var tools = require("./tools.js");
var utils = require("./utils.js");
var pkgName = "com.whatsapp";
var config = {};
var tmpTaskList = [];
var isContinueFail = 0;
var instance = {};
var isOver = false;
// // 定义多语言文本映射
// const i18nText = {
//    Chats: ["Chats", "Conversas"], // 墨西哥 / 巴西
//    Selft: ["(Tú)",],
//    Chatear: ["Chatear",],
//    SuccessTag: ["Enviado", "Leído", "Entregado"],
// }

// 通用函数，查找匹配任一语言
function findTextEnd(keys, timeout) {
   let tmpNode = null;
   keys.forEach((item, index) => {
      const node = textEndsWith(item).findOne(timeout);
      if (node) {
         tmpNode = node;
      }
   })
   return tmpNode;
}
function findTextStart(keys, timeout) {
   let tmpNode = null;
   keys.forEach((item, index) => {
      const node = textStartsWith(item).findOne(timeout);
      if (node) {
         tmpNode = node;
      }
   })
   return tmpNode;
}

function findDescStart(keys, timeout) {
   let tmpNode = null;
   keys.forEach((item, index) => {
      const node = descStartsWith(item).findOne(timeout);
      if (node) {
         tmpNode = node;
      }
   })
   return tmpNode;
}

var fadeData = ` [{
            "name": "TGAI私信 ",
            "app_id": 10,
            "config":
            {
                "has_paid": 1,
                "reply_timeout": 1,
                "single_interval":
                    [
                        2,
                        5
                    ],
                "account_interval":
                    [
                        1,
                        2
                    ]
            },
            "task_id": 15,
            "has_paid": 1,
            "task_data":
                [
                    {
                        "text":
                            [
                                "嘿~ 刚刷到你在推特，聊聊？"
                            ],
                        "account": "+55 11 94603-3714",
                        "detail_id": 1826
                    }
                ],
            "task_type": 8,
            "task_length": 5,
            "task_sub_id": 1316,
            "times_stop_begin": 0,
            "continuous_fail_stop": 0
        }]`;

var fakeContent = ["Olá~ Acabei de ver você no Twitter, quer bater um papo?",
   "Ouvi dizer que esse lugar é divertido. Por que você não dá uma olhada?",
   "Há muitas comidas deliciosas aqui~",
   "Pode",
   "Sem chance! ! Você não ouviu falar dessa animação? ! ! !",
   "Sem problemas",
   "Todas as manhãs quando acordo, sou grato pela sua companhia 🌅✨.",
   "Bom dia, vamos saudar o novo dia juntos com belas expectativas em nossos corações 🌞🌈.",
   "mas...",
   "Bom dia! Espero que tudo corra como você deseja hoje e que tudo seja repleto de icidade e alegria! 🥰🌻.",
   "Desejo a você um dia cheio de energia positiva e que comece o novo dia com total alidade 💪😊.",
   "Bom dia! Você é a pessoa mais especial do meu coração, desejo-lhe um bom dia! 💖✨.",
   "bom",
   "Ao amanhecer, desejo a você um dia feliz e alegre. 🌟🌱.",
   "Bom dia! Que seu dia seja repleto de bênçãos e alegrias, e que você aproveite cada momento dele! 🎉😄",
   "O sol da manhã também é minha saudação para você, que você tenha um dia maravilhoso ☀️💕.",
   "Bom dia! Cada manhã é um novo milagre. Vamos saudar o novo dia com confiança! 🌈🌼.",
   " Acorde cedo, que você sorria todos os dias e comece o dia com gratidão e carinho! 😊🌸.",
   "Ok, eu entendo",
   "Pode",
   "mas...",
   "Sem problemas",
   "Mas!",
   `${random(1, 3000)}`,
];

events.on("say", function (param) {
   instance.handle(param.list);
});

var runing = setInterval(() => {
   if (isOver) {
      clearInterval(runing);
   }
}, 1000);

instance.handle = function (taskList) {
   try {
      // var taskFinishCount = 0;
      tmpTaskList = tools.storage.get("whatsapp", []);
      console.info("获取本地缓存", tmpTaskList);
      console.info("传入数据 =>\n", taskList);
      // 提交旧数据/ 赋值新任务
      if (tmpTaskList.length > 0) {
         tmpTaskList.forEach((item, index) => {
            try {
               if (item.task_sub_id != taskList[index].task_sub_id) {
                  console.log("提交旧任务：", item.task_sub_id, taskList[index].task_sub_id);
                  submitRes(index);
                  tmpTaskList[index] = taskList[index];
               }
            } catch (error) {

            }
         })
      } else {
         tmpTaskList = taskList;
      }

      // 执行任务
      tmpTaskList.forEach((item, i) => {
         config = item.config;
         // 执行所有人
         exeAll(item, i);
         // 提交前，检查一边失败的，提高成功率
         recheckFailed(item, i);
         console.log("提交任务", i);
         submitRes(i);
      })
      isOver = true;
   } catch (error) {
      isOver = true;
      tools.storage.put("whatsapp", tmpTaskList);
      console.error("运行中报错，保存数据::::", error);
      // submitRes(-1);
      // engines.myEngine().forceStop();
   }
}

function checkRes(res, i, j) {
   if (res == -4) {
      console.log(`(s=${res}) 控件未找到`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 6;
      tmpTaskList[i].task_data[j].result_text = "控件未找到";
   }
   if (res == 100) {
      console.log(`(s=${res}) 成功`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 1;
      tmpTaskList[i].task_data[j].result_text = "成功";
   }
   if (res == -10) {
      console.log(`(s=${res}) 账号被禁`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "账号被禁";
      tmpTaskList[i].task_data[j].status = 4;
      isOver = true;
   }
   if (res == -11) {
      console.log(`(s=${res})未登录Ws`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 5;
      tmpTaskList[i].task_data[j].result_text = "未登录WS";
      isOver = true;
   }
   if (res == -20) {
      console.log(`(s=${res}) 目标账号不存在`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "目标账号不存在";
      tmpTaskList[i].task_data[j].status = 3;
   }
   if (tmpTaskList[i].task_data[j].taskFinish) { } else {
      console.log(`(s=${res}) 失败`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 2;
      tmpTaskList[i].task_data[j].result_text = "失败";
   }
   tools.storage.put("whatsapp", tmpTaskList);
}

function recheckFailed(item, i) {
   item.task_data.forEach((data, j) => {
      console.log("检查失败", tmpTaskList[i].task_data[j].status, tmpTaskList[i].task_data[j].result_text);
      if (tmpTaskList[i].task_data[j].status == 2) {
         let res = exeTask(data, i, j);
         checkRes(res, i, j);
      }
   })
}

function exeAll(item, i) {
   item.task_data.forEach((data, j) => {
      console.log("任务-", i, j, "数据", tmpTaskList[i].task_data[j])
      if (tmpTaskList[i].task_data[j].taskFinish) { } else {
         let res = exeTask(data, i, j);
         console.log("结果：", res);
         if (res == -4 || res == -5) {
            res = exeTask(data, i, j);
         }
         checkRes(res, i, j);
      }
      console.log("执行完一个", i, j);
   })
}


// 删除聊天对话
function deleteTaskContent() {
   try {
      console.log("deleteTaskContent-", 1);
      let tabBarMenu = id("com.whatsapp:id/menuitem_overflow").findOne(5000);
      tabBarMenu.click();
      console.log("deleteTaskContent-", 2);
      sleep(1000);
      let root = className("android.widget.ListView").findOne(5000);
      sleep(1000);
      root.children().each(function (child) {
         if (child.className() === "android.widget.LinearLayout") {
            if (child.findOne(id("com.whatsapp:id/title")).text() === "Mais") {
               child.click();
            }
         }
      });
      console.log("deleteTaskContent-", 3);
      sleep(1000);
      let root2 = className("android.widget.ListView").findOne(5000);
      console.log("deleteTaskContent-", 4);
      sleep(1000);
      root2.children().each(function (child) {
         if (child.className() === "android.widget.LinearLayout") {
            let textNode = child.findOne(id("com.whatsapp:id/title"));
            if (textNode && textNode.text() === "Limpar conversa") {
               child.click();
            }
         }
      });
      console.log("deleteTaskContent-", 5);
      let checkBoxContainer = id("com.whatsapp:id/delete_media_checkbox").findOne(5000);
      let checkBox = id("com.whatsapp:id/delete_media_checkbox").findOne(5000);
      if (checkBoxContainer) {
         if (checkBox.isSelected() == false) {
            checkBoxContainer.click();
         }
         sleep(1000);
         console.log("deleteTaskContent-", 6);
         let deleteNode = id("android:id/button1").findOne(5000);
         if (deleteNode) {
            deleteNode.click();
            console.log("deleteTaskContent-", "finish");
            sleep(500);
         }
      }
   } catch (e) {
      console.error("删除对话失败", e);
   }
}


function randomNum(minNum, maxNum) {
   return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}

function submitRes(i) {
   let res = {};
   res.task_id = tmpTaskList[i].task_id;
   res.task_sub_id = tmpTaskList[i].task_sub_id;
   res.ex_account = tmpTaskList[i].ex_account;
   res.has_continuous_fail = isContinueFail;
   res.task_data = JSON.stringify(tmpTaskList[i].task_data);
   console.error("提交数据", res);
   let result = utils.submitTask(res);
   console.log("提交结果", result);
   tools.storage.remove("whatsapp");
   tmpTaskList = [];
}

function submitBlocked(i) {
   let res = {};
   res.app_id = tmpTaskList[i].app_id;

   utils.submitBlocked(res, function () {
      tools.addStatus(tmpTaskList[i].pkgName);
      console.log("账号被封禁提交成功");
   });
}

function deleteUserList() {
   // try {
   back();
   back();
   sleep(500);
   let selfNode = textEndsWith(")").findOne(5000);
   if (selfNode) {
      longClick(")");
      let selfNodeRect = selfNode.bounds();
      let deleteTargetNode = id("com.whatsapp:id/conversations_row_contact_name").find();
      deleteTargetNode.each(function (child) {
         let childRect = child.bounds();
         if (childRect.centerY() < selfNodeRect.centerY()) {
            console.log(child.text());
            click(child.text());
            sleep(500);
         }
      });

      let pinNode = id("com.whatsapp:id/menuitem_conversations_pin").findOne(5000);
      if (pinNode) {
         let deleteRect = pinNode.bounds();
         click(deleteRect.centerX() + deleteRect.width(), deleteRect.centerY());
         sleep(1000);
         let deleteNode = descStartsWith("Apagar").findOne(5000);
         if (deleteNode) {
            deleteNode.click();
            console.log("0=====  delete success");
            return;
         } else {
            console.warn("3=====  delete step  3");
         }
      } else {
         console.warn("2=====  delete step  2");
      }
   } else {
      console.warn("1=====  delete step  1");
   }
   // } catch (error) {
   //    console.warn("-1=====  delete  exp", error);
   // }
}


function sendMsg(data, i, j) {
   try {
      console.log("sendMsg:-1", data, data.text);
      let isScuccess = false;
      if (data.text && data.text.length > 0) {
         let inputNode = id("com.whatsapp:id/entry").findOne(5000);
         if (!inputNode) {
            return -4;
         }
         console.log("sendMsg:-2");
         data.text.forEach((item, index) => {
            console.log("sendMsg:", tmpTaskList[i].task_data[j].sendIndex, item, index);
            if (tmpTaskList[i].task_data[j].sendIndex && index < tmpTaskList[i].task_data[j].sendIndex) { } else {
               inputNode.setText(item);
               sleep(500);
               var sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (sendNode && sendNode.click()) {
                  sleep(500);
                  tmpTaskList[i].task_data[j].sendIndex = index + 1;
                  tools.storage.put("whatsapp", tmpTaskList);
               }
               let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
               sleep(randTime * 1000);
            }
         })
         console.log("sendMsg:-3", tmpTaskList[i].task_data[j].sendIndex);
         sleep(config.send_timeout * 1000);
         if (tmpTaskList[i].task_data[j].sendIndex) {
            let isSuccessNode = id("com.whatsapp:id/status").find();
            console.log("检查节点：111111");
            let checkNodes = isSuccessNode.slice((tmpTaskList[i].task_data[j].sendIndex + 1) * -1);
            console.log("检查节点：222222");
            console.log("检查节点：", checkNodes);

            checkNodes.forEach(function (child) {
               let descStutas = child.desc();
               console.log("状态", descStutas, data.account);
               let successTag = ["Enviado", "Leído", "Entregado", "Enviada", "Entregue", "Lida"];
               if (successTag.includes(descStutas)) {
                  // tmpTaskList[i].task_data[j].taskFinish = true;
                  // tools.storage.put("whatsapp", tmpTaskList);
                  console.log("sendMsg:", 3);
                  isScuccess = true;
                  return;
               }
            });
         }
      }
      if (data.video && data.video.length > 0) {
         data.video.forEach((item, index) => {
            if (tmpTaskList[i].task_data[j].sendIndexVideo && index <= tmpTaskList[i].task_data[j].sendIndexVideo) { } else {
               let downFileName = tools.downloadFiles(item);
               if (downFileName == "") {
                  videoOkNum = -1;
                  console.log("1=====  send msg  download video failed");
                  return;
               }

               var attachNode = id("com.whatsapp:id/input_attach_button").findOne(5000);
               if (!attachNode) {
                  return;
               }
               attachNode.click();
               sleep(500);

               var medioNode = id("com.whatsapp:id/pickfiletype_gallery_holder").findOne(5000);
               if (!medioNode) {
                  return;
               }
               medioNode.click();
               sleep(500);

               var targeVidowtNode = idContains("com.whatsapp:string/(name removed)").findOne(5000);
               if (!targeVidowtNode) {
                  return;
               }
               targeVidowtNode.click();
               sleep(500);

               var sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (!sendNode) {
                  return;
               }
               sendNode.click();
               sleep(500);
               tmpTaskList[i].task_data[j].sendIndexVideo = index;

               let randTime = randomNum(config.single_interval[0], config.single_interval[1])
               sleep(randTime * 1000);
            }
         })
      }
      if (data.image) {
         if (data.image.length > 0) {
            data.image.forEach(() => {

            })
         }
      }
      if (isScuccess) {
         return 100;
      }
      return -5;
   } catch (error) {
      console.log(error);
      return -4;
   }
}

function reGetTarget(data, i, j, maxNum) {
   back();
   if (maxNum < 1) return -20;

   var result = utils.redistributionWs(tmpTaskList[i].task_sub_id, data.detail_id);
   if (result == -100) {
      console.log('重新分配账号接口');
      return -20;
   }
   if (result == -2) {
      console.log('重试3次后重新分配账号仍然失败');
      return -20;
   }
   data.account = result;
   let inputNode = className("android.widget.EditText").findOne(5000);
   if (!inputNode) {
      return -4;
   }
   inputNode.setText(data.account);
   sleep(1000);

   console.log(5);
   let sendNode = id("com.whatsapp:id/send").findOne(5000);
   if (sendNode == null) {
      sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
   }
   if (!sendNode) {
      return -4;
   }
   sendNode.click();
   sleep(500);

   console.log(6);
   let targetNode = desc(data.account).className("android.view.View").findOne(5000);
   if (!targetNode) {
      return -4;
   }
   targetNode.click();
   sleep(5000);

   console.log(7);
   // let targetCallNode = textMatches(/^(Conversar|Chatear)/).clickable(true).findOne(25000);
   let tmpTargetList = ["Conversar", "Chatear"];
   let targetCallNode = findTextStart(tmpTargetList, 7000);
   if (!targetCallNode) {
      console.log("目标号码不存在", data.account);
      // let noWsNode = textStartsWith("Ligar para").findOne(5000);
      // if (noWsNode) {
      //    console.log("目标号码不存在", data.account);
      //    // return -20;
      //    return reGetTarget(data, i, j, maxNum - 1);
      // }
      return reGetTarget(data, i, j, maxNum - 1);
   }
   targetCallNode.click();
   sleep(500);

   let tmpCheckNode = id("com.whatsapp:id/ephemeral_nux_ok").findOne(2000);
   if (tmpCheckNode) {
      tmpCheckNode.click();
   }

   console.log(8);
   return sendMsg(data, i, j);
}

function getNameBeforeLangTag(text, langTags) {
   for (let tag of langTags) {
      const idx = text.indexOf(tag);
      if (idx !== -1) {
         return text.substring(0, idx).trim();
      }
   }
   return text;
}
//  exe task
function exeTask(data, i, j) {

   console.log("打开执行");
   launchApp();
   sleep(random(5000, 7000));
   while (true) {
      console.log(1);
      let keywords = ["Conversas", "Chats"];
      let userListNode = findDescStart(keywords, 5000);
      if (!userListNode) {
         let noAccountList = ["Esta conta não"]
         let notAccountNode = findTextStart(noAccountList, 1000);
         if (notAccountNode) {
            console.info("账号被封");
            return -10;
         }
         console.log("第一步没找到111111");
         let notLoginNode = textMatches(/(CONCORDAR E CONTINUAR|ACEPTAR Y CONTINUAR)/).findOne(2000);
         if (notLoginNode) {
            console.info("未登录");
            return -11;
         }
         return -4;
      }
      if (!userListNode.isSelected()) {
         userListNode.select();
         sleep(3000);
      }

      console.log(2);
      let addTagNode = id("com.whatsapp:id/fab").findOne(10000);
      if (!addTagNode) {
         addTagNode = id("com.whatsapp:id/fabText").findOne(5000);
      }
      if (!addTagNode) {
         return -4;
      }
      if (addTagNode.click()) {
         console.log("点击+好友");
      }
      sleep(2000);

      console.log(3);
      // let selfNode = textMatches(/\s*(\(você\)|\(Tú\))$/).findOne(5000);
      let tmpSelfList = ["(você)", "(Tú)"];
      let selfNode = findTextEnd(tmpSelfList, 2000);
      if (!selfNode) {
         return -4;
      }
      let selfName = selfNode.text();
      tmpTaskList[i].ex_account = getNameBeforeLangTag(selfName, [" (Tú)", " (você)"]);
      click("(Tú)");
      click("(você)");
      sleep(1000);

      console.log(4);
      console.log(4, data.account);
      let inputNode = className("android.widget.EditText").findOne(5000);
      if (!inputNode) {
         return -4;
      }
      let targetNode = desc(data.account).className("android.view.View").findOne(5000);
      if (!targetNode) {
         inputNode.setText(data.account);
         sleep(1000);

         console.log(5);
         let sendNode = id("com.whatsapp:id/send").findOne(5000);
         if (sendNode == null) {
            sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
         }
         if (!sendNode) {
            return -4;
         }
         sendNode.click();
         sleep(500);
      }

      console.log(6);
      targetNode = desc(data.account).className("android.view.View").findOne(5000);
      if (!targetNode) {
         return -4;
      }
      targetNode.click();
      sleep(5000);

      console.log(7);
      let tmpTargetList = ["Conversar", "Chatear"];
      // let targetCallNode = textMatches(/^(Conversar|Chatear)/).clickable(true).findOne(20000);
      let targetCallNode = findTextStart(tmpTargetList, 7000);

      if (!targetCallNode) {
         // let noWsNode = textStartsWith("Ligar para").findOne(5000);
         // if (noWsNode) {
         //    console.log("目标号码不存在", data.account);
         //    // return -20;
         //    return reGetTarget(data, i, j, 20);

         // }
         return reGetTarget(data, i, j, 20);
      }
      targetCallNode.click();
      sleep(500);

      let tmpCheckNode = id("com.whatsapp:id/ephemeral_nux_ok").findOne(2000);
      if (tmpCheckNode) {
         tmpCheckNode.click();
      }

      console.log(8);
      return sendMsg(data, i, j);
   }
}

function launchApp() {
   console.log("启动");
   var intent = new Intent();
   intent.setClassName(pkgName, "com.whatsapp.HomeActivity");
   intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
   context.startActivity(intent);
}
