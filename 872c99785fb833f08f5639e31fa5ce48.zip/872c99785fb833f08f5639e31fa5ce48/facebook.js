var utils = require("./utils.js");
var tools = require("./tools.js");
var storage = storages.create(STORAGE_KEY);

var context = context || {};
if (!context) {
    throw new Error("Context is not available");
}

var isText = JSON.parse(files.read("project.json")).build.is_debug || false;

var isOver = false;
// 简化配置对象
const CONFIG = {
    packageName: "com.facebook.katana",
    activityName: "com.facebook.katana.activity.FbMainTabActivity",
    maxRetries: 5,
    retryInterval: 500,
    uiWaitTime: 1000,
    findOneTimeout: 3000
};

// 添加全局存储常量
events.on("say", function (data) {
    console.info('------------------------------say', JSON.stringify(data, null, 2));
    try {
        sendSmsList(data);
    } catch (e) {
        console.error("事件处理发生错误:", e);
        // if (!e.toString().includes("ScriptInterruptedException")) {
        //     throw e;
        // }
    }
});

threads.start(function () {
    events.on("stop", function () {
        console.log("强制结束");
        try {
            let globalTask = loadGlobalTask();
            if (globalTask) {
                //未执行的联系人设置为超时失败
                globalTask.task_data.forEach(item => {
                    if (typeof item.status !== 'number') {
                        formatResult(item, "强制结束", BusinessErrorCodes.OTHER_FAILED);
                    }
                });
                saveGlobalTask();
                checkAllTasksCompleted();
            }
        } catch (e) {
            console.error("强制结束时发生错误:", e);
        }
        engines.myEngine().forceStop();
    })
});

//保持脚本运行
var runing = setInterval(() => {
    if (isOver) {
        clearInterval(runing);
    }
}, 1000);

// 添加持久化相关的工具函数
const STORAGE_KEY = "facebook_storage";
const GLOBAL_TASK_KEY = "facebook_global_task";


// 添加新的存储键名常量
const MESSAGE_STATUS_KEY = "message_status_store";
const ACCOUNT_KEY = "facebook_account";

function saveGlobalTask() {
    try {
        storage.put(GLOBAL_TASK_KEY, JSON.stringify(globalTask));
        console.log("全局任务已保存到存储");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存全局任务失败:", e);
        throw e;
    }
}

function loadGlobalTask() {
    try {
        const savedTask = storage.get(GLOBAL_TASK_KEY);
        return savedTask ? JSON.parse(savedTask) : null;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("加载全局任务失败:", e);
        throw e;
    }
}

function clearMessageStatuses() {
    try {
        storage.remove(MESSAGE_STATUS_KEY);
        console.log("清除所有消息状态记录");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除消息状态失败:", e);
    }
}

// 添加消息状态管理的工具函数
function saveMessageStatus(taskSubId, account, detailId, status) {
    try {
        const statusKey = `${taskSubId}_${account}_${detailId}`;
        let statusStore = storage.get(MESSAGE_STATUS_KEY);
        let statusMap = statusStore ? JSON.parse(statusStore) : {};
        statusMap[statusKey] = status;
        storage.put(MESSAGE_STATUS_KEY, JSON.stringify(statusMap));
        console.log(`保存消息状态: ${statusKey} -> ${status}`);
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存消息状态失败:", e);
    }
}

function getMessageStatus(taskSubId, account, detailId) {
    try {
        const statusKey = `${taskSubId}_${account}_${detailId}`;
        let statusStore = storage.get(MESSAGE_STATUS_KEY);
        let statusMap = statusStore ? JSON.parse(statusStore) : {};
        let status = statusMap[statusKey];
        return status;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("获取消息状态失败:", e);
        return MessageStatus.PENDING;
    }
}

// 修改自定义错误类的实现
function OperationError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = true;
    }
    Error.call(this);
    this.name = 'OperationError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

OperationError.prototype = Object.create(Error.prototype);
OperationError.prototype.constructor = OperationError;

// 错误代码常量
const ErrorCodes = {
    APP_LAUNCH_FAILED: 1001,
    ELEMENT_NOT_FOUND: 1002,
    CLICK_FAILED: 1003,
    INPUT_FAILED: 1004,
    CONTACT_LIST_ERROR: 1005,
    CONTACT_SELECT_ERROR: 1006,
    AI_REPLY_FAILED: 1007
};

// 错误代码常量
const BusinessErrorCodes = {
    // 1-成功,2-其他失败 3-账号不存在,4-账号被封,5-APP未登录,6-控件未找到,7-结束语未发送成功,8-AI接口无返回,9-执行账号已被绑定,10-执行账号异常
    SUCCESS: 1,
    OTHER_FAILED: 2,
    ACCOUNT_NOT_EXIST: 3,
    ACCOUNT_BLOCKED: 4,
    APP_NOT_LOGIN: 5,
    ELEMENT_NOT_FOUND: 6,
    EXECUTION_ACCOUNT_BOUND: 9,
    EXECUTION_ACCOUNT_EXCEPTION: 10
};


// 修改自定义错误类的实现
function BusinessError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = false;
    }
    Error.call(this);
    this.name = 'BusinessError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

BusinessError.prototype = Object.create(Error.prototype);
BusinessError.prototype.constructor = BusinessError;

// 添加消息状态常量
const MessageStatus = {
    PENDING: 'pending',
    SENDED: 'sending',
    SUCCESS: 'success',
    FAILED: 'failed'
};

function goHome() {
    console.log("开始启动应用:", CONFIG.packageName);
    let retries = 0;
    console.log("尝试启动应用 (第" + (retries + 1) + "次)");

    // 创建Intent
    let intent = new android.content.Intent();

    // 设置包名和活动名，确保启动主界面
    intent.setClassName(CONFIG.packageName, CONFIG.activityName);

    // 添加标志，确保回到主界面
    intent.addFlags(
        android.content.Intent.FLAG_ACTIVITY_NEW_TASK |
        android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP |
        android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
    );

    // 启动活动
    context.startActivity(intent);

    // 等待应用启动并检查界面
    let maxWaitAttempts = 5;
    let waitAttempt = 0;
    let infacebook = false;

    while (waitAttempt < maxWaitAttempts && !infacebook) {
        sleep(1000);
        let currentPkg = currentPackage();
        if (currentPkg === CONFIG.packageName) {
            console.log("成功进入Facebook界面");
            infacebook = true;
        } else {
            console.log(`当前不在Facebook界面,当前包名: ${currentPkg} (尝试 ${waitAttempt + 1}/${maxWaitAttempts})`);
            waitAttempt++;
        }
    }

    if (!infacebook) {
        throw new OperationError(
            ErrorCodes.APP_LAUNCH_FAILED,
            "应用启动失败: 多次尝试后仍未进入facebook界面"
        );
    }

    // 检查是否在主界面，如果不是则点击返回
    let backAttempts = 0;
    const MAX_BACK_ATTEMPTS = 10;

    while (backAttempts < MAX_BACK_ATTEMPTS) {
        // 检查是否在主界面
        let homeIndicator = descMatches(/(facebook 徽标|Facebook logo|logotipo do Facebook|Logotipo de Facebook|logotipo de Facebook)/).findOne(5000)

        if (homeIndicator) {
            console.log("已回到主界面");
            break;
        }

        console.log(`尝试返回主界面 (第${backAttempts + 1}次)`);
        back();
        // waitAndClick(descMatches(/(返回|Voltar|Back|Atrás)/), true, "返回主界面");
        let cancelBtn = descMatches(/(放弃发布|Discard post|Descartar post|Descartar publicación|Descartar publicación)/).findOne(1000)
        if (cancelBtn) {
            console.log("点击取消发布");
            cancelBtn.click();
        }
        backAttempts++;
    }

    if (backAttempts >= MAX_BACK_ATTEMPTS) {
        console.warn("达到最大返回次数，可能未回到主界面");
    }

    console.log("应用启动成功");
    return;
}


// 等待并点击元素的通用函数
function waitAndClick(selector, useBounds, description) {
    console.log("开始等待并点击元素", description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                throw new OperationError(
                    ErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 未找到目标元素"
                );
            }

            sleep(500);
            if (useBounds) {
                var bounds = element.bounds();
                if (!bounds) {
                    throw new OperationError(
                        ErrorCodes.ELEMENT_NOT_FOUND,
                        description + " 获取元素边界失败"
                    );
                }
                click(bounds.centerX(), bounds.centerY());
            } else {
                element.click();
            }
            return;

        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new BusinessError(
                    BusinessErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 点击元素失败: " + e.message,
                    true
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

// 格式化结果的辅助函数
function formatResult(contact, message, status) {
    console.log("处理结果:", contact.account, message, status);
    contact.result_text = message;
    contact.result_image = "";
    contact.status = status;
    return contact;
}

// 修改处理消息组函数中的间隔处理
function processItemTask(currentTask, account_interval, taskData) {
    let retryCount = 0;
    const MAX_RETRIES = 1;

    while (retryCount <= MAX_RETRIES) {
        try {
            //如果联系人已经有状态，或者所有消息发送失败，则跳过
            if (typeof currentTask.status === 'number') {
                console.log(`跳过处理: status=${currentTask.status}`);
                return;
            }
            // 检查当前任务的消息状态
            let currentStatus = getMessageStatus(globalTask.task_sub_id, currentTask.account, currentTask.detail_id);
            console.log(`当前任务状态: ${currentStatus}`);
            // 如果已经成功发送，则跳过
            if (!currentStatus) {
                publishPosts(currentTask);
            }
            checkPublishResult(currentTask);
            break;
        } catch (innerError) {
            if (innerError.toString().includes("ScriptInterruptedException")) {
                throw innerError;
            }
            console.error(innerError);
            // 检查是否是我们自定义的业务异常
            if (innerError instanceof OperationError) {
                // 检查是否需要重试
                if (!innerError.retryable) {
                    formatResult(currentTask, "发布失败: " + innerError.message, BusinessErrorCodes.OTHER_FAILED);
                    saveGlobalTask();
                    return;
                }
            }

            if (innerError instanceof BusinessError) {
                if (!innerError.retryable) {
                    formatResult(currentTask, "发布失败: " + innerError.message, innerError.code);
                    saveGlobalTask();
                    return;
                }
            }

            // 进入重试逻辑
            retryCount++;
            console.error(`处理失败 (第${retryCount}次)`);
            if (retryCount <= MAX_RETRIES) {
                console.error(innerError);
                console.log(`准备第${retryCount}次重试...`);
                sleep(CONFIG.retryInterval);
                continue;
            }

            formatResult(currentTask, "发布失败: " + innerError.message, innerError instanceof BusinessError ? innerError.code : BusinessErrorCodes.OTHER_FAILED);
            saveGlobalTask();
        }
    }
}

function setPublic() {
    console.log("开始设置公开权限...");
    // waitAndClick(descMatches(/(Edit Privacy |)/), true, "编辑公开");
    // console.log("点击编辑公开按钮完成");
    // sleep(3000);
    
    console.log("开始查找Friends按钮...");
    let friendsElement = descMatches(/(Choose privacy Friends|Elegir privacidad Amigos|Escolha a privacidade Amigos|Friends|Amigos|Amigos)/).findOne(5000);
    console.log("friendsElement",friendsElement)
    if (friendsElement) {
        
        console.log("找到Friends按钮，准备点击");
        
        // click(friendsElement.bounds().centerX(), friendsElement.bounds().centerY());
        friendsElement.click();

        console.log("Friends按钮点击完成");
    } else {
        console.log("未找到Friends按钮");
    }
    sleep(3000)

    console.log("开始查找Public单选按钮...");
    let publicElement = className("android.widget.RadioButton").descMatches(/(Public|Público|Público).*/).findOne(5000);
    console.log("publicElement",publicElement)
    if (publicElement) {
        console.log("找到Public单选按钮，准备点击");
        let parent = publicElement;
        if (parent) {
            console.log("获取到父元素，准备点击父元素中心点");
            click(parent.bounds().centerX(), parent.bounds().centerY());
            console.log("Public单选按钮点击完成");
        } else {
            console.log("未找到Public按钮的父元素");
        }
    } else {
        console.log("未找到Public单选按钮");
    }
    
    sleep(3000);
    console.log("开始查找Done/Save按钮...");
    waitAndClick(textMatches(/(Done|Listo|Concluir|Save)/), true, "公开保存");
    // let doneElement = textMatches(/(Done|Listo|Concluir|Save)/).findOne(3000);
    // console.log("doneElement",doneElement)
    // if (doneElement) {
    //     console.log("找到Done/Save按钮，准备点击");
    //     doneElement.click();
    //     console.log("Done/Save按钮点击完成");
    // } else {
    //     console.log("未找到Done/Save按钮");
    // }
    sleep(3000);
    console.log("设置公开权限流程完成");
}


function findElementByDesc(desc) {
    let retryCount = 0;
    const MAX_RETRIES = 3;

    while (retryCount < MAX_RETRIES) {
        try {
            // 遍历所有节点
            let elements = find();
            for (let element of elements) {
                let elementText = element.desc();
                if (!elementText) continue;

                // 检查是否是正则表达式
                if (desc instanceof RegExp) {
                    if (desc.test(elementText)) {
                        console.log(element.toString());
                        console.log("找到匹配正则表达式" + desc + "的元素");
                        return element;
                    }
                } else if (elementText === desc) {
                    console.log("找到text为" + desc + "的元素");
                    return element;
                }
            }
            console.log("未找到匹配的元素,重试第" + (retryCount + 1) + "次");
            retryCount++;
            sleep(500);
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("查找元素出错:", e);
            retryCount++;
            if (retryCount >= MAX_RETRIES) {
                throw e;
            }
            sleep(500);
        }
    }
    console.log("达到最大重试次数,未找到元素");
    return null;
}

function publishPosts(currentTask) {
    goHome();
    sleep(3000);
    waitAndClick(descMatches(/.*,.*1.*/), false, "首页");
    sleep(1000);
    waitAndClick(descMatches(/.*,.*1.*/), false, "首页");
    sleep(3000);
    // let shareButton = null;
    // // 最多滑动3次，找到按钮就停止
    // for (let i = 0; i < 3; i++) {
    //     // 先尝试查找分享新鲜事按钮
    //     shareButton = descMatches(/(分享新鲜事|What's on your mind|No que você está pensando|¿Qué estás pensando|Faça um post no Facebook|Haz una publicación en Facebook|Make a post on Facebook).*/).findOne(1000);
    //     if (shareButton) {
    //         console.log("找到分享新鲜事按钮，停止滑动");
    //         break;
    //     }

    //     console.log(`第${i + 1}次滑动`);
    //     swipe(device.width / 2, device.height * 0.8, device.width / 2, device.height * 0.6, 500);
    //     sleep(1000);
    // }
    waitAndClick(descMatches(/(分享新鲜事|What's on your mind|No que você está pensando|¿Qué estás pensando|Faça um post no Facebook|Haz una publicación en Facebook|Make a post on Facebook).*/), true, "分享新鲜事");
    console.log("开始发布帖子:", currentTask.paperwork);
    sleep(3000);
    toastLog("开始下载视频:" + currentTask.video);
    let downloadVideoPath = tools.downloadFiles(currentTask.video);
    console.log("downloadVideoPath:", downloadVideoPath);
    setPublic();
    sleep(3000);
    setTextSafely(className("android.widget.AutoCompleteTextView"), currentTask.paperwork + " #" + currentTask.tag, "设置帖子内容");
    sleep(3000);
    
    waitAndClick(descMatches(/(照片\/视频|Photo\/video|Foto\/vídeo|Foto\/video)/), true, "选择视频");
    sleep(3000);
    //第一个gridview里面的第一个Button点击
    let gridView = className("android.widget.GridView").findOne();
    console.log("gridView:", gridView);
    if (gridView) {
        console.log("gridView找到");
        let firstButton = gridView.findOne(descMatches(/.*(gravado em|taken on|grabado el).*/).className("android.widget.Button"))
        console.log("firstButton:", firstButton);
        if (firstButton) {
            sleep(1000);
            console.log("点击第一个按钮");
            click(firstButton.bounds().centerX(), firstButton.bounds().centerY());
        }
    }
    sleep(3000)
    let netbutton = descMatches(/(SIGUIENTE|NEXT|AVANÇAR)/).findOne(3000);
    if (netbutton) {
        click(netbutton.bounds().centerX(), netbutton.bounds().centerY());
        sleep(3000)
    }
    //点击发布
    if (!isText) {
        waitAndClick(descMatches(/(发布|POST|Publicar|POSTAR|PUBLICAR)/), true, "发布");
    }
    // 更新状态为发送中
    saveMessageStatus(globalTask.task_sub_id, currentTask.account, currentTask.detail_id, MessageStatus.SENDED);
    //    tools.deleteDownloadFiles(downloadVideoPath);
}

// 添加检查发布结果的函数
function checkPublishResult(currentTask) {
    let maxOuterRetries = 5;
    let outerRetryCount = 0;

    while (outerRetryCount < maxOuterRetries) {
        try {
            console.log("检查发布结果");
            goHome();
            sleep(3000);
            // waitAndClick(descMatches(/(个人主页|Profile|Perfil).*/), false, "个人主页");
            waitAndClick(descMatches(/.*,.*1.*/), false, "首页");
            sleep(1000);
            waitAndClick(descMatches(/.*,.*1.*/), false, "首页");
            sleep(3000);
            waitAndClick(descMatches(/(Go to profile|Ir para o perfil|Ir al perfil).*/), true, "分享新鲜事");
            console.log("开始检查帖子:", currentTask.paperwork);
            sleep(3000);

            let paperWorkText = null;
            let maxRetries = 5;
            let retryCount = 0;

            while (retryCount < maxRetries) {
                paperWorkText = textStartsWith(currentTask.paperwork.substring(0, 30)).findOne(3000);
                if (paperWorkText) {
                    console.log("找到帖子内容，停止滑动");
                    break;
                }

                console.log(`第${retryCount + 1}次滑动查找帖子内容`);
                swipe(device.width / 2, device.height * 0.7, device.width / 2, device.height * 0.5, 400);
                sleep(1000);
                retryCount++;
            }

            if (!paperWorkText) {
                console.log("未找到帖子内容，发布可能失败");
                outerRetryCount++;
                continue;
            }

            let parent = paperWorkText.parent().parent();
            parent.child(0).click();
            sleep(3000);
            // waitAndClick(descMatches(/(更多|更多选项|More|Mais|Más)/), true, "更多");
            // sleep(3000);
            // setPublic();
            waitAndClick(descMatches(/(更多|更多选项|More|Mais|Más)/), true, "更多");
            sleep(3000);
            waitAndClick(descMatches(/(复制链接|Copiar link|Copy link|Copiar link|Copiar enlace)/), true, "复制链接");
            console.log("复制链接成功");
            sleep(1000);

            let input = className("android.widget.AutoCompleteTextView").findOne(3000);
            console.log("input:", input);
            if (input) {
                input.click();
                sleep(1000)
                input.setText("");
                sleep(2000);
                input.paste();
                sleep(1000);
                input.refresh();
                // back();
                // sleep(1000)
                // input.click();
                // sleep(1000);
            }

            let clipboardContent = input.text();
            console.log("clipboardContent:", clipboardContent);
            if (clipboardContent) {
                formatResult(currentTask, clipboardContent, BusinessErrorCodes.SUCCESS);
                saveGlobalTask();
            } else {
                formatResult(currentTask, "发布成功 但未找到链接", BusinessErrorCodes.SUCCESS);
                saveGlobalTask();
                outerRetryCount++;
                continue;
            }
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error(`第${outerRetryCount + 1}次尝试失败:`, e);
            outerRetryCount++;
            sleep(1000);
            continue;
        }
    }


    console.log("达到最大重试次数，发布检查失败");
    if (typeof currentTask.status !== 'number') {
        formatResult(currentTask, "发布成功 但未找到链接", BusinessErrorCodes.SUCCESS);
        saveGlobalTask();
    }
}

// 主要处理函数
function sendSmsList(data) {
    if (isText) {
        // 更新测试数据
        data = {
            "list": [
                {
                    "name": "巴西",
                    "app_id": 2,
                    "config":
                    {
                        "continuous_fail_stop": "12",
                        "post_interval":
                            [
                                20,
                                30
                            ]
                    },
                    "task_id": 2,
                    "has_paid": 1,
                    "task_data":
                        [
                            {
                                "tag": "工作效率",
                                "video": "https://static.waga.la/video/cc99d1f3b1ba617039eea0180351d1b1.mp4",
                                "detail_id": 18757,
                                "paperwork": "儿童怎么学习英语"
                            }
                        ],
                    "task_type": 3,
                    "has_verify": 0,
                    "create_time": 1744696332,
                    "js_build_id": "292",
                    "task_length": 3,
                    "task_sub_id": 8222,
                    "version_code": "30",
                    "times_stop_begin": 0,
                    "continuous_fail_stop": 12,
                    "task_remind_risk": 0
                }
            ]
        }
        // 确保在处理新任务前清除数据
        let cleanResult = cleanALLLocalData();
    };

    // 声明为全局变量
    globalTask = loadGlobalTask();


    if (isOver) {
        console.log("任务已完成");
        return;
    }

    try {
        console.log("接收到的原始数据:", JSON.stringify(data, null, 2));
        const newTask = data.list[0];

        // 声明为全局变量
        globalTask = loadGlobalTask();

        console.log("加载的本地globalTask:", JSON.stringify(globalTask, null, 2));

        // 检查是否需要提交之前的任务结果
        if (!globalTask || (newTask && newTask.task_sub_id !== globalTask.task_sub_id)) {
            console.log("检测到新任务");
            if (globalTask && globalTask.task_data) {  // 添加额外检查
                console.log("准备上传旧任务结果...");
                try {
                    submitTasks(globalTask, false);
                    console.log("旧任务结果上传完成");
                } catch (e) {
                    if (error.toString().includes("ScriptInterruptedException")) {
                        throw error;
                    }
                    console.error("提交任务失败:", e);                    
                }
                cleanALLLocalData();
            }
            globalTask = newTask;
            saveGlobalTask();
            console.log("新任务已保存:");
        }

        var config = newTask.config;
        console.log("utils.forceStop:", utils.forceStop);
        if (utils.forceStop == true) {
            //未执行的联系人设置为超时失败
            globalTask.task_data.forEach(item => {
                if (typeof item.status !== 'number') {
                    formatResult(item, "强制结束", BusinessErrorCodes.OTHER_FAILED);
                }
            });
            saveGlobalTask();
            return;
        }
        //未登录状态，直接return;
        // goHome();
        // sleep(3000);
        // let startMessaging = textMatches(/(Start Messaging|Comece a Conversar)/).findOne(3000);
        // if (startMessaging) {
        //     console.log("存在Start Messaging,未登录状态");
        //     return;
        // }

        for (var i = 0; i < globalTask.task_data.length; i++) {
            console.log(`开始处理第${i + 1}组消息，共${globalTask.task_data.length}组`);
            try {
                processItemTask(
                    globalTask.task_data[i],
                    config.post_interval,
                    globalTask
                );
            } catch (error) {
                if (error.toString().includes("ScriptInterruptedException")) {
                    throw error;
                }
                console.error(`处理第${i + 1}组消息失败:`, error);
                continue;
            }
            console.log(`第${i + 1}组消息全部完成，进度:${i + 1}/${globalTask.task_data.length}`);
        }
    } catch (e) {
        // 检查是否是脚本中断异常
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("处理任务失败:", e);
    } finally {
        try {
            checkAllTasksCompleted();
        } catch (e) {
            console.error("检查任务完成状态时出错:", e);
        } finally {
            console.log("执行完成");
            isOver = true;
        }
    }
}

function cleanALLLocalData() {
    console.log("开始清除所有本地数据");
    try {

        // 清除全局任务数据
        storage.remove(GLOBAL_TASK_KEY);
        console.log("已清除全局任务数据");

        // 清除消息状态记录
        clearMessageStatuses();

        // 清除账号信息
        storage.remove(ACCOUNT_KEY);
        console.log("已清除账号信息");

        // 直接清除storage对象并重新创建
        storage.clear();

        console.log("所有本地数据已清除");

        // 验证清除结果
        if (storage.get(GLOBAL_TASK_KEY)) {
            console.warn("警告: 数据未能完全清除");
            return false;
        }

        return true;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除本地数据时发生错误:", e);
        console.error("错误堆栈:", e.stack);
        return false;
    }
}

// 修改上传结果函数
function submitTasks(task, isRetry) {
    if (isRetry === undefined) {
        isRetry = true;
    }
    if (!task || !task.task_data) {
        console.error("无效的任务数据，取消上传");
        return;
    }

    const MAX_RETRIES = 2;  // 最大重试次数
    const RETRY_DELAY = 1000;  // 重试间隔时间(毫秒)
    let retryCount = 0;

    while (retryCount < MAX_RETRIES) {
        try {
            console.log(`开始上传任务结果... (尝试 ${retryCount + 1}/${MAX_RETRIES})`);
            var obj = {
                "task_id": task.task_id,
                "has_continuous_fail": 0,
                "task_data": JSON.stringify(task.task_data),
                "ex_account": storage.get(ACCOUNT_KEY) || "",
                "task_sub_id": task.task_sub_id
            };
            console.log("准备上传的任务结果:", JSON.stringify(obj));

            utils.submitTask(obj);
            console.log("任务结果上传成功");
            return;  // 上传成功，退出函数

        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;  // 脚本中断异常直接抛出
            }

            retryCount++;
            console.error(`上传任务失败 (第${retryCount}次): ${e}`);

            if (retryCount < MAX_RETRIES) {
                console.log(`${RETRY_DELAY / 1000}秒后进行第${retryCount + 1}次重试...`);
                sleep(RETRY_DELAY);
            } else {
                console.error("上传任务达到最大重试次数，放弃重试");
                throw e;  // 重试次数用完后抛出最后一次的错误
            }
        }
    }
}


// 设置文本的通用函数
function setTextSafely(selector, text, description) {
    console.log("开始设置文本:", text, description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试设置文本 (第" + (retries + 1) + "次)", description);

            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                console.error("未找到输入框元素", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "未找到输入框元素", description);
            }

            sleep(500);
            element.setText("");
            sleep(200);
            let success = element.setText(text);
            if (!success) {
                console.error("设置文本失败", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "设置文本失败", description);
            }
            console.log("文本设置成功");
            return;
        } catch (e) {
            // 修改中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries < CONFIG.maxRetries) {
                sleep(CONFIG.retryInterval);
                continue;
            }
            throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败: " + e.message, description, true);
        }
    }
    throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败，已达到最大重试次数", description, true);
}

function checkAllTasksCompleted() {
    // 简化检查逻辑，只检查每个联系人的status
    if (globalTask && globalTask.task_data) {
        let allTasksCompleted = globalTask.task_data.every(contact => typeof contact.status === 'number'
        );
        if (allTasksCompleted) {
            console.log("所有任务消息已完成发送,准备上传结果");
            submitTasks(globalTask);
            console.log("上传结果成功");
            cleanALLLocalData();
            console.log("全局任务已清除");
            tools.addStatus(globalTask.pkgName);
            console.log("添加状态成功");
        } else {
            console.log("仍有未完成的消息任务");
        }
    } else {
        console.log("没有任务数据");
    }
}

if (isText) {
    sendSmsList("");
}