var utils = require("./utils.js");
var tools = require("./tools.js");
var storage = storages.create("openstack_google_message_storage");

// 从project.json读取is_debug配置
var isText = JSON.parse(files.read("project.json")).build.is_debug || false;


var context = context || {};
if (!context) {
    throw new Error("Context is not available");
}



var isOver = false;

events.on("say", function (data) {
    console.info('------------------------------say', JSON.stringify(data, null, 2));
    try {
        sendSmsList(data);
    } catch (e) {
        console.error("事件处理发生错误:", e);
    }
});

//保持脚本运行
var runing = setInterval(() => {
    if (isOver) {
        clearInterval(runing);
    }
}, 1000);

// 简化配置对象
const CONFIG = {
    packageName: "com.google.android.apps.messaging",
    activityName: "com.google.android.apps.messaging.main.MainActivity",
    maxRetries: 10,
    retryInterval: 500,
    uiWaitTime: 1000,
    findOneTimeout: 3000
};

// 添加持久化相关的工具函数
const STORAGE_KEY = "google_global_task";

// 添加新的存储键名常量
const MESSAGE_STATUS_KEY = "google_message_status_store";
const ACCOUNT_KEY = "telegram_account";
function saveGlobalTask() {
    try {
        storage.put(STORAGE_KEY, JSON.stringify(globalTask));
        console.log("全局任务已保存到存储");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存全局任务失败:", e);
        throw e;
    }

}


function loadGlobalTask() {
    try {
        const savedTask = storage.get(STORAGE_KEY);
        return savedTask ? JSON.parse(savedTask) : null;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("加载全局任务失败:", e);
        throw e;
    }

}

// 添加消息状态管理的工具函数
function saveMessageStatus(taskSubId, account, messageIndex, status) {
    try {
        const statusKey = `${taskSubId}_${account}_${messageIndex}`;
        let statusStore = storage.get(MESSAGE_STATUS_KEY);
        let statusMap = statusStore ? JSON.parse(statusStore) : {};
        statusMap[statusKey] = status;
        storage.put(MESSAGE_STATUS_KEY, JSON.stringify(statusMap));
        console.log(`保存消息状态: ${statusKey} -> ${status}`);
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存消息状态失败:", e);
    }
}


function getMessageStatus(taskSubId, account, messageIndex) {
    try {
        const statusKey = `${taskSubId}_${account}_${messageIndex}`;

        let statusStore = storage.get(MESSAGE_STATUS_KEY);

        let statusMap = statusStore ? JSON.parse(statusStore) : {};

        let status = statusMap[statusKey] || MessageStatus.PENDING;

        return status;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("获取消息状态失败:", e);
        return MessageStatus.PENDING;
    }

}

function clearMessageStatuses() {
    try {
        storage.remove(MESSAGE_STATUS_KEY);
        console.log("清除所有消息状态记录");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除消息状态失败:", e);
    }
}


// 修改自定义错误类的实现
function OperationError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = true;
    }
    Error.call(this);
    this.name = 'OperationError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

OperationError.prototype = Object.create(Error.prototype);
OperationError.prototype.constructor = OperationError;

// 错误代码常量
const ErrorCodes = {
    APP_LAUNCH_FAILED: 1001,
    ELEMENT_NOT_FOUND: 1002,
    CLICK_FAILED: 1003,
    INPUT_FAILED: 1004,
    CONTACT_LIST_ERROR: 1005,
    CONTACT_SELECT_ERROR: 1006,
    AI_REPLY_FAILED: 1007
};

// 错误代码常量
const BusinessErrorCodes = {
    // 1-成功,2-其他失败 3-账号不存在,4-账号被封,5-APP未登录,6-控件未找到,7-结束语未发送成功,8-AI接口无返回,9-执行账号已被绑定,10-执行账号异常
    SUCCESS: 1,
    OTHER_FAILED: 2,
    ACCOUNT_NOT_EXIST: 3,
    ACCOUNT_BLOCKED: 4,
    APP_NOT_LOGIN: 5,
    ELEMENT_NOT_FOUND: 6,
    END_MESSAGE_FAILED: 7,
    AI_REPLY_FAILED: 8,
    EXECUTION_ACCOUNT_BOUND: 9,
    EXECUTION_ACCOUNT_EXCEPTION: 10
};


// 修改自定义错误类的实现
function BusinessError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = false;
    }
    Error.call(this);
    this.name = 'BusinessError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

BusinessError.prototype = Object.create(Error.prototype);
BusinessError.prototype.constructor = BusinessError;

// 添加消息状态常量
const MessageStatus = {
    PENDING: 'pending',
    SENDED: 'sending',
    SUCCESS: 'success',
    FAILED: 'failed'
};

// 启动Telegram应用
function goHome() {
    console.log("开始启动应用:", CONFIG.packageName);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试启动应用 (第" + (retries + 1) + "次)");
            app.startActivity({
                packageName: CONFIG.packageName,
                className: CONFIG.activityName,
                flags: ["activity_new_task", "activity_clear_task", "activity_clear_top"]
            });
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.APP_LAUNCH_FAILED,
                    "应用启动失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

function openChatWithContact(currentContact) {
    let phoneNumber = currentContact.account;
    console.log("准备直接打开与联系人的聊天:", phoneNumber);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            goHome();
            sleep(2000);

            waitAndClick(id("com.google.android.apps.messaging:id/start_chat_fab"), false, "开始聊天按钮");
            sleep(CONFIG.uiWaitTime);

            editPhoneNumber(phoneNumber);
            sleep(1000);

            clickFirstConcatItem();
            sleep(2000);
            return;
        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("打开聊天界面失败:", e);
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.APP_LAUNCH_FAILED,
                    "打开聊天界面失败: " + e.message
                );
            }
            console.log("第" + (retries + 1) + "次重试打开聊天界面");
            sleep(CONFIG.retryInterval);
        }
    }
}

// 等待并点击元素的通用函数
function waitAndClick(selector, useBounds, description) {
    console.log("开始等待并点击元素", description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                throw new OperationError(
                    ErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 未找到目标元素"
                );
            }

            sleep(500);
            if (useBounds) {
                var bounds = element.bounds();
                if (!bounds) {
                    throw new OperationError(
                        ErrorCodes.ELEMENT_NOT_FOUND,
                        description + " 获取元素边界失败"
                    );
                }
                click(bounds.centerX(), bounds.centerY());
            } else {
                element.click();
            }
            return;

        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new BusinessError(
                    BusinessErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 点击元素失败: " + e.message,
                    true
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

function editPhoneNumber(phoneNumber) {
    console.log("开始输入手机号码:", phoneNumber);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let input = className("android.widget.EditText").findOne(CONFIG.findOneTimeout);
            if (!input) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "未找到输入框"
                );
            }
            input.setText("");
            if (!input.setText(phoneNumber)) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "输入手机号失败"
                );
            }
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new BusinessError(
                    BusinessErrorCodes.ELEMENT_NOT_FOUND,
                    "输入手机号码失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

// 查找联系人函数
function clickFirstConcatItem() {
    console.log("开始点击第一个联系人");
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            // 同时匹配中文和巴西葡萄牙语的文本
            let element = textMatches(/(发送到|Enviar para|Enviar al|اس کو بھیجیں|Ipadala sa|ส่งถึง|इस पर भेजें).*/).findOne();
            if (!element) {
                throw new BusinessError(
                    BusinessErrorCodes.ELEMENT_NOT_FOUND,
                    "未找到联系人选择元素"
                );
            }
            element.parent().click();
            return;
        } catch (e) {
            console.log(e);
            // 添加中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new BusinessError(
                    BusinessErrorCodes.ELEMENT_NOT_FOUND,
                    e instanceof BusinessError ? e.message : "选择联系人失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

// 修改发送消息的核心函数
function sendChatMessage(phoneNumber, message) {
    console.log("开始发送消息给:", phoneNumber);


    // 设置文本消息
    setTextSafely(id("com.google.android.apps.messaging:id/compose_message_text"), message, "发送消息");

    sleep(500);
    waitAndClick(id("Compose:Draft:Send"), true, "发送消息");

    // 记录发送时间并存储到本地
    let sendTime = new Date().getTime();
    storage.put("message_send_time_" + phoneNumber, sendTime);
    console.log("消息发送时间已记录:", sendTime);
}

// 修改处理单个联系人的所有消息函数
function contactSendMessages(contactItem, taskData) {
    console.log("准备发送消息到: " + contactItem.account);

    // 发送联系人的所有消息内容
    for (let i = 0; i < contactItem.text.length; i++) {
        let messageText = contactItem.text[i];
        let currentStatus = getMessageStatus(globalTask.task_sub_id, contactItem.account, i);

        // 跳过已处理的消息
        if (currentStatus === MessageStatus.SUCCESS || currentStatus === MessageStatus.FAILED) {
            console.log(`跳过已处理的消息 ${i}，状态为:`, currentStatus);
            continue;
        }

        console.log(`开始发送消息 ${i}，当前状态:`, currentStatus);
        if (!currentStatus || currentStatus === MessageStatus.PENDING) {
            // 发送消息
            sendChatMessage(contactItem.account, messageText);
            saveMessageStatus(globalTask.task_sub_id, contactItem.account, i, MessageStatus.SENDED);
        }

        let messageSentSuccessfully = checkResultRepeatedly(messageText);
        console.log("消息发送结果:", messageSentSuccessfully ? "成功" : "失败");
        // 更新消息状态

        let newStatus = getMessageStatus(globalTask.task_sub_id, contactItem.account, i);
        if (messageSentSuccessfully) {
            console.log("消息发送成功,设置状态为SUCCESS");
            newStatus = MessageStatus.SUCCESS;
        } else {
            console.log("消息发送失败,设置状态为FAILED");
            newStatus = MessageStatus.FAILED;
        }

        saveMessageStatus(globalTask.task_sub_id, contactItem.account, i, newStatus);
        console.log(`消息状态: ${currentStatus} -> ${newStatus}`);
        // const randomInterval = getRandomInterval(globalTask.config.single_interval);
        // console.log("等待随机间隔时间:", randomInterval, "秒");
        // sleep(randomInterval * 1000);
    }
}

// 格式化结果的辅助函数
function formatResult(contact, message, status) {
    console.log("处理结果:", contact.account, message, status);
    contact.result_text = message;
    contact.result_image = "";
    contact.status = status;
    return contact;
}

function isSayHelloSendFailed(currentContact) {
    // 检查是否有待处理的回复消息或者所有消息都是失败状态
    let allFailed = currentContact.text.every((msg, index) => {
        let status = getMessageStatus(globalTask.task_sub_id, currentContact.account, index);
        return status === MessageStatus.FAILED;
    });
    if (allFailed) {
        console.log("所有打招呼发送失败,设置联系人状态为失败");
        formatResult(currentContact, "发送失败", BusinessErrorCodes.OTHER_FAILED);
        console.log("保存全局任务状态");
        saveGlobalTask();
        return true;
    }
    return false;

}

// 修改处理消息组函数中的间隔处理
function processItemTask(currentContact, account_interval, taskData) {
    let retryCount = 0;
    const MAX_RETRIES = 1;

    while (retryCount <= MAX_RETRIES) {
        try {
            //如果联系人已经有状态，或者所有消息发送失败，则跳过
            if (typeof currentContact.status === 'number' || isSayHelloSendFailed(currentContact)) {
                console.log(`跳过处理: status=${currentContact.status}`);
                return;
            }
            openChatWithContact(currentContact);
            console.log("开始发送消息:", currentContact.account);
            contactSendMessages(currentContact, taskData);

            // 检查是否至少有一条消息发送成功
            let hasAnySuccess = currentContact.text.some((msg, index) => {
                let status = getMessageStatus(globalTask.task_sub_id, currentContact.account, index);
                // SMS 
                return status === MessageStatus.SUCCESS;
            });

            if (hasAnySuccess) {
                console.log("至少有一条消息发送成功,设置联系人状态为成功");
                formatResult(currentContact, "发送成功", 1);
                saveGlobalTask();
            } else {
                console.log("所有消息发送失败,设置联系人状态为失败");
                formatResult(currentContact, "发送失败", BusinessErrorCodes.OTHER_FAILED);
                console.log("保存全局任务状态");
                saveGlobalTask();
            }
            //加入single_interval，取随机数
            let randomInterval = getRandomInterval(config.single_interval);
            sleep(randomInterval * 1000);
            //删除该聊天
            // if (typeof currentContact.status === 'number') {
            //     try {

            //         console.log("点击更多");
            //         descMatches(/(More|Mais|更多|Más|عام|Pangkalahatan|ทั่วไป|सामान्य)/).findOne(1000).parent().click();
            //         sleep(1000);
            //         console.log("点击删除聊天");
            //         findElementByText(/(Delete|Eliminar|حذف کریں|I-delete|ลบ|हटाएं)/).parent().click();
            //         sleep(1000);
            //         console.log("点击删除聊天");
            //         findElementByText(/(Delete|Eliminar|حذف کریں|I-delete|ลบ|हटाएं)/).parent().click();

            //     } catch (e) {
            //         if (e.toString().includes("ScriptInterruptedException")) {
            //             throw e;
            //         }
            //         console.error("删除聊天失败:", e);
            //     }
            // }
            break;
        } catch (innerError) {
            if (innerError.toString().includes("ScriptInterruptedException")) {
                throw innerError;
            }
            console.error(innerError);
            // 检查是否是我们自定义的业务异常
            if (innerError instanceof OperationError) {
                // 检查是否需要重试
                if (!innerError.retryable) {
                    formatResult(currentContact, "发送失败: " + innerError.message, BusinessErrorCodes.OTHER_FAILED);
                    saveGlobalTask();
                    return;
                }
            }

            if (innerError instanceof BusinessError) {
                if (!innerError.retryable) {
                    formatResult(currentContact, "发送失败: " + innerError.message, innerError.code);
                    saveGlobalTask();
                    return;
                }
            }

            // 进入重试逻辑
            retryCount++;
            console.error(`处理失败 (第${retryCount}次)`);
            if (retryCount <= MAX_RETRIES) {
                console.error(innerError);
                console.log(`准备第${retryCount}次重试...`);
                sleep(CONFIG.retryInterval);
                continue;
            }

            formatResult(currentContact, "发送失败: " + innerError.message, innerError instanceof BusinessError ? innerError.code : BusinessErrorCodes.OTHER_FAILED);
            saveGlobalTask();
        }
    }
}

// 主要处理函数
function sendSmsList(data) {

    if (isText) {
        // 更新测试数据
        data = {
            "list": [{
                "name": "TGAI私信 ",
                "app_id": 10,
                "config":
                {
                    "has_paid": 1,
                    "send_timeout": 10,
                    "single_interval":
                        [
                            2,
                            5
                        ],
                    "account_interval":
                        [
                            1,
                            2
                        ]
                },
                "task_id": 15,
                "has_paid": 1,
                "task_data":
                    [
                        {
                            "text":
                                [
                                    "嘿~ 刚刷到你在推特，聊聊？"
                                ],
                            "account": "13098694510",
                            "detail_id": 1826
                        }
                    ],
                "task_type": 8,
                "task_length": 5,
                "task_sub_id": 1316,
                "times_stop_begin": 0,
                "continuous_fail_stop": 0
            }]
        };
        // 确保在处理新任务前清除数据
        let cleanResult = cleanALLLocalData();
    }
    // 声明为全局变量
    globalTask = loadGlobalTask();

    if (isOver) {
        console.log("任务已完成");
        return;
    }

    try {
        console.log("接收到的原始数据:", JSON.stringify(data, null, 2));
        const newTask = data.list[0];

        // 声明为全局变量
        globalTask = loadGlobalTask();

        console.log("加载的本地globalTask:", JSON.stringify(globalTask, null, 2));

        // 检查是否需要提交之前的任务结果
        if (!globalTask || (newTask && newTask.task_sub_id !== globalTask.task_sub_id)) {
            console.log("检测到新任务");
            if (globalTask && globalTask.task_data) {  // 添加额外检查
                console.log("准备上传旧任务结果...");
                try {
                    submitTasks(globalTask, false);
                    console.log("旧任务结果上传完成");
                } catch (e) {
                    console.error("提交任务失败:", e);
                }
                cleanALLLocalData();
            }
            globalTask = newTask;
            saveGlobalTask();
            console.log("新任务已保存:");
        }

        var config = newTask.config;
        console.log("任务配置:", config);

        goHome();
        sleep(5000);
        // try {
        //     goHome();
        //     sleep(5000);

        //     // 点击主页右上角按钮
        //     // waitAndClick(id("com.google.android.apps.messaging:id/selected_account_disc"), false, "点击主页右上角按钮");
        //     // sleep(2000);

        //     // 进入设置页面
        //     // waitAndClick(textMatches(/(信息设置|Configuración de Mensajes|Configurações do Mensagens)/), true, "信息设置");
        //     let recyclerView = null;
        //     let retryCount = 0;
        //     const MAX_RETRIES = 2;

        //     while (retryCount <= MAX_RETRIES) {
        //         recyclerView = id("com.google.android.apps.messaging:id/common_actions").findOne(5 * 1000);
        //         if (recyclerView) {
        //             break;
        //         }
        //         if (retryCount < MAX_RETRIES) {
        //             console.log(`未找到recyclerView，第${retryCount + 1}次滑动重试`);
        //             swipe(device.width / 2, device.height * 0.8, device.width / 2, device.height * 0.6, 500);
        //             sleep(1000);
        //         }
        //         retryCount++;
        //     }

        //     if (!recyclerView) {
        //         throw new Error("未找到recyclerView元素");
        //     }
        //     console.log("recyclerView:", recyclerView);
        //     const info_setting = recyclerView.child(1);
        //     console.log("info_setting:", info_setting);
        //     info_setting.click();
        //     sleep(2000);
        //     try {
        //         waitClick(/(常规|General|Geral|Gerais|عام|Pangkalahatan|ทั่วไป|सामान्य)/, true, "常规");
        //         sleep(2000);
        //     } catch (error) {
        //         console.log("常规未找到");
        //     }
        //     var element = findElementByText(/(RCS 聊天|Chat RCS|Chats RCS|‏RCS چیٹس|Mga RCS chat|แชท RCS|आरसीएस चैट)/, true, "RCS 聊天");
        //     console.log("element:", element);
        //     if (element) {
        //         let bounds = element.parent().bounds();
        //         if (!bounds) {
        //             throw new Error("获取元素边界失败");
        //         }
        //         click(bounds.centerX(), bounds.centerY());
        //     }

        //     // waitClick(/(RCS 聊天|Chats RCS|‏RCS چیٹس|Mga RCS chat|แชท RCS|आरसीएस चैट)/, true, "RCS 聊天");
        //     sleep(5000);

        //     // 检查RCS开关状态
        //     let switcher = id("com.google.android.apps.messaging:id/switchWidget").findOne(5 * 1000);
        //     if (!switcher) {
        //         throw new Error("RCS 聊天开关未找到");
        //     }

        //     if (!switcher.enabled()) {
        //         throw new Error("RCS 聊天开关不可用");
        //     }

        //     let isChecked = switcher.checked();
        //     if (isChecked) {
        //         console.log("RCS 聊天已开启");
        //     } else {
        //         console.log("RCS 聊天未开启,准备开启");
        //         let bounds = switcher.bounds();
        //         if (!bounds) {
        //             throw new Error("获取元素边界失败");
        //         }
        //         click(bounds.centerX(), bounds.centerY());
        //         sleep(2000);
        //         // waitAndClick(text("确定"), true, "确定");
        //         // sleep(2000);
        //         console.log("RCS 聊天已开启");
        //     }
        // } catch (e) {
        //     if (e.toString().includes("ScriptInterruptedException")) {
        //         throw e;
        //     }
        //     console.error("设置RCS聊天失败:", e.message);
        //     //所有任务设置发送失败
        //     globalTask.task_data.forEach(contact => {
        //         formatResult(contact, e.message, BusinessErrorCodes.OTHER_FAILED);
        //     });
        //     saveGlobalTask();
        //     return;
        // }

        for (var i = 0; i < globalTask.task_data.length; i++) {
            console.log(`开始处理第${i + 1}组消息，共${globalTask.task_data.length}组`);
            try {
                processItemTask(
                    globalTask.task_data[i],
                    config.account_interval,
                    globalTask
                );
            } catch (error) {
                if (error.toString().includes("ScriptInterruptedException")) {
                    throw error;
                }
                console.error(`处理第${i + 1}组消息失败:`, error);
                continue;
            }
            console.log(`第${i + 1}组消息全部完成，进度:${i + 1}/${globalTask.task_data.length}`);
        }
    } catch (e) {
        // 检查是否是脚本中断异常
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("处理任务失败:", e);
    } finally {
        try {
            checkAllTasksCompleted();
        } catch (e) {
            console.error("检查任务完成状态时出错:", e);
        } finally {
            console.log("执行完成");
            isOver = true;
        }
    }
}

// 添加一个获取随机间隔的辅助函数
function getRandomInterval(intervalArray) {
    if (!Array.isArray(intervalArray) || intervalArray.length !== 2) {
        console.log("间隔配置无效，使用默认值1秒");
        return 1;
    }
    const [min, max] = intervalArray;
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function waitClick(text, isBoundsClick, description) {
    if (description === undefined) {
        description = "元素";
    }
    let retryCount = 0;
    const MAX_RETRIES = 3;

    while (retryCount < MAX_RETRIES) {
        try {
            let element = findElementByText(text);
            if (element) {
                console.log("找到" + description + "并点击");
                if (isBoundsClick) {
                    let bounds = element.bounds();
                    if (!bounds) {
                        throw new Error("获取元素边界失败");
                    }
                    click(bounds.centerX(), bounds.centerY());
                } else {
                    element.click();
                }
                return true;
            }
            console.log("未找到" + description + ",重试第" + (retryCount + 1) + "次");
            retryCount++;
            sleep(500);
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("查找" + description + "出错:", e);
            retryCount++;
            if (retryCount >= MAX_RETRIES) {
                throw e;
            }
            sleep(500);
        }
    }
    console.log("达到最大重试次数,未找到" + description);
    return false;
}

function findElementByText(text) {
    let retryCount = 0;
    const MAX_RETRIES = 3;

    while (retryCount < MAX_RETRIES) {
        try {
            // 遍历所有节点
            let elements = find();
            for (let element of elements) {
                let elementText = element.text();
                if (!elementText) continue;

                // 检查是否是正则表达式
                if (text instanceof RegExp) {
                    if (text.test(elementText)) {
                        console.log(element.toString());
                        console.log("找到匹配正则表达式" + text + "的元素");
                        return element;
                    }
                } else if (elementText === text) {
                    console.log("找到text为" + text + "的元素");
                    return element;
                }
            }
            console.log("未找到匹配的元素,重试第" + (retryCount + 1) + "次");
            retryCount++;
            sleep(500);
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("查找元素出错:", e);
            retryCount++;
            if (retryCount >= MAX_RETRIES) {
                throw e;
            }
            sleep(500);
        }
    }
    console.log("达到最大重试次数,未找到元素");
    return null;
}

function cleanALLLocalData() {
    console.log("开始清除所有本地数据");
    try {

        // 清除全局任务数据
        storage.remove(STORAGE_KEY);
        console.log("已清除全局任务数据");

        // 清除消息状态记录
        clearMessageStatuses();

        // 清除账号信息
        storage.remove(ACCOUNT_KEY);
        console.log("已清除账号信息");

        // 直接清除storage对象并重新创建
        storage.clear();

        console.log("所有本地数据已清除");

        // 验证清除结果
        if (storage.get(STORAGE_KEY)) {
            console.warn("警告: 数据未能完全清除");
            return false;
        }

        return true;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除本地数据时发生错误:", e);
        console.error("错误堆栈:", e.stack);
        return false;
    }

}

// 修改上传结果函数
function submitTasks(task, isRetry) {
    if (isRetry === undefined) {
        isRetry = true;
    }
    if (!task || !task.task_data) {
        console.error("无效的任务数据，取消上传");
        return;
    }

    const MAX_RETRIES = 2;  // 最大重试次数
    const RETRY_DELAY = 1000;  // 重试间隔时间(毫秒)
    let retryCount = 0;

    while (retryCount < MAX_RETRIES) {
        try {
            console.log(`开始上传任务结果... (尝试 ${retryCount + 1}/${MAX_RETRIES})`);
            var obj = {
                "task_id": task.task_id,
                "has_continuous_fail": 0,
                "task_data": JSON.stringify(task.task_data),
                "ex_account": storage.get(ACCOUNT_KEY) || "",
                "task_sub_id": task.task_sub_id
            };
            console.log("准备上传的任务结果:", JSON.stringify(obj));
            console.log("准备上传的任务结果00:", task.task_data);

            utils.submitTask(obj);
            console.log("任务结果上传成功");
            return;  // 上传成功，退出函数

        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;  // 脚本中断异常直接抛出
            }

            retryCount++;
            console.error(`上传任务失败 (第${retryCount}次): ${e}`);

            if (retryCount < MAX_RETRIES) {
                console.log(`${RETRY_DELAY / 1000}秒后进行第${retryCount + 1}次重试...`);
                sleep(RETRY_DELAY);
            } else {
                console.error("上传任务达到最大重试次数，放弃重试");
                throw e;  // 重试次数用完后抛出最后一次的错误
            }
        }
    }
}


// 设置文本的通用函数
function setTextSafely(selector, text, description) {
    console.log("开始设置文本:", text, description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试设置文本 (第" + (retries + 1) + "次)", description);

            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                console.error("未找到输入框元素", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "未找到输入框元素", description);
            }

            sleep(500);
            element.setText("");
            sleep(200);
            let success = element.setText(text);
            if (!success) {
                console.error("设置文本失败", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "设置文本失败", description);
            }
            console.log("文本设置成功");
            return;
        } catch (e) {
            // 修改中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries < CONFIG.maxRetries) {
                sleep(CONFIG.retryInterval);
                continue;
            }
            throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败: " + e.message, description, true);
        }
    }
    throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败，已达到最大重试次数", description, true);
}

function checkResultRepeatedly(messageText) {
    let messageSentSuccessfully = false;
    const MAX_WAIT_TIME = globalTask.config.send_timeout; // 最大等待时间为5秒
    let elapsedTime = 0;

    while (elapsedTime < MAX_WAIT_TIME) {
        sleep(1000); // 每秒检查一次
        messageSentSuccessfully = checkSendResult({ text: messageText });
        if (messageSentSuccessfully) {
            break; // 如果成功，跳出循环
        }
        elapsedTime++;
    }
    return messageSentSuccessfully;
}

function checkSendResult(messageItem) {
    let retryAttempts = 0;
    const MAX_RETRIES = 3;



    while (retryAttempts < MAX_RETRIES) {
        try {
            console.log("获取状态1111：");


            if (false) {
                if (lastMessage.findOne(textContains("已发送"))) {
                    return true;
                }
                return false;
            } else {
                // 获取当前可见的消息
                let messageElements = text(messageItem.text).find();
                console.log("找到的元素:", messageElements.length);
                for (let bundle of messageElements) {
                    if (!bundle) {
                        console.log("消息元素为空,跳过处理");
                        continue;
                    }
                    let id = bundle.id();
                    if (id != "message_text") {
                        continue;
                    }

                    let currentText = bundle.text();
                    let desc = bundle.desc();

                    if (currentText === messageItem.text &&
                        (desc.startsWith("您说  " + messageItem.text) ||
                            desc.startsWith("Has dicho: " + messageItem.text) ||
                            desc.startsWith("आपने कहा" + messageItem.text) ||
                            desc.startsWith("Você disse" + messageItem.text) ||
                            desc.startsWith("คุณพูดว่า" + messageItem.text) ||
                            desc.startsWith("Ang sabi mo" + messageItem.text) ||
                            desc.startsWith("پ نے کہا" + messageItem.text) ||
                            desc.startsWith("Você disse  " + messageItem.text) ||
                            desc.startsWith("You said  " + messageItem.text))) {
                        return true;
                    }
                }
                console.log("未找到匹配的消息");
                return false;
            }
        } catch (e) {
            // 检查脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("检查消息结果时发生错误:", e);
            retryAttempts++;
            if (retryAttempts >= MAX_RETRIES) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "检查消息结果失败: " + e.message);
            }
            sleep(CONFIG.retryInterval);
        }
    }
}
function checkAllTasksCompleted() {
    // 简化检查逻辑，只检查每个联系人的status
    if (globalTask && globalTask.task_data) {
        let allTasksCompleted = globalTask.task_data.every(contact => typeof contact.status === 'number'
        );
        if (allTasksCompleted) {
            console.log("所有任务消息已完成发送,准备上传结果");
            submitTasks(globalTask);
            console.log("上传结果成功");
            cleanALLLocalData();
            console.log("全局任务已清除");
            tools.addStatus(globalTask.pkgName);
            console.log("添加状态成功");
        } else {
            console.log("仍有未完成的消息任务");
        }
    } else {
        console.log("没有任务数据");
    }
}

if (isText) {
    sendSmsList("");
}