var tools = require("./tools.js");
var utils = require("./utils.js");
var pkgName = "com.whatsapp";
var config = {};
var tmpTaskList = [];
var isContinueFail = 0;
var instance = {};
var task_id = 0;
var app_id = 0;
var isOver = false;


var fadeData = ` [{
            "name": "TGAI私信 ",
            "app_id": 10,
            "config":
            {
                "has_paid": 1,
                "reply_timeout": 1,
                "single_interval":
                    [
                        2,
                        5
                    ],
                "account_interval":
                    [
                        1,
                        2
                    ]
            },
            "task_id": 15,
            "has_paid": 1,
            "task_data":
                [
                    {
                        "text":
                            [
                                "嘿~ 刚刷到你在推特，聊聊？"
                            ],
                        "account": "+55 11 94603-3714",
                        "detail_id": 1826
                    }
                ],
            "task_type": 8,
            "task_length": 5,
            "task_sub_id": 1316,
            "times_stop_begin": 0,
            "continuous_fail_stop": 0
        }]`;

var fakeContent = ["Olá~ Acabei de ver você no Twitter, quer bater um papo?",
   "Ouvi dizer que esse lugar é divertido. Por que você não dá uma olhada?",
   "Há muitas comidas deliciosas aqui~",
   "Pode",
   "Sem chance! ! Você não ouviu falar dessa animação? ! ! !",
   "Sem problemas",
   "Todas as manhãs quando acordo, sou grato pela sua companhia 🌅✨.",
   "Bom dia, vamos saudar o novo dia juntos com belas expectativas em nossos corações 🌞🌈.",
   "mas...",
   "Bom dia! Espero que tudo corra como você deseja hoje e que tudo seja repleto de icidade e alegria! 🥰🌻.",
   "Desejo a você um dia cheio de energia positiva e que comece o novo dia com total alidade 💪😊.",
   "Bom dia! Você é a pessoa mais especial do meu coração, desejo-lhe um bom dia! 💖✨.",
   "bom",
   "Ao amanhecer, desejo a você um dia feliz e alegre. 🌟🌱.",
   "Bom dia! Que seu dia seja repleto de bênçãos e alegrias, e que você aproveite cada momento dele! 🎉😄",
   "O sol da manhã também é minha saudação para você, que você tenha um dia maravilhoso ☀️💕.",
   "Bom dia! Cada manhã é um novo milagre. Vamos saudar o novo dia com confiança! 🌈🌼.",
   " Acorde cedo, que você sorria todos os dias e comece o dia com gratidão e carinho! 😊🌸.",
   "Ok, eu entendo",
   "Pode",
   "mas...",
   "Sem problemas",
   "Mas!",
   `${random(1, 3000)}`,
];

events.on("say", function (param) {
   instance.handle(param.list);
});

var runing = setInterval(() => {
   if (isOver) {
      clearInterval(runing);
   }
}, 1000);

instance.handle = function (taskList) {
   try {
      // var taskFinishCount = 0;
      tmpTaskList = tools.storage.get("whatsapp", []);
      console.info("获取本地缓存", tmpTaskList);
      console.info("传入数据 =>\n", taskList);
      // 提交旧数据/ 赋值新任务
      if (tmpTaskList.length > 0) {
         tmpTaskList.forEach((item, index) => {
            try {
               if (item.task_sub_id != taskList[index].task_sub_id) {
                  console.log("提交旧任务：", item.task_sub_id, taskList[index].task_sub_id);
                  submitRes(index);
                  tmpTaskList[index] = taskList[index];
               }
            } catch (error) {

            }
         })
      } else {
         tmpTaskList = taskList;
      }

      // 执行任务
      tmpTaskList.forEach((item, i) => {
         config = item.config;
         // 执行所有人
         exeAll(item, i);
         // 提交前，检查一边失败的，提高成功率
         recheckFailed(item, i);
         console.log("提交任务", i);
         submitRes(i);
      })
      isOver = true;
   } catch (error) {
      isOver = true;
      tools.storage.put("whatsapp", tmpTaskList);
      console.error("运行中报错，保存数据::::", error);
      // submitRes(-1);
      // engines.myEngine().forceStop();
   }
}

function checkRes(res, i, j) {
   if (res == -4) {
      console.log(`(s=${res}) 控件未找到`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 6;
      tmpTaskList[i].task_data[j].result_text = "控件未找到";
   }
   if (res == 100) {
      console.log(`(s=${res}) 成功`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 1;
      tmpTaskList[i].task_data[j].result_text = "成功";
   }
   if (res == -10) {
      console.log(`(s=${res}) 账号被禁`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "账号被禁";
      tmpTaskList[i].task_data[j].status = 4;
      isOver = true;
   }
   if (res == -11) {
      console.log(`(s=${res})未登录Ws`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 5;
      tmpTaskList[i].task_data[j].result_text = "未登录WS";
      isOver = true;
   }
   if (res == -20) {
      console.log(`(s=${res}) 目标账号不存在`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "目标账号不存在";
      tmpTaskList[i].task_data[j].status = 3;
   }
   if (tmpTaskList[i].task_data[j].taskFinish) { } else {
      console.log(`(s=${res}) 失败`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 2;
      tmpTaskList[i].task_data[j].result_text = "失败";
   }
   tools.storage.put("whatsapp", tmpTaskList);
}

function recheckFailed(item, i) {
   item.task_data.forEach((data, j) => {
      console.log("检查失败", tmpTaskList[i].task_data[j].status, tmpTaskList[i].task_data[j].result_text);
      if (tmpTaskList[i].task_data[j].status == 2) {
         let res = exeTask(data, i, j);
         checkRes(res, i, j);
      }
   })
}

function exeAll(item, i) {
   item.task_data.forEach((data, j) => {
      console.log("任务-", i, j, "数据", tmpTaskList[i].task_data[j])
      if (tmpTaskList[i].task_data[j].taskFinish) { } else {
         let res = exeTask(data, i, j);
         console.log("结果：", res);
         if (res == -4 || res == -5) {
            res = exeTask(data, i, j);
         }
         checkRes(res, i, j);
      }
      console.log("执行完一个", i, j);
   })
}

function checkSuccess(indexI, indexJ) {
   oneData = tmpTaskList[indexI].task_data[indexJ];
   if (oneData.reason != -2) {
      return;
   }
   console.info("******一检：当前账号：", oneData.account);
   console.log("******一检：当前失败原因", oneData.result_text);
   launchApp();
   let userListNode = packageName(pkgName).descStartsWith("Conversas").drawingOrder("1").findOne(5000);
   if (userListNode) {
      if (!userListNode.isSelected()) {
         userListNode.select();
         sleep(500);
      }

      let addTagNode = id("com.whatsapp:id/fab").findOne(5000);
      if (!addTagNode) {
         addTagNode = id("com.whatsapp:id/fabText").findOne(5000);
      }
      if (addTagNode) {
         addTagNode.click();
         sleep(500);
         let selfNode = textEndsWith("(você)").findOne(5000);
         if (selfNode) {
            let selfName = selfNode.text();
            tmpTaskList[i].ex_account = selfName.substring(0, selfName.indexOf(" (você)"));
            console.log("自己账号:", tmpTaskList[i].ex_account, selfName);
            tools.storage.put("whatsapp", tmpTaskList);
            click("(você)");
            sleep(500);
            let inputNode = className("android.widget.EditText").findOne(5000);
            if (inputNode) {
               // console.log(onedata.account);
               inputNode.setText(oneData.account);
               sleep(500);
               let sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (sendNode) {
                  sendNode.click();
                  sleep(500);
                  let targetNode = desc(oneData.account).className("android.view.View").findOne(5000);
                  if (targetNode) {
                     targetNode.click();
                     sleep(3000);
                     let noWs = textStartsWith("Ligar para").findOne(5000);
                     if (noWs == null) {
                        let targetCallNode = textStartsWith("Conversar").clickable(true).findOne(20000);
                        if (targetCallNode) {
                           targetCallNode.click();
                           sleep(500);
                           let isSuccessNode = id("com.whatsapp:id/status").find();
                           if (isSuccessNode) {
                              if (isSuccessNode.length - 1 < 0) {
                                 console.info("******一检:仍然失败");
                                 oneData.taskFinish = true;
                                 oneData.account_already_send = false;
                                 oneData.result_text = "首轮消息发送失败";
                                 oneData.reason = -110;
                                 return -110;
                              }
                              let child = isSuccessNode.get(isSuccessNode.length - 1);
                              let descStutas = child.desc();
                              if (descStutas == "Enviada" || descStutas == "Lida" || descStutas == "Entregue") {
                                 console.info("******一检:发送成功");
                                 tmpTaskList[indexI].task_data[indexJ].lastMessageMills = new Date().getTime();
                                 tmpTaskList[indexI].task_data[indexJ].account_already_send = true;
                                 tmpTaskList[indexI].task_data[indexJ].reason = 99;
                                 tools.storage.put("whatsapp", tmpTaskList);
                                 sleep(3000);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }
}

function findAccount() {
   try {
      var accountStr = "";
      let tabBarMenu = id("com.whatsapp:id/menuitem_overflow").findOne(5000);
      tabBarMenu.click();
      sleep(1000);
      let root = className("android.widget.ListView").findOne(5000);
      sleep(1000);
      root.children().each(function (child) {
         if (child.className() === "android.widget.LinearLayout") {
            let textNode = child.findOne(id("com.whatsapp:id/title"));
            if (textNode && textNode.text() === "Configurações") {
               child.click();
            }
         }
      });
      sleep(1000);
      let accountNode = id("com.whatsapp:id/profile_info").findOne(5000);
      if (accountNode) {
         accountNode.click();
         sleep(500);
         let teleRootNode = id("com.whatsapp:id/profile_phone_info").findOne(5000);
         if (teleRootNode) {
            let teleNode = teleRootNode.findOne(id("com.whatsapp:id/profile_settings_row_subtext"));
            if (teleNode) {
               accountStr = teleNode.text();
               console.log("获取到当前账号手机号码:", accountStr);
               return accountStr;
            }
         }
      } else {
         console.log("未找到设置按钮:默认继续执行");
      }
      return null;
   } catch (error) {
      console.error("绑定过程中发生错误:默认继续执行", error);
      return null;
   }
}

// 删除聊天对话
function deleteTaskContent() {
   try {
      console.log("deleteTaskContent-", 1);
      let tabBarMenu = id("com.whatsapp:id/menuitem_overflow").findOne(5000);
      tabBarMenu.click();
      console.log("deleteTaskContent-", 2);
      sleep(1000);
      let root = className("android.widget.ListView").findOne(5000);
      sleep(1000);
      root.children().each(function (child) {
         if (child.className() === "android.widget.LinearLayout") {
            if (child.findOne(id("com.whatsapp:id/title")).text() === "Mais") {
               child.click();
            }
         }
      });
      console.log("deleteTaskContent-", 3);
      sleep(1000);
      let root2 = className("android.widget.ListView").findOne(5000);
      console.log("deleteTaskContent-", 4);
      sleep(1000);
      root2.children().each(function (child) {
         if (child.className() === "android.widget.LinearLayout") {
            let textNode = child.findOne(id("com.whatsapp:id/title"));
            if (textNode && textNode.text() === "Limpar conversa") {
               child.click();
            }
         }
      });
      console.log("deleteTaskContent-", 5);
      let checkBoxContainer = id("com.whatsapp:id/delete_media_checkbox").findOne(5000);
      let checkBox = id("com.whatsapp:id/delete_media_checkbox").findOne(5000);
      if (checkBoxContainer) {
         if (checkBox.isSelected() == false) {
            checkBoxContainer.click();
         }
         sleep(1000);
         console.log("deleteTaskContent-", 6);
         let deleteNode = id("android:id/button1").findOne(5000);
         if (deleteNode) {
            deleteNode.click();
            console.log("deleteTaskContent-", "finish");
            sleep(500);
         }
      }
   } catch (e) {
      console.error("删除对话失败", e);
   }
}


function randomNum(minNum, maxNum) {
   return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}

function submitRes(i) {
   let res = {};
   res.task_id = tmpTaskList[i].task_id;
   res.task_sub_id = tmpTaskList[i].task_sub_id;
   res.ex_account = tmpTaskList[i].ex_account;
   res.has_continuous_fail = isContinueFail;
   res.task_data = JSON.stringify(tmpTaskList[i].task_data);
   console.error("提交数据", res);
   let result = utils.submitTask(res);
   console.log("提交结果", result);
   tools.storage.remove("whatsapp");
   tmpTaskList = [];
}

function submitBlocked(i) {
   let res = {};
   res.app_id = tmpTaskList[i].app_id;

   utils.submitBlocked(res, function () {
      tools.addStatus(tmpTaskList[i].pkgName);
      console.log("账号被封禁提交成功");
   });
}

function deleteUserList() {
   // try {
   back();
   back();
   sleep(500);
   let selfNode = textEndsWith(")").findOne(5000);
   if (selfNode) {
      longClick(")");
      let selfNodeRect = selfNode.bounds();
      let deleteTargetNode = id("com.whatsapp:id/conversations_row_contact_name").find();
      deleteTargetNode.each(function (child) {
         let childRect = child.bounds();
         if (childRect.centerY() < selfNodeRect.centerY()) {
            console.log(child.text());
            click(child.text());
            sleep(500);
         }
      });

      let pinNode = id("com.whatsapp:id/menuitem_conversations_pin").findOne(5000);
      if (pinNode) {
         let deleteRect = pinNode.bounds();
         click(deleteRect.centerX() + deleteRect.width(), deleteRect.centerY());
         sleep(1000);
         let deleteNode = descStartsWith("Apagar").findOne(5000);
         if (deleteNode) {
            deleteNode.click();
            console.log("0=====  delete success");
            return;
         } else {
            console.warn("3=====  delete step  3");
         }
      } else {
         console.warn("2=====  delete step  2");
      }
   } else {
      console.warn("1=====  delete step  1");
   }
   // } catch (error) {
   //    console.warn("-1=====  delete  exp", error);
   // }
}


function sendMsg(data, i, j) {
   try {
      console.log("sendMsg:-1", data, data.text);
      let isScuccess = false;
      if (data.text && data.text.length > 0) {
         let inputNode = id("com.whatsapp:id/entry").findOne(5000);
         if (!inputNode) {
            return -4;
         }
         console.log("sendMsg:-2");
         data.text.forEach((item, index) => {
            console.log("sendMsg:", tmpTaskList[i].task_data[j].sendIndex, item, index);
            if (tmpTaskList[i].task_data[j].sendIndex && index < tmpTaskList[i].task_data[j].sendIndex) { } else {
               inputNode.setText(item);
               sleep(500);
               var sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (sendNode && sendNode.click()) {
                  sleep(500);
                  tmpTaskList[i].task_data[j].sendIndex = index + 1;
                  tools.storage.put("whatsapp", tmpTaskList);
               }
               let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
               sleep(randTime * 1000);
            }
         })
         console.log("sendMsg:-3", tmpTaskList[i].task_data[j].sendIndex);

         sleep(config.send_timeout * 1000);

         if (tmpTaskList[i].task_data[j].sendIndex) {
            console.log("检查节点：00000");
            let isSuccessNode = id("com.whatsapp:id/status").find();
            console.log("检查节点：111111");
            let checkNodes = isSuccessNode.slice((tmpTaskList[i].task_data[j].sendIndex + 1) * -1);
            console.log("检查节点：222222");
            console.log("检查节点：", checkNodes);

            checkNodes.forEach(function (child) {
               let descStutas = child.desc();
               console.log("状态", descStutas, data.account);
               if (descStutas == "Enviada" || descStutas == "Lida" || descStutas == "Entregue") {
                  // tmpTaskList[i].task_data[j].taskFinish = true;
                  // tools.storage.put("whatsapp", tmpTaskList);
                  console.log("sendMsg:", 3);
                  isScuccess = true;
                  return;
               }
            });
         }
      }
      if (data.video && data.video.length > 0) {
         data.video.forEach((item, index) => {
            if (tmpTaskList[i].task_data[j].sendIndexVideo && index <= tmpTaskList[i].task_data[j].sendIndexVideo) { } else {
               let downFileName = tools.downloadFiles(item);
               if (downFileName == "") {
                  videoOkNum = -1;
                  console.log("1=====  send msg  download video failed");
                  return;
               }

               var attachNode = id("com.whatsapp:id/input_attach_button").findOne(5000);
               if (!attachNode) {
                  return;
               }
               attachNode.click();
               sleep(500);

               var medioNode = id("com.whatsapp:id/pickfiletype_gallery_holder").findOne(5000);
               if (!medioNode) {
                  return;
               }
               medioNode.click();
               sleep(500);

               var targeVidowtNode = idContains("com.whatsapp:string/(name removed)").findOne(5000);
               if (!targeVidowtNode) {
                  return;
               }
               targeVidowtNode.click();
               sleep(500);

               var sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (!sendNode) {
                  return;
               }
               sendNode.click();
               sleep(500);
               tmpTaskList[i].task_data[j].sendIndexVideo = index;

               let randTime = randomNum(config.single_interval[0], config.single_interval[1])
               sleep(randTime * 1000);
            }


            // for (var i = 0; i < oneData.video.length; i++) {
            //    if (oneData.videoRecordNum && oneData.videoRecordNum >= i) { continue; }
            //    let downFileName = tools.downloadFiles(oneData.video[i]);
            //    if (downFileName == "") {
            //       videoOkNum = -1;
            //       console.log("1=====  send msg  download video failed");
            //       break;
            //    }
            //    var attachNode = id("com.whatsapp:id/input_attach_button").findOne(5000);
            //    if (attachNode) {
            //       attachNode.click();
            //       sleep(500);
            //       var medioNode = id("com.whatsapp:id/pickfiletype_gallery_holder").findOne(5000);
            //       if (medioNode) {
            //          medioNode.click();
            //          sleep(500);
            //          var targeVidowtNode = idContains("com.whatsapp:string/(name removed)").findOne(5000);
            //          if (targeVidowtNode) {
            //             targeVidowtNode.click();
            //             sleep(500);
            //          }
            //          var sendNode = id("com.whatsapp:id/send").findOne(5000);
            //          if (sendNode) {
            //             if (sendNode.click()) {
            //                tmpTaskList[indexI].task_data[indexJ].videoRecordNum = i + 1;
            //                tools.storage.put("whatsapp", tmpTaskList);
            //             }
            //          } console.log("4=====  send msg  video 4");
            //       } else {
            //          console.log("3=====  send msg  video 3");
            //       }
            //    } else {
            //       console.log("2=====  send msg video 2");
            //    }
            //    // delete download imgs
            //    tools.deleteDownloadFiles(downFileName);
            //    console.log("5=====  send msg vedio video 5");
            //    let randTime = randomNum(config.single_interval[0], config.single_interval[1])
            //    console.info(`单条私信间隔[${config.single_interval[0]}-${config.single_interval[1]}] --- 当前[${randTime}秒]`);
            //    sleep(randTime * 1000);
            // }
            // sleep(50 * 1000);
            // let isSuccessNode = id("com.whatsapp:id/status").find();
            // if (tmpTaskList[indexI].task_data[indexJ].videoRecordNum) {
            //    if (isSuccessNode.length >= tmpTaskList[indexI].task_data[indexJ].videoRecordNum) {
            //       let checkNodes = isSuccessNode.slice(tmpTaskList[indexI].task_data[indexJ].videoRecordNum * -1);
            //       checkNodes.forEach(function (child) {
            //          let descStutas = child.desc();
            //          console.log("status:::", descStutas, oneData.account);
            //          if (descStutas == "Enviada" || descStutas == "Lida" || descStutas == "Entregue") {
            //             videoOkNum++;
            //          }
            //       });
            //    }
            //    console.log("成功发送视频数量：" + videoOkNum);
            // } else {
            //    console.log("发送视频异常videoRecordNum为空");
            // }
         })
      }
      if (data.image) {
         if (data.image.length > 0) {
            data.image.forEach(() => {

            })
         }
      }
      if (isScuccess) {
         return 100;
      }
      return -5;
   } catch (error) {
      console.log(error);
      return -4;
   }


   console.info("发送第一轮消息");
   let textOkNum = 0;
   let videoOkNum = 0;
   let imageOkNum = 0;
   // try {
   let inputNode = id("com.whatsapp:id/entry").findOne(5000);
   if (inputNode) {
      if (oneData.text) {
         for (var i = 0; i < oneData.text.length; i++) {
            if (tmpTaskList[indexI].task_data[indexJ].textRecordNum && tmpTaskList[indexI].task_data[indexJ].textRecordNum > i) {
               console.info(`一轮对话[${i}]已发送`);
               continue;
            } else {
               console.info(`一轮对话[${i}]待发送`);
            }

            inputNode.setText(oneData.text[i]);
            var sendNode = id("com.whatsapp:id/send").findOne(5000);
            if (sendNode) {
               if (sendNode.click()) {
                  tmpTaskList[indexI].task_data[indexJ].textRecordNum = i + 1;
                  tools.storage.put("whatsapp", tmpTaskList);
                  console.info("发送文案：", oneData.text[i]);
               }
            }
            let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
            console.info(`单条私信间隔[${config.single_interval[0]}-${config.single_interval[1]}] --- 当前[${randTime}秒]`);
            sleep(randTime * 1000);
         }
         sleep(8000);
         let isSuccessNode = id("com.whatsapp:id/status").find();
         console.log("发送条数：", isSuccessNode.length);
         if (tmpTaskList[indexI].task_data[indexJ].textRecordNum) {
            if (isSuccessNode.length >= tmpTaskList[indexI].task_data[indexJ].textRecordNum) {
               let checkNodes = isSuccessNode.slice(tmpTaskList[indexI].task_data[indexJ].textRecordNum * -1);
               checkNodes.forEach(function (child) {
                  let descStutas = child.desc();
                  console.log("状态", descStutas, oneData.account);
                  if (descStutas == "Enviada" || descStutas == "Lida" || descStutas == "Entregue") {
                     textOkNum++;
                  }
               });
            };
            console.log("成功发送文本数量：" + textOkNum);
         } else {
            console.log("发送文本异常textRecordNum为空");
         }
      }
      if (oneData.video) {
         console.log("vieow :：", oneData.video);
         for (var i = 0; i < oneData.video.length; i++) {
            if (oneData.videoRecordNum && oneData.videoRecordNum >= i) { continue; }
            let downFileName = tools.downloadFiles(oneData.video[i]);
            if (downFileName == "") {
               videoOkNum = -1;
               console.log("1=====  send msg  download video failed");
               break;
            }
            var attachNode = id("com.whatsapp:id/input_attach_button").findOne(5000);
            if (attachNode) {
               attachNode.click();
               sleep(500);
               var medioNode = id("com.whatsapp:id/pickfiletype_gallery_holder").findOne(5000);
               if (medioNode) {
                  medioNode.click();
                  sleep(500);
                  var targeVidowtNode = idContains("com.whatsapp:string/(name removed)").findOne(5000);
                  if (targeVidowtNode) {
                     targeVidowtNode.click();
                     sleep(500);
                  }
                  var sendNode = id("com.whatsapp:id/send").findOne(5000);
                  if (sendNode) {
                     if (sendNode.click()) {
                        tmpTaskList[indexI].task_data[indexJ].videoRecordNum = i + 1;
                        tools.storage.put("whatsapp", tmpTaskList);
                     }
                  } console.log("4=====  send msg  video 4");
               } else {
                  console.log("3=====  send msg  video 3");
               }
            } else {
               console.log("2=====  send msg video 2");
            }
            // delete download imgs
            tools.deleteDownloadFiles(downFileName);
            console.log("5=====  send msg vedio video 5");
            let randTime = randomNum(config.single_interval[0], config.single_interval[1])
            console.info(`单条私信间隔[${config.single_interval[0]}-${config.single_interval[1]}] --- 当前[${randTime}秒]`);
            sleep(randTime * 1000);
         }
         sleep(50 * 1000);
         let isSuccessNode = id("com.whatsapp:id/status").find();
         if (tmpTaskList[indexI].task_data[indexJ].videoRecordNum) {
            if (isSuccessNode.length >= tmpTaskList[indexI].task_data[indexJ].videoRecordNum) {
               let checkNodes = isSuccessNode.slice(tmpTaskList[indexI].task_data[indexJ].videoRecordNum * -1);
               checkNodes.forEach(function (child) {
                  let descStutas = child.desc();
                  console.log("status:::", descStutas, oneData.account);
                  if (descStutas == "Enviada" || descStutas == "Lida" || descStutas == "Entregue") {
                     videoOkNum++;
                  }
               });
            }
            console.log("成功发送视频数量：" + videoOkNum);
         } else {
            console.log("发送视频异常videoRecordNum为空");
         }
      }
      if (oneData.image) {
         console.log("images", oneData.image);
         for (var i = 0; i < oneData.image.length; i++) {
            if (oneData.imageRecordNum && oneData.imageRecordNum >= i) { continue; }
            let downFileName = tools.downloadFiles(oneData.image[i]);
            if (downFileName == "") {
               imageOkNum = -1;
               console.log("1=====  send msg  download image failed");
               break;
            }
            var attachNode = id("com.whatsapp:id/input_attach_button").findOne(5000);
            if (attachNode) {
               attachNode.click();
               sleep(500);
               var medioNode = id("com.whatsapp:id/pickfiletype_gallery_holder").findOne(5000);
               if (medioNode) {
                  medioNode.click();
                  sleep(500);
                  var targeVidowtNode = idContains("com.whatsapp:string/(name removed)").findOne(5000);
                  if (targeVidowtNode) {
                     targeVidowtNode.click();
                     sleep(500);
                  }
                  var sendNode = id("com.whatsapp:id/send").findOne(5000);
                  if (sendNode) {
                     if (sendNode.click()) {
                        tmpTaskList[indexI].task_data[indexJ].imageRecordNum = i + 1;
                        tools.storage.put("whatsapp", tmpTaskList);
                     }
                  } else {
                     console.log("3=====  send msg image 3");
                  }
               } else {
                  console.log("2=====  send msg image 2");
               }
            } else {
               console.log("1=====  send msg image 1");
            }
            // delete download imgs
            tools.deleteDownloadFiles(downFileName);
            console.log("6=====  send msg image 6");
            let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
            console.info(`单条私信间隔[${config.single_interval[0]}-${config.single_interval[1]}] --- 当前[${randTime}秒]`);
            sleep(randTime * 1000);
         }
         sleep(30 * 1000);
         let isSuccessNode = id("com.whatsapp:id/status").find();
         if (tmpTaskList[indexI].task_data[indexJ].imageRecordNum) {
            if (isSuccessNode.length >= imageOkNum) {
               let checkNodes = isSuccessNode.slice(imageOkNum * -1);
               checkNodes.forEach(function (child) {
                  let descStutas = child.desc();
                  if (descStutas == "Enviada" || descStutas == "Lida" || descStutas == "Entregue") {
                     imageOkNum++;
                  }
               });
            }
            console.log("成功发送图片数量：" + imageOkNum);
         } else {
            console.log("发送图片异常imageRecordNum为空");
         }
      }
   }
   // setLastIndex(oneData);
   if (textOkNum > 0 || videoOkNum > 0 || imageOkNum > 0) {
      console.log(`首条推广已发送：textOkNum|${textOkNum} videoOkNum|${videoOkNum} imageOkNum|${imageOkNum}`);
      return 99
   }
   return -2;
   // } catch (error) {
   //    console.log("-1=====  send msg  exp", error);
   //    return -1;
   // }
}

var retryNum = 2;
function reGetTarget(data, i, j, maxNum) {
   back();
   if (maxNum < 1) return -20;

   var result = utils.redistributionWs(tmpTaskList[i].task_sub_id, data.detail_id);
   if (result == -100) {
      console.log('重新分配账号接口');
      return -20;
   }
   if (result == -2) {
      console.log('重试3次后重新分配账号仍然失败');
      return -20;
   }
   data.account = result;
   let inputNode = className("android.widget.EditText").findOne(5000);
   if (!inputNode) {
      return -4;
   }
   inputNode.setText(data.account);
   sleep(1000);

   console.log(5);
   let sendNode = id("com.whatsapp:id/send").findOne(5000);
   if (sendNode == null) {
      sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
   }
   if (!sendNode) {
      return -4;
   }
   sendNode.click();
   sleep(500);

   console.log(6);
   let targetNode = desc(data.account).className("android.view.View").findOne(5000);
   if (!targetNode) {
      return -4;
   }
   targetNode.click();
   sleep(3000);

   console.log(7);
   let targetCallNode = textStartsWith("Conversar").clickable(true).findOne(25000);
   if (!targetCallNode) {
      console.log("目标号码不存在", data.account);
      // let noWsNode = textStartsWith("Ligar para").findOne(5000);
      // if (noWsNode) {
      //    console.log("目标号码不存在", data.account);
      //    // return -20;
      //    return reGetTarget(data, i, j, maxNum - 1);
      // }
      return reGetTarget(data, i, j, maxNum - 1);
   }
   targetCallNode.click();
   sleep(500);

   let tmpCheckNode = id("com.whatsapp:id/ephemeral_nux_ok").findOne(2000);
   if (tmpCheckNode) {
      tmpCheckNode.click();
   }

   console.log(8);
   return sendMsg(data, i, j);
}
//  exe task
function exeTask(data, i, j) {

   console.log("打开执行");
   launchApp();
   sleep(random(3000, 5000));
   while (true) {
      console.log(1);
      let userListNode = packageName(pkgName).descStartsWith("Conversas").findOne(10000);
      if (!userListNode) {
         let notAccountNode = textStartsWith("Esta conta não").findOne(2000);
         if (notAccountNode) {
            console.info("账号被封");
            return -10;
         }
         console.log("第一步没找到111111");
         let notLoginNode = text("CONCORDAR E CONTINUAR").findOne(2000);
         if (notLoginNode) {
            console.info("未登录");
            return -11;
         }
         return -4;
      }
      if (!userListNode.isSelected()) {
         userListNode.select();
         sleep(3000);
      }

      console.log(2);
      let addTagNode = id("com.whatsapp:id/fab").findOne(10000);
      if (!addTagNode) {
         addTagNode = id("com.whatsapp:id/fabText").findOne(5000);
      }
      if (!addTagNode) {
         return -4;
      }
      if (addTagNode.click()) {
         console.log("点击+好友");
      }
      sleep(2000);

      console.log(3);
      let selfNodePage = textEndsWith("(você)").find();
      let selfNode = textEndsWith("(você)").findOne(5000);
      if (!selfNode) {
         return -4;
      }
      let selfName = selfNode.text();
      tmpTaskList[i].ex_account = selfName.substring(0, selfName.indexOf(" (você)"));
      console.log(3, tmpTaskList[i].ex_account, selfNodePage.size());
      if (click("(você)")) {
         console.log("点击自己");
      }
      sleep(1000);

      console.log(4);
      console.log(4, data.account);
      let inputNode = className("android.widget.EditText").findOne(5000);
      if (!inputNode) {
         return -4;
      }
      let targetNode = desc(data.account).className("android.view.View").findOne(5000);
      if (!targetNode) {
         inputNode.setText(data.account);
         sleep(1000);

         console.log(5);
         let sendNode = id("com.whatsapp:id/send").findOne(5000);
         if (sendNode == null) {
            sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
         }
         if (!sendNode) {
            return -4;
         }
         sendNode.click();
         sleep(500);
      }

      console.log(6);
      targetNode = desc(data.account).className("android.view.View").findOne(5000);
      if (!targetNode) {
         return -4;
      }
      targetNode.click();
      sleep(3000);

      console.log(7);
      let targetCallNode = textStartsWith("Conversar").clickable(true).findOne(25000);
      if (!targetCallNode) {
         // let noWsNode = textStartsWith("Ligar para").findOne(5000);
         // if (noWsNode) {
         //    console.log("目标号码不存在", data.account);
         //    // return -20;
         //    return reGetTarget(data, i, j, 20);

         // }
         return reGetTarget(data, i, j, 20);
      }
      targetCallNode.click();
      sleep(500);

      let tmpCheckNode = id("com.whatsapp:id/ephemeral_nux_ok").findOne(2000);
      if (tmpCheckNode) {
         tmpCheckNode.click();
      }

      console.log(8);
      return sendMsg(data, i, j);

      // let oneData = tmpTaskList[indexI].task_data[indexJ];

      // let userListNode = packageName(pkgName).descStartsWith("Conversas").drawingOrder("1").findOne(10000);
      // if (userListNode) {
      //    if (!userListNode.isSelected()) {
      //       userListNode.select();
      //       sleep(500);
      //    }

      //    let addTagNode = id("com.whatsapp:id/fab").findOne(10000);
      //    if (!addTagNode) {
      //       addTagNode = id("com.whatsapp:id/fabText").findOne(5000);
      //    }
      //    if (addTagNode) {
      //       addTagNode.click();
      //       sleep(500);
      //       let selfNode = textEndsWith("(você)").findOne(5000);
      //       if (selfNode) {
      //          // let selfName = selfNode.text();
      //          // selfId = selfName.substring(0, selfName.indexOf(" (você)"));
      //          click("(você)");
      //          sleep(1500);
      //          console.log("查找是否存在账号", oneData.account);
      //          let targetNode = desc(oneData.account).className("android.view.View").findOne(5000);
      //          if (targetNode) {
      //             console.log("找到当前账号：", oneData.account);
      //             targetNode.click();
      //             return doSubAction(indexI, indexJ, oneData, reason);
      //          } else {
      //             console.log(`没有找到账号[${oneData.account}],重新键入`);
      //             let inputNode = className("android.widget.EditText").findOne(5000);
      //             if (inputNode) {
      //                inputNode.setText(oneData.account);
      //                sleep(500);
      //                let sendNode = id("com.whatsapp:id/send").findOne(5000);
      //                if (sendNode == null) {
      //                   sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
      //                }

      //                if (sendNode) {
      //                   sendNode.click();
      //                   return preCheck(indexI, indexJ, oneData, reason);
      //                } else {
      //                   oneData.findFailReason = "findOne(sendNode):发送按钮未找到";
      //                   console.error("findOne(sendNode):发送按钮未找到");
      //                }
      //             } else {
      //                oneData.findFailReason = "findOne(inputNode):输入框未找到";
      //                console.error("findOne(inputNode):输入框未找到");
      //             }
      //          }
      //       } else {
      //          oneData.findFailReason = "findOne(selfNode):未找到自己的账号";
      //          console.error("findOne(selfNode):未找到自己的账号");
      //       }
      //    } else {
      //       oneData.findFailReason = "findOne(addTagNode):添加按钮未找到";
      //       console.error("findOne(addTagNode):添加按钮未找到");
      //    }
      // } else {
      //    let notAccountNode = textStartsWith("Esta conta não").findOne(5000);
      //    if (notAccountNode) {
      //       submitBlocked(indexI);
      //       console.info("准备提交任务");
      //       return -10;
      //    }
      //    let notLoginNode = text("CONCORDAR E CONTINUAR").findOne(5000);
      //    if (notLoginNode) {
      //       return -30;
      //    }
      //    if (oneData.retryCount != null) {
      //       oneData.retryCount = oneData.retryCount + 1;
      //       if (oneData.retryCount >= retryNum) {
      //          return -40;
      //       }
      //    } else {
      //       oneData.retryCount = 0;
      //    }
      //    oneData.findFailReason = "findOne(userListNode):用户列表未找到";
      //    console.error("列表未找到//////", oneData.retryCount);
      //    return -4;
      // }
      // if (oneData.retryCount != null) {
      //    oneData.retryCount = oneData.retryCount + 1;
      //    console.error("oneData.retryCount1:", oneData.retryCount);
      //    if (oneData.retryCount >= retryNum) {
      //       return -40;
      //    }
      //    console.error("oneData.retryCount2:", oneData.retryCount);
      // } else {
      //    oneData.retryCount = 0;
      // }
      // console.error("账号可能未注册或某些按钮没有找到/////");
      // return -19;
   }
}

function preCheck(indexI, indexJ, oneData, reason) {
   sleep(1000);
   let targetNode = desc(oneData.account).className("android.view.View").clickable(true).findOne(5000);
   if (targetNode) {
      targetNode.click();
      return doSubAction(indexI, indexJ, oneData, reason);
   } else {
      console.log("preCheck 重试，账号未注册，结束任务");
      return -20;
   }
}


// function doSubAction(indexI, indexJ, oneData, reason) {
//    sleep(1000);
//    console.log("查询是否有和该账户对话按钮");
//    let noWs = textStartsWith("Ligar para").findOne(5000);
//    if (noWs != null) {
//       console.log("查询失败，当前账号错误或者未注册");
//       if (oneData.retryLoadNum != null) {
//          oneData.retryLoadNum = oneData.retryLoadNum - 1;
//          console.error("查询重试次数:", oneData.retryLoadNum);
//          if (oneData.retryLoadNum <= 0) {
//             console.log("查询重试次数用尽,任务失败");
//             var result = utils.redistributionWs(tmpTaskList[indexI].task_sub_id, oneData.detail_id);
//             if (result == -100) {
//                console.log('重新分配账号接口');
//                return -12;
//             }
//             if (result == -2) {
//                console.log('重试3次后重新分配账号仍然失败');
//                return -21;
//             }
//             console.log(`重新分配 ${oneData.account} -> ${result}`);
//             oneData.account = result;
//             oneData.retryLoadNum = 3;
//             back();
//             console.log(`新账号[${oneData.account}],重新键入`);
//             let inputNode = className("android.widget.EditText").findOne(5000);
//             if (inputNode) {
//                inputNode.setText(oneData.account);
//                sleep(500);
//                let sendNode = id("com.whatsapp:id/send").findOne(5000);
//                if (sendNode == null) {
//                   sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
//                }

//                if (sendNode) {
//                   sendNode.click();
//                   return preCheck(indexI, indexJ, oneData, reason);
//                } else {
//                   oneData.findFailReason = "findOne(sendNode):发送按钮未找到";
//                   console.error("findOne(sendNode):发送按钮未找到");
//                }
//             } else {
//                oneData.findFailReason = "findOne(inputNode):输入框未找到";
//                console.error("findOne(inputNode):输入框未找到");
//             }
//             return -19;
//          }
//       } else {
//          oneData.retryLoadNum = 3;
//          console.error("查询重试次数:", oneData.retryLoadNum);
//       }
//       let dialogShowed = textStartsWith("Ligar ").clickable(true).findOne(5000);
//       if (dialogShowed) {
//          oneData.findFailReason = "当前账号查询失败，whatsapp无法查询到当前账号";
//          console.log("对话框弹出，点击取消");
//          back();
//          sleep(1000);
//       }
//       oneData.findFailReason = "当前账号查询失败";
//       console.log("对话框未弹出,重新执行preCheck");
//       // preCheck(indexI, indexJ, oneData, reason);
//       launchApp();
//       sleep(random(3000, 5000));
//       return exeTask(indexI, indexJ, reason);
//    }
//    let targetCallNode = textStartsWith("Conversar").clickable(true).findOne(20000);
//    if (targetCallNode != null) {
//       targetCallNode.click();
//       console.log("点击和该账户对话按钮");
//       sleep(2000);
//       let tmpCheckNode = id("com.whatsapp:id/ephemeral_nux_ok").findOne(2000);
//       if (tmpCheckNode) {
//          tmpCheckNode.click();
//       }
//       oneData.retryCount = 0;
//       oneData.retryNum = 3;
//       oneData.retryLoadNum = 3;
//       var hadSentMsg = oneData.account_already_send;
//       if (hadSentMsg == null) {
//          var s = sendMsg(indexI, indexJ);
//          if (s == 99) {
//             oneData.lastMessageMills = new Date().getTime();
//             oneData.account_already_send = true;
//             tools.storage.put("whatsapp", tmpTaskList);
//          }
//          return s;
//       }
//       // 终结消息失败判断
//       // if (oneData.result_text == "res-99" && oneData.status != 1) {
//       //    console.log("******二检开始");
//       //    if (oneData.lastMsgCheckNum) {
//       //       console.log(`******二检：第${oneData.lastMsgCheckNum}次检查`);
//       //    }
//       //    let response = oneData.endResponse;
//       //    if (response == null || response.length == 0) {
//       //       console.log("保存的结束语被清理或结束语为空，提前结束");
//       //       return -101;
//       //    }
//       //    var isAnySendSuc = checkRepeat(response, oneData).some(function (item) {
//       //       return item;
//       //    });
//       //    if (isAnySendSuc) {
//       //       console.log("******二检：终止消息发送成功");
//       //       return 49;
//       //    } else {
//       //       if (oneData.lastMsgCheckNum) {
//       //          oneData.lastMsgCheckNum = oneData.lastMsgCheckNum + 1;
//       //          if (oneData.lastMsgCheckNum > 1) {
//       //             console.log("******二检：判定失败");
//       //             return -100;
//       //          }
//       //          console.log(`******二检[${oneData.lastMsgCheckNum}]：终止消息发送失败`);
//       //       } else {
//       //          oneData.lastMsgCheckNum = 0;
//       //       }
//       //       tools.storage.put("whatsapp", tmpTaskList);
//       //       console.log("******二检：终止消息发送失败");
//       //       return -99;
//       //    }
//       // }
//       // 先执行一遍确认我最后一条消息的位置
//       // setLastIndex(oneData);
//       // 正常处理
//       // var list = getAllTalkData(oneData);
//       // 有新消息
//       // if (list.length > 0) {
//       //    var containsImg = list.some(function (item) {
//       //       return item.includes("image");
//       //    });
//       //    console.log("等待AI回复");
//       //    var response = utils.startTalk(oneData.detail_id, list.join(","), containsImg ? 1 : 0, 0);
//       //    // 请求失败，返回-1
//       //    if (response == null || response.length == 0) {
//       //       if (oneData.talkRetryCount) {
//       //          oneData.talkRetryCount = oneData.talkRetryCount + 1;
//       //          if (oneData.talkRetryCount > 1) {
//       //             console.log("AI未回复，3次重试后判定失败");
//       //             return -102;
//       //          }
//       //       } else {
//       //          oneData.talkRetryCount = 0
//       //       }
//       //       return -15;
//       //    }
//       //    oneData.talkRetryCount = 0;
//       //    console.log("回复消息数量：" + response.text.length);
//       //    // 如果已经结束，提前保存结束语，以便后续检查
//       //    if (response.is_end == 1) {
//       //       if (response.text != null && response.text.length == 0) {
//       //          tools.storage.put("whatsapp", tmpTaskList);
//       //          console.log("******终止消息请求失败 结束语为空");
//       //          return -105;
//       //       }
//       //       oneData.endResponse = response.text;
//       //       tools.storage.put("whatsapp", tmpTaskList);
//       //       console.log("is_end == 1 保存结束语");
//       //    }
//       //    var msgGroup = [];
//       //    // 发送消息
//       //    for (var i = 0; i < response.text.length; i++) {
//       //       let currMsg = response.text[i];
//       //       msgGroup.push(currMsg);
//       //       sendAIMsg(currMsg);
//       //    }
//       //    oneData.msgGroup = msgGroup;
//       //    oneData.lastMessageMills = new Date().getTime();
//       //    // setLastIndex(oneData);
//       //    // is_end == 1 对话结束
//       //    if (response.is_end == 1) {
//       //       console.log("***聊天已达最大数量***");
//       //       console.log("6-8秒后检查是否发送成功");
//       //       sleep(random(6000, 8000));
//       //       var isAnySendSuc = checkRepeat(response.text, oneData).some(function (item) {
//       //          return item;
//       //       });
//       //       if (isAnySendSuc) {
//       //          console.log("******终止消息发送成功");
//       //          return 49;
//       //       } else {
//       //          console.log("******终止消息发送失败");
//       //          return -99;
//       //       }
//       //    } else {
//       //       console.log("6-8秒后检查是否发送成功");
//       //       sleep(random(6000, 8000));
//       //       var isAnySendSuc = checkRepeat(response.text, oneData).some(function (item) {
//       //          return item;
//       //       });
//       //       if (isAnySendSuc) {
//       //          console.log("普通消息发送成功");
//       //       } else {
//       //          console.log("普通消息发送失败");
//       //       }
//       //    }
//       //    return 50;
//       // } else {
//       //    console.info("没有新消息");
//       //    if (oneData.lastMessageMills == null) {
//       //       console.log("****回复记录异常，清除发送记录，重新开始***");
//       //       oneData.account_already_send = null;
//       //       tools.storage.put("whatsapp", tmpTaskList);
//       //       return -1;
//       //    }
//       //    // 判断本次聊天是否已超时
//       //    if (isTimeDiffExceeded(oneData.lastMessageMills)) {
//       //       console.log("***聊天超时***");
//       //       console.log("等待AI回复");
//       //       let response = utils.startTalk(oneData.detail_id, "", 0, 1);
//       //       if (response == null || response.length == 0) {
//       //          console.log("没有聊天返回，判定这个任务失败！");
//       //          return -103;
//       //       }
//       //       console.log("超时回复语句:", response.text.join(","));
//       //       // 如果已经结束，提前保存结束语，以便后续检查
//       //       if (response.text) {
//       //          if (response.text.length == 0) {
//       //             tools.storage.put("whatsapp", tmpTaskList);
//       //             console.log("******终止消息请求失败 结束语为空");
//       //             return -104;
//       //          } else {
//       //             oneData.endResponse = response.text;
//       //             console.log("超时结束 保存结束语");
//       //             tools.storage.put("whatsapp", tmpTaskList);
//       //          }
//       //       } else {
//       //          tools.storage.put("whatsapp", tmpTaskList);
//       //          console.log("******终止消息请求失败 结束语为空");
//       //          return -104;
//       //       }
//       //       // 发送消息
//       //       for (var i = 0; i < response.text.length; i++) {
//       //          sendAIMsg(response.text[i]);
//       //       }
//       //       console.log("6-8秒后检查是否发送成功");
//       //       sleep(random(6000, 8000));
//       //       var isAnySendSuc = checkRepeat(response.text, oneData).some(function (item) {
//       //          return item;
//       //       });
//       //       if (isAnySendSuc) {
//       //          console.log("******终止消息发送成功");
//       //          return 49;
//       //       } else {
//       //          console.log("******终止消息发送失败");
//       //          return -99;
//       //       }
//       //    }
//       //    return reason;
//       // }
//    } else {
//       console.error("对话按钮未找到///////");
//       if (oneData.retryLoadNum != null) {
//          oneData.retryLoadNum = oneData.retryLoadNum - 1;
//          console.error("查询重试次数:", oneData.retryLoadNum);
//          if (oneData.retryLoadNum <= 0) {
//             console.log("查询重试次数用尽,任务失败");
//             var result = utils.redistributionWs(tmpTaskList[indexI].task_sub_id, oneData.detail_id);
//             if (result == -100) {
//                console.log('重新分配账号接口');
//                return -12;
//             }
//             if (result == -2) {
//                console.log('重试3次后重新分配账号仍然失败');
//                return -21;
//             }
//             console.log(`重新分配 ${oneData.account} -> ${result}`);
//             oneData.account = result;
//             oneData.retryLoadNum = 3;
//             console.log("重新打开whatsapp");
//             launchApp();
//             sleep(random(3000, 5000));
//             return exeTask(indexI, indexJ, reason);
//          }
//       } else {
//          oneData.retryLoadNum = 3;
//          console.error("查询重试次数:", oneData.retryLoadNum);
//       }
//       let progressLoading = id("android:id/progress").findOne(1000);
//       if (progressLoading) {
//          console.error("findOne(progressLoading):当前账号查询时间过长，等待重试");
//          oneData.findFailReason = "当前账号查询超时，whatsapp无法查询到账号,考虑网络是否正常";
//          launchApp();
//          sleep(random(3000, 5000));
//          return exeTask(indexI, indexJ, reason);
//       }
//       let dialogShowed = textStartsWith("Ligar ").clickable(true).findOne(1000);
//       if (dialogShowed) {
//          oneData.findFailReason = "当前账号查询失败，whatsapp无法查询到当前账号";
//          console.log("对话框弹出，点击取消");
//          back();
//          sleep(1000);
//       }
//       oneData.findFailReason = "当前账号查询失败";
//       console.log("对话框未弹出,重新执行exeTask");
//       // preCheck(indexI, indexJ, oneData, reason);
//       launchApp();
//       sleep(random(3000, 5000));
//       return exeTask(indexI, indexJ, reason);
//    }
// }

function checkRepeat(response, oneData) {
   var responseSelector = [];
   var repeatSucList = [];
   var listNode = id("android:id/list").findOne(3000);
   if (listNode == null) {
      console.log("没有找到listNode55");
      return [];
   }
   for (var i = 0; i < response.length; i++) {
      let resp = listNode.findByText(response[i]);
      responseSelector.push(resp);
   }
   console.log("找到" + responseSelector.length + "个控件");
   sleep(2000);
   listNode = id("android:id/list").findOne(3000);
   if (listNode == null) {
      console.log("没有找到listNode55");
      return [];
   }
   listNode.children().reverse().forEach(function (child) {
      let send = child.findOne(id("com.whatsapp:id/status"));
      if (send != null) {
         let like = child.findOne(id("com.whatsapp:id/message_text"));
         if (like) {
            console.log("检查-当前聊天内容：", like.text());
            for (var k = 0; k < response.length; k++) {
               let respNode = response[k];
               if (like.text() == respNode) {
                  console.log("找到内容", respNode);
                  let descStutas = send.desc();
                  var sendSuc = false;
                  if (descStutas == "Enviada" || descStutas == "Lida" || descStutas == "Entregue") {
                     oneData.lastMessageMills = new Date().getTime();
                     sendSuc = true;
                  }
                  console.log("状态是否成功：", sendSuc);
                  repeatSucList.push(sendSuc);
               }
            }
         } else {
            console.log("检查-当前聊天内容：", "没有找到文字TextView");
         }
      } else {
         console.log("检查-当前聊天内容：", "没有找到状态View");
      }
   })
   return repeatSucList;
}

function sendAIMsg(message) {
   console.info("等待发送");
   sleep(random(1200, 7800));
   let inputNode = id("com.whatsapp:id/entry").findOne(5000);
   if (inputNode) {
      // 发送AI回复
      inputNode.setText(message);
      var sendNode = id("com.whatsapp:id/send").findOne(5000);
      if (sendNode) {
         if (sendNode.click()) {
            tools.storage.put("whatsapp", tmpTaskList);
            console.info("[发送]:", message);
         }
      }
      let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
      console.info("发送间隔:", config.single_interval[0], config.single_interval[1], randTime);
      sleep(randTime * 1000);
   } else {
      console.info("没有找到输入框")
   }
}

function getAllTalkData(oneData) {
   console.info("进入消息页面");
   sleep(random(2000, 6000));
   var listNode = className("android.widget.ListView").findOne(8000);
   if (listNode == null) {
      console.info("没有找到消息队列listNode");
      return -1;
   }
   var mylastRepeat = false;
   var otherLastRepeat = false;
   var lastConvarsations = [];
   if (oneData.talkData) {
      lastConvarsations = oneData.talkData;
   }
   console.log("历史回复内容：", lastConvarsations);
   var currentMsgList = [];
   var screenX = (device.width / 2) + random(0, 200);
   swipe(screenX, (device.height / 2) + random(0, 100), screenX, device.height / 4, 500);
   sleep(500);
   swipe(screenX, device.height / 4, screenX, (device.height / 2) + random(0, 100), 500);
   sleep(500);
   let scrollDown = id("com.whatsapp:id/scroll_bottom").findOne(1000);
   if (scrollDown) {
      scrollDown.click();
   } else {
      for (var x = 0; x < random(1, 4); x++) {
         sleep(500);
         console.log(`向上滑动[${x + 1}次]`);
         swipe(device.width / 2, device.height / 2, device.width / 2, device.height / 4, 500);
      }
   }
   sleep(2000);
   try {
      console.info("开始查找消息队列");
      // 滑动后重新找到list节点，避免丢失信息
      var listNode = className("android.widget.ListView").findOne(3000);
      console.log("开始轮询列表");
      console.log("列表长度=", listNode.children().length);
      listNode.children().reverse().forEach(function (child, index) {
         var textSelector = child.find(id("com.whatsapp:id/message_text"));
         var like = null;
         if (textSelector != null && textSelector.length > 0) {
            like = child.findOne(id("com.whatsapp:id/message_text"));
         }
         let dateNode = child.findOne(id("com.whatsapp:id/date"));
         let send = child.findOne(id("com.whatsapp:id/status"));
         if (like != null && send == null) {
            let otherDateTime = child.findOne(id("com.whatsapp:id/date"));
            console.log("-------(" + `[${otherDateTime.text()}])` + like.text());
            if (!otherLastRepeat) {
               otherLastRepeat = true;
               console.log("***对方最后回复文字[" + index + "]***：" + like.text() + `[${otherDateTime.text()}]`);
            } else {
               console.log("-------(" + `[${otherDateTime.text()}])` + like.text());
            }
            if ((lastConvarsations.length == 0 && oneData.firstTextIndex > index) || oneData.lastItemIndex > index) {
               console.log(`-------[文字消息][${like.text()}]`);
               currentMsgList.push(like.text());
            } else {
               console.log(`旧消息，抛弃[${dateNode.text()}]`);
            }
         } else {
            if (dateNode != null && send == null) {
               if (!otherLastRepeat) {
                  console.log(`***最新消息为 [非文字消息][${dateNode.text()}]`);
                  otherLastRepeat = true;
               } else {
                  if ((lastConvarsations.length == 0 && oneData.firstTextIndex > index) || oneData.lastItemIndex > index) {
                     console.log(`-------[非文字消息][${dateNode.text()}]`);
                     //存入当前轮询查找的控件列表中
                     currentMsgList.push("image");
                  } else {
                     console.log(`-------[非文字消息]旧消息，抛弃[${dateNode.text()}]`);
                  }
               }
            }
         }
      });
      console.log("当前回复内容：", currentMsgList);
      // 判断是否有新消息
      if (currentMsgList.length > 0) {
         console.log("*******有新消息，内容：", currentMsgList);
         currentMsgList.forEach(function (child) {
            lastConvarsations.push(child);
         });
         oneData.talkData = lastConvarsations;
         tools.storage.put("whatsapp", tmpTaskList);
      }
      // 倒序一下，让先回复的在头部
      return currentMsgList.reverse();
   } catch (error) {
      if (oneData.talkListCheck) {
         oneData.talkListCheck = oneData.talkListCheck + 1;
         if (oneData.talkListCheck <= 2) {
            getAllTalkData(oneData);
         }
      } else {
         oneData.talkListCheck = 0;
      }
      tools.storage.put("whatsapp", tmpTaskList);
      sleep(1000);
      return [];
   }
}

function setLastIndex(oneData) {
   //第一轮检查
   //确定我最后回复消息的位置，以及确定对方消息的位置
   let listNode = id("android:id/list").findOne(3000);
   if (listNode == null) {
      console.log("没有找到listNode55");
      return [];
   }
   var screenX = (device.width / 2) + random(0, 200);
   swipe(screenX, (device.height / 2) + random(0, 100), screenX, device.height / 4, 500);
   sleep(500);
   swipe(screenX, device.height / 4, screenX, (device.height / 2) + random(0, 100), 500);
   sleep(500);
   let scrollDown = id("com.whatsapp:id/scroll_bottom").findOne(1000);
   if (scrollDown) {
      scrollDown.click();
   } else {
      for (var x = 0; x < random(1, 4); x++) {
         sleep(500);
         console.log(`向上滑动[${x + 1}次]`);
         swipe(device.width / 2, device.height / 2, device.width / 2, device.height / 4, 500);
      }
   }
   sleep(2000);
   var mylastRepeat = false;
   var otherLastRepeat = false;
   var lastOtherRepeatText = null;
   var lastOtherRepeatIndex = null;
   var checkFirstItemSuc = false;
   var myFirstTextIndex = null;
   listNode = className("android.widget.ListView").findOne(3000);
   listNode.children().reverse().forEach(function (child, index) {
      var textSelector = child.find(id("com.whatsapp:id/message_text"));
      var like = null;
      if (textSelector != null && textSelector.length > 0) {
         like = child.findOne(id("com.whatsapp:id/message_text"));
      }
      let send = child.findOne(id("com.whatsapp:id/status"));
      // 对方
      if (like != null && send == null) {
         let otherDateTime = child.findOne(id("com.whatsapp:id/date"));
         console.log("-------(" + `[${otherDateTime.text()}])` + like.text());
         if (!otherLastRepeat) {
            otherLastRepeat = true;
            if (oneData.lastConvarsations != null && oneData.lastConvarsations.length > 0) {
               lastOtherRepeatText = like.text();
               lastOtherRepeatIndex = index;
            }
            console.log("***对方最后回复文字[" + index + "]***：" + like.text() + `[${otherDateTime.text()}]`);
         } else {
            console.log("-------(" + `[${otherDateTime.text()}])` + like.text());
         }
      }
      // 我的
      if (like != null && send != null) {
         if (oneData.text != null && oneData.text.length > 0) {
            if (oneData.lastConvarsations == null || oneData.lastConvarsations.length === 0) {
               if (oneData.text[0] == like.text()) {
                  checkFirstItemSuc = true;
                  myFirstTextIndex = index;
               }
            }
         }
      }
   });
   if (checkFirstItemSuc) {
      oneData.firstTextIndex = myFirstTextIndex;
      console.info("当前历史记录为空，记录首条消息位置：", myFirstTextIndex);
   } else {
      console.log("当前页面没有找到我发送的首轮首条历史消息，判断可能用户发送多条将文案顶上去了[firstTextIndex = 10]");
      //如果当前页面没有找到我发送的首轮首条历史消息，判断可能用户发送多条将文案顶上去了
      //下次检查的时候将所有对方消息收集发送给AI
      oneData.firstTextIndex = 10;
   }
   if (oneData.msgGroup) {
      console.log("检查我的上次回复，判断是否有间隔消息");
      for (var n = 0; n < oneData.msgGroup.length; n++) {
         var targetText = oneData.msgGroup[n];
         if (mylastRepeat) break;
         listNode.children().reverse().forEach(function (child, index) {
            var textSelector = child.find(id("com.whatsapp:id/message_text"));
            var like = null;
            if (textSelector != null && textSelector.length > 0) {
               like = child.findOne(id("com.whatsapp:id/message_text"));
            }
            let send = child.findOne(id("com.whatsapp:id/status"));
            if (like != null && send != null) {
               let dateTime = child.findOne(id("com.whatsapp:id/date"));
               if (targetText == like.text()) {
                  if (!mylastRepeat) {
                     mylastRepeat = true;
                     console.log("***找到上轮回复消息的第[" + n + "]条消息：" + like.text() + `[${dateTime.text()}]`);
                     oneData.lastItemIndex = index;
                  };
               }
            }
         })
      }
      if (!mylastRepeat) {
         oneData.lastItemIndex = 10;
         console.log("***没有找到上轮回复消息 oneData.lastItemIndex 设置为" + `[${oneData.lastItemIndex}]`);
      }
   } else {
      console.log("***我的非首次回复消息内容为空");
      if (oneData.status != 1 && oneData.reason == -15) {
         oneData.lastItemIndex = 5;
         console.log("***判断为AI回复失败,获取最近 " + `[${oneData.lastItemIndex}] 条数据`);
      }
   }
}

function isTimeDiffExceeded(lastTimestamp) {
   // 获取当前时间戳
   let currentTimestamp = new Date().getTime();

   // 如果上一次时间戳为空，直接更新并返回 false
   if (lastTimestamp === null) {
      lastTimestamp = currentTimestamp;
      return false;
   }
   console.log("记录时间戳lastTimestamp: " + lastTimestamp);
   console.log("当前时间戳currentTimestamp: " + currentTimestamp);
   // 计算时间差
   let timeDiff = currentTimestamp - lastTimestamp;

   console.log("距离上次发送已过去: " + Math.floor(timeDiff / 1000) + "秒");
   console.log("既定超时间隔: " + config.reply_timeout * 60 + "秒");

   // 返回是否超过阈值
   return Math.floor(timeDiff / 1000) > config.reply_timeout * 60;
}

function launchApp() {
   console.log("启动");
   var intent = new Intent();
   intent.setClassName(pkgName, "com.whatsapp.HomeActivity");
   intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
   context.startActivity(intent);
}
