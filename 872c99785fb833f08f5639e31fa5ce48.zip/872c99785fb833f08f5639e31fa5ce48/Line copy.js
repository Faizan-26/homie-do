var tools = require("./tools.js");
var utils = require("./utils.js");
var pkgName = "jp.naver.line.android";
var storeKey = "Line";
var config = {};
var tmpTaskList = [];
var isContinueFail = 0;
var selfId = "";
var instance = {};
var isOver = false;
const isTest = false;
const countries = {
   '+1': 'United States',
   '+86': 'China',
   '+81': 'Japan',
   '+82': '대한민국',
   '+44': 'United Kingdom',
   '+49': 'Germany',
   '+33': 'France',
   '+61': 'Australia',
   '+91': 'India',
   // 继续添加其他国家
   '+55': 'Brazil',
};
var runing = setInterval(() => {
   if (isOver) {
      clearInterval(runing);
   }
}, 1000);

var fadeData = ` [{
            "name": "TGAI私信 ",
            "app_id": 10,
            "config":
            {
                "has_paid": 1,
                "reply_timeout": 10,
                "single_interval":
                    [
                        2,
                        5
                    ],
                "account_interval":
                    [
                        1,
                        2
                    ]
            },
            "task_id": 15,
            "has_paid": 1,
            "task_data":
                [
                    {
                        "text":
                            [
                                "走咯，打球去了"
                            ],
                        "account": "+66 886464361",
                        "detail_id": 1826
                    }
                ],
            "task_type": 8,
            "task_length": 5,
            "task_sub_id": 1316,
            "times_stop_begin": 0,
            "continuous_fail_stop": 0
        }]`;

var fakeContent = ["Olá~ Acabei de ver você no Twitter, quer bater um papo?",
   "Ouvi dizer que esse lugar é divertido. Por que você não dá uma olhada?",
   "Há muitas comidas deliciosas aqui~",
   "Pode",
   "Sem chance! ! Você não ouviu falar dessa animação? ! ! !",
   "Sem problemas",
   "Todas as manhãs quando acordo, sou grato pela sua companhia 🌅✨.",
   "Bom dia, vamos saudar o novo dia juntos com belas expectativas em nossos corações 🌞🌈.",
   "mas...",
   "Bom dia! Espero que tudo corra como você deseja hoje e que tudo seja repleto de icidade e alegria! 🥰🌻.",
   "Desejo a você um dia cheio de energia positiva e que comece o novo dia com total alidade 💪😊.",
   "Bom dia! Você é a pessoa mais especial do meu coração, desejo-lhe um bom dia! 💖✨.",
   "bom",
   "Ao amanhecer, desejo a você um dia feliz e alegre. 🌟🌱.",
   "Bom dia! Que seu dia seja repleto de bênçãos e alegrias, e que você aproveite cada momento dele! 🎉😄",
   "O sol da manhã também é minha saudação para você, que você tenha um dia maravilhoso ☀️💕.",
   "Bom dia! Cada manhã é um novo milagre. Vamos saudar o novo dia com confiança! 🌈🌼.",
   " Acorde cedo, que você sorria todos os dias e comece o dia com gratidão e carinho! 😊🌸.",
   "Ok, eu entendo",
   "Pode",
   "mas...",
   "Sem problemas",
   "Mas!",
   `${random(1, 3000)}`,
];

events.on("say", function (param) {
   try {
      instance.handle(param.list);
   } catch (error) {
      
   }
   
});



instance.handle = function (taskList) {
   try {
      //  storage check 
      console.info("tmpTaskList =>\n", tmpTaskList);
      try {
         console.info("获取本地缓存");
         tmpTaskList = tools.storage.get(storeKey, []);
         console.info("tmpTaskList 缓存=>\n", tmpTaskList);
         if (tmpTaskList.length > 0) {
            for (var i = tmpTaskList.length - 1; i >= 0; i--) {
               if (i < taskList.length) {
                  if (tmpTaskList[i].task_sub_id != taskList[i].task_sub_id) {
                     console.info("task_sub_id 与传入的taskList 不一致，判断为历史数据，准备提交");
                     submitRes(i);
                  }
               }
            }
         }
         // 没有缓存则赋值
         console.log("赋值长度", tmpTaskList.length);
         if (tmpTaskList.length < 1) {
            // 测试用
            if (isTest) {
               console.log("赋值:", isTest);
               tmpTaskList = JSON.parse(taskList);
               tools.storage.put(storeKey, tmpTaskList);
            } else {
               tmpTaskList = taskList;
               console.log("赋值");
               tools.storage.put("Line", tmpTaskList);
            }
         }

         // 强制结束
         if (utils.forceStop == true) {
            for (var i = tmpTaskList.length - 1; i >= 0; i--) {
               for (var j = 0; j < tmpTaskList[i].task_data.length; j++) {
                  if (!tmpTaskList[i].task_data[j].taskFinish) {
                     tmpTaskList[i].task_data[j].taskFinish = true;
                     tmpTaskList[i].task_data[j].status = 2;
                     tmpTaskList[i].task_data[j].result_text = "强制结束";
                  }
               }
               submitRes(i);
            }
            return;
         }

         // 账号绑定
         let isBind = false;
         for (var i = 0; i < tmpTaskList.length; i++) {
            console.log("所有", tmpTaskList[i]);
            if (tmpTaskList[i].isBind) {
               isBind = true;
            } else {
               let tmpBind = exeGetInfo();
               let tmpRemark = tmpBind == 1 ? "" : "没找到";
               let temResult = utils.bindAccount(tmpTaskList[i].app_id, selfId, tmpTaskList[i].task_sub_id, tmpRemark);
               if (temResult == 1) {
                  tmpTaskList[i].isBind = true;
                  isBind = true;
               } else {
                  tmpTaskList[i].isBind = false;
               }
               tools.storage.put(storeKey, tmpTaskList);
            }
         }

         if (!isBind) {
            isOver = true;
            return;
         }
         //            for (var i = tmpTaskList.length - 1; i >= 0; i--) {
         //               for (var j = 0; j < tmpTaskList[i].task_data.length; j++) {
         //                  if (!tmpTaskList[i].task_data[j].taskFinish) {
         //                     tmpTaskList[i].task_data[j].taskFinish = true;
         //                     tmpTaskList[i].task_data[j].status = 9;
         //                     tmpTaskList[i].task_data[j].result_text = selfId + "Line账号已被绑定";
         //                  }
         //               }
         //               submitRes(i);
         //            }
      } catch (error) {
         tools.storage.remove("Line");
         console.error("数据错误，清除缓存 ::", error);
         return;
      }


      let isExit = false;
      // task number
      for (var i = tmpTaskList.length - 1; i >= 0; i--) {
         config = tmpTaskList[i].config;
         //  person number
         console.info("任务(" + tmpTaskList[i].task_data.length + ")");
         for (var j = 0; j < tmpTaskList[i].task_data.length; j++) {
            console.log(`当前账号[${j}]:`, tmpTaskList[i].task_data[j].account);
            tmpTaskList[i].task_data[j].taskFinish = false;
            if (tmpTaskList[i].task_data[j].taskFinish) {
               continue;
            } else {
               if (!tmpTaskList[i].task_data[j].hasOwnProperty("opt")) {
                  tmpTaskList[i].task_data[j].opt = 1;
               }
               console.log("当前执行任务数据:\n", tmpTaskList[i].task_data[j]);
               let s = exeTask(i, j, tmpTaskList[i].task_data[j].opt);
               console.log("当前任务执行结果 ", s);

               //   ？？？？2-强制结束，9-执行账号绑定，被动结束，删消息列表


               if (s == -4 || s == -5) {
                  s = exeTask(i, j, tmpTaskList[i].task_data[j].opt);
               }
               if (s == -4 || s == -5) {
                  console.log(`(s=${s})控件没找到`);
                  tmpTaskList[i].task_data[j].taskFinish = true;
                  tmpTaskList[i].task_data[j].status = 6;
                  tmpTaskList[i].task_data[j].result_text = "控件没找到";
               }
               if (s == -10) {
                  console.log(`(s=${s})未登录Line`);
                  tmpTaskList[i].task_data[j].taskFinish = true;
                  tmpTaskList[i].task_data[j].status = 5;
                  tmpTaskList[i].task_data[j].result_text = "未登录Line";
                  isExit = true;
                  break;
               }
               if (s == -20) {
                  console.log(`(s=${s}) 账号被禁`);
                  tmpTaskList[i].task_data[j].taskFinish = true;
                  tmpTaskList[i].task_data[j].result_text = "账号被禁";
                  tmpTaskList[i].task_data[j].status = 4;
                  isExit = true;
                  break;
               }
               if (s == -30) {
                  console.log(`(s=${s})Line未找到该账号或账号未注册`);
                  tmpTaskList[i].task_data[j].taskFinish = true;
                  tmpTaskList[i].task_data[j].status = 3;
                  tmpTaskList[i].task_data[j].result_text = "Line未找到该账号或账号未注册";
               }

               if (s == -100) {
                  console.log(`(s=${s}) AI对话请求失败，等待重试`);
                  tmpTaskList[i].task_data[j].taskFinish = true;
                  tmpTaskList[i].task_data[j].status = 8;
                  tmpTaskList[i].task_data[j].result_text = "AI对话请求失败";
               }

               if (s == -101) {
                  console.log(`(s=${s}) 发送结束语失败`);
                  tmpTaskList[i].task_data[j].taskFinish = true;
                  tmpTaskList[i].task_data[j].status = 7;
                  tmpTaskList[i].task_data[j].result_text = "发送结束语失败";
               }

               if (s == 100) {
                  console.log(`(s=${s}) 发送结束语成功`);
                  tmpTaskList[i].task_data[j].taskFinish = true;
                  tmpTaskList[i].task_data[j].status = 1;
                  tmpTaskList[i].task_data[j].result_text = "发送结束语成功";
               }


               if (s == 1) {
                  // tmpTaskList[i].task_data[j].status = 1;
                  console.info("发送成功，进入AI对话....");
                  tmpTaskList[i].task_data[j].result_text = "发送成功";
                  tmpTaskList[i].task_data[j].opt = 2;
               }
               tools.storage.put(storeKey, tmpTaskList);
            }
            console.log("执行完后任务数据:\n", tmpTaskList[i].task_data[j]);

            if (j + 1 < tmpTaskList[i].task_data.length) {
               let randTime = randomNum(config.account_interval[0], config.account_interval[1]);
               sleep(randTime * 1000);
            }

         }

         // tools.storage.put(storeKey, tmpTaskList);
         sleep(500);

         // 特殊情况直接提交
         if (isExit) {
            console.info("未登录或者封号直接退出提交");
            tools.addStatus(tmpTaskList[i].pkgName);
            submitRes(i);
            return;
         }

         let isAllFinish = true;
         for (var j = 0; j < tmpTaskList[i].task_data.length; j++) {
            if (!tmpTaskList[i].task_data[j].taskFinish) {
               console.info(`任务对象${tmpTaskList[i].task_data[j].account} 未完成`);
               isAllFinish = false;
            }
         }
         if (isAllFinish) {
            console.info("Line所有任务已完成");
            console.log("tools.addStatus", tmpTaskList[i].pkgName);
            tools.addStatus(tmpTaskList[i].pkgName);
            console.info("准备提交任务");
            submitRes(i);
         }
      }

      console.log("Line exe  end");

   } catch (error) {
      tools.storage.put(storeKey, tmpTaskList);
      console.error("运行中报错，保存数据::::", error);
      setTimeout(function () {
         engines.myEngine().forceStop();
      }, 500);
   }
}

if (isTest) {
   instance.handle(fadeData);
}

function randomNum(minNum, maxNum) {
   return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}

function submitRes(i) {
   let res = {};
   res.task_id = tmpTaskList[i].task_id;
   res.task_sub_id = tmpTaskList[i].task_sub_id;
   res.ex_account = selfId;
   res.has_continuous_fail = isContinueFail;
   res.task_data = JSON.stringify(tmpTaskList[i].task_data);
   console.error("提交", res);
   // let result = utils.submitTask(res);

   if (i >= 0) {
      tmpTaskList[i] = [];
      if (i == tmpTaskList.length - 1) {
         tmpTaskList = [];
         tools.storage.remove(storeKey);
      }
   }
}

function submitBlocked(i) {
   let res = {};
   res.app_id = tmpTaskList[i].app_id;

   utils.submitBlocked(res, function () {
      tools.addStatus(tmpTaskList[i].pkgName);
      console.log("账号被封禁提交成功");
   });
}

function deleteUserList() {
   // try {
   back();
   back();
   sleep(500);
   let selfNode = textEndsWith(")").findOne(5000);
   if (selfNode) {
      longClick(")");
      let selfNodeRect = selfNode.bounds();
      let deleteTargetNode = id("com.whatsapp:id/conversations_row_contact_name").find();
      deleteTargetNode.each(function (child) {
         let childRect = child.bounds();
         if (childRect.centerY() < selfNodeRect.centerY()) {
            console.log(child.text());
            click(child.text());
            sleep(500);
         }
      });

      let pinNode = id("com.whatsapp:id/menuitem_conversations_pin").findOne(5000);
      if (pinNode) {
         let deleteRect = pinNode.bounds();
         click(deleteRect.centerX() + deleteRect.width(), deleteRect.centerY());
         sleep(1000);
         let deleteNode = descStartsWith("Apagar").findOne(5000);
         if (deleteNode) {
            deleteNode.click();
            console.log("0=====  delete success");
            return;
         } else {
            console.warn("3=====  delete step  3");
         }
      } else {
         console.warn("2=====  delete step  2");
      }
   } else {
      console.warn("1=====  delete step  1");
   }
   // } catch (error) {
   //    console.warn("-1=====  delete  exp", error);
   // }
}

function sendAIMsg(indexI, indexJ, response) {
   try {
      let editNode = id("jp.naver.line.android:id/chat_ui_message_edit").findOne(5000);
      if (!editNode) {
         return -4;
      }

      let tmpArray = [];
      console.log("AI 发送", response.text.length);
      // 发送
      for (var i = 0; i < response.text.length; i++) {
         let element = response.text[i];
         console.log(element);
         editNode.setText(element);
         let sendNode = id("jp.naver.line.android:id/chat_ui_send_button_image").findOne(5000);
         if (sendNode && sendNode.click()) {
            tmpArray.push(i);
            sleep(500);
            // if (index + 1 < response.text.length) {
            let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
            sleep(randTime * 1000);
            // }
         }
      }

      console.info("AI 检测");
      // 检测
      let msgListNode = id("jp.naver.line.android:id/chathistory_message_list").findOne(5000);
      if (msgListNode) {
         let tmpMsgList = msgListNode.children().reverse();
         tmpArray = tmpArray.reverse();
         tmpArray.forEach(element => {
            try {
               tmpMsgList.forEach(function (child) {
                  let tmpSendMsgNode = child.findOne(text(response.text[element]));
                  let leftMsgNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_message_layout"));
                  console.info("距离：", leftMsgNode.bounds().centerX(), device.width);
                  // if (tmpSendMsgNode && (leftMsgNode && leftMsgNode.bounds().centerX() - 431 > device.width / 2)) {
                  if (tmpSendMsgNode) {
                     console.log(tmpSendMsgNode.text());
                     let tmpSendMsgTimeNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_timestamp"));
                     if (tmpSendMsgTimeNode) {
                        console.info("时间距离：", tmpSendMsgTimeNode.bounds().centerX(), device.width);
                        tmpTaskList[indexI].task_data[indexJ].lastSendTimeText = tmpSendMsgTimeNode.text();
                        tmpTaskList[indexI].task_data[indexJ].lastSendTime = Date.now();
                        tools.storage.put(storeKey, tmpTaskList);
                        throw new Error();
                     }
                     return;
                  }
               });
            } catch (error) {

            }
         });
      }
      let isSendSuccess = false;
      if (tmpTaskList[indexI].task_data[indexJ].hasOwnProperty("lastSendTime") &&
         tmpTaskList[indexI].task_data[indexJ].lastSendTime >= tmpTaskList[indexI].task_data[indexJ].oldSendTime) {
         tmpTaskList[indexI].task_data[indexJ].oldSendTime = tmpTaskList[indexI].task_data[indexJ].lastSendTime;
         tools.storage.put(storeKey, tmpTaskList);
         console.log("AI发送成功");
         isSendSuccess = true;
      }
      // if (tmpTaskList[indexI].task_data[indexJ].hasOwnProperty("forceEnd") && tmpTaskList[indexI].task_data[indexJ].forceEnd) {
      if (response.is_end == 1) {
         if (isSendSuccess) {
            return 100;
         } else {
            return -101;
         }
      } else {
         return 1;
      }

      return -4;
   } catch (error) {
      console.error(error);
      return -5;
   }
}

function getAllTalkData(oneData) {
   console.info("进入消息页面");
   sleep(random(2000, 6000));
   var listNode = className("android.widget.ListView").findOne(8000);
   if (listNode == null) {
      console.info("没有找到消息队列listNode");
      return -1;
   }
   var mylastRepeat = false;
   var otherLastRepeat = false;
   var lastConvarsations = [];
   if (oneData.talkData) {
      lastConvarsations = oneData.talkData;
   }
   console.log("历史回复内容：", lastConvarsations);
   var currentMsgList = [];
   var screenX = (device.width / 2) + random(0, 200);
   swipe(screenX, (device.height / 2) + random(0, 100), screenX, device.height / 4, 500);
   sleep(500);
   swipe(screenX, device.height / 4, screenX, (device.height / 2) + random(0, 100), 500);
   sleep(500);
   let scrollDown = id("com.whatsapp:id/scroll_bottom").findOne(1000);
   if (scrollDown) {
      scrollDown.click();
   } else {
      for (var x = 0; x < random(1, 4); x++) {
         sleep(500);
         console.log(`向上滑动[${x + 1}次]`);
         swipe(device.width / 2, device.height / 2, device.width / 2, device.height / 4, 500);
      }
   }
   sleep(2000);
   try {
      console.info("开始查找消息队列");
      // 滑动后重新找到list节点，避免丢失信息
      var listNode = className("android.widget.ListView").findOne(3000);
      console.log("开始轮询列表");
      console.log("列表长度=", listNode.children().length);
      listNode.children().reverse().forEach(function (child, index) {
         var textSelector = child.find(id("com.whatsapp:id/message_text"));
         var like = null;
         if (textSelector != null && textSelector.length > 0) {
            like = child.findOne(id("com.whatsapp:id/message_text"));
         }
         let dateNode = child.findOne(id("com.whatsapp:id/date"));
         let send = child.findOne(id("com.whatsapp:id/status"));
         if (like != null && send == null) {
            let otherDateTime = child.findOne(id("com.whatsapp:id/date"));
            console.log("-------(" + `[${otherDateTime.text()}])` + like.text());
            if (!otherLastRepeat) {
               otherLastRepeat = true;
               console.log("***对方最后回复文字[" + index + "]***：" + like.text() + `[${otherDateTime.text()}]`);
            } else {
               console.log("-------(" + `[${otherDateTime.text()}])` + like.text());
            }
            if ((lastConvarsations.length == 0 && oneData.firstTextIndex > index) || oneData.lastItemIndex > index) {
               console.log(`-------[文字消息][${like.text()}]`);
               currentMsgList.push(like.text());
            } else {
               console.log(`旧消息，抛弃[${dateNode.text()}]`);
            }
         } else {
            if (dateNode != null && send == null) {
               if (!otherLastRepeat) {
                  console.log(`***最新消息为 [非文字消息][${dateNode.text()}]`);
                  otherLastRepeat = true;
               } else {
                  if ((lastConvarsations.length == 0 && oneData.firstTextIndex > index) || oneData.lastItemIndex > index) {
                     console.log(`-------[非文字消息][${dateNode.text()}]`);
                     //存入当前轮询查找的控件列表中
                     currentMsgList.push("image");
                  } else {
                     console.log(`-------[非文字消息]旧消息，抛弃[${dateNode.text()}]`);
                  }
               }
            }
         }
      });
      console.log("当前回复内容：", currentMsgList);
      // 判断是否有新消息
      if (currentMsgList.length > 0) {
         console.log("*******有新消息，内容：", currentMsgList);
         currentMsgList.forEach(function (child) {
            lastConvarsations.push(child);
         });
         oneData.talkData = lastConvarsations;
         tools.storage.put(storeKey, tmpTaskList);
      }
      // 倒序一下，让先回复的在头部
      return currentMsgList.reverse();
   } catch (error) {
      if (oneData.talkListCheck) {
         oneData.talkListCheck = oneData.talkListCheck + 1;
         if (oneData.talkListCheck <= 2) {
            getAllTalkData(oneData);
         }
      } else {
         oneData.talkListCheck = 0;
      }
      tools.storage.put(storeKey, tmpTaskList);
      sleep(1000);
      return [];
   }
}



// **************************************辅助函数**************************************
function launchApp() {
   try {
      app.startActivity({
         action: "android.intent.action.MAIN",
         packageName: "jp.naver.line.android",
         className: "jp.naver.line.android.activity.SplashActivity",
         flags: ["grant_read_uri_permission", "grant_write_uri_permission", "activity_clear_top", "activity_new_task", "activity_clear_task"]
      });
      sleep(3000);
      if (currentPackage() !== pkgName) {
         launchApp();
      }
   } catch (error) {
      console.error("启动失败:", e);
   }
};

function findCountry(tmpCountryCode) {
   try {
      let isFind = false;
      console.info(countries[tmpCountryCode]);
      let phone_country_listNode = id("jp.naver.line.android:id/phone_country_list").findOne(5000);
      if (phone_country_listNode) {
         console.log(3);
         phone_country_listNode.children().forEach(function (child) {
            let tmpCodeNode = child.findOne(text(countries[tmpCountryCode]));
            if (tmpCodeNode) {
               child.click();
               sleep(500);
               back();
               sleep(500);
               isFind = true;
               console.info("找到了");
            }
         })
         console.log(4);
         if (!isFind && text("Zimbabwe").findOne(2000)) {
            console.info("到底了");
            isFind = true;
         }
         console.log(5);
         if (isFind) return;
         console.log(6);
         let posX = device.width / 2;
         let posY = device.height / 3 * 2;
         swipe(posX, posY, posX, posY - device.height / 3, 500);
         sleep(1000);
         console.log(7);
         findCountry(tmpCountryCode);
      }
   } catch (error) {

   }
}

function exeTask(indexI, indexJ, opt) {
   try {
      launchApp();
      //    let notAccountNode = textStartsWith("Esta conta não").findOne(5000);
      //    if (notAccountNode) {
      //       submitBlocked(indexI);
      //       console.info("准备提交任务");
      //       return -10;
      //    }

      let notLoginNode = id("jp.naver.line.android:id/login").findOne(5000);
      if (notLoginNode) {
         return -10;
      }

      let oneData = tmpTaskList[indexI].task_data[indexJ];
      console.log(1);

      // let chatNode = packageName(pkgName).id("jp.naver.line.android:id/bnb_home_v2").findOne(5000);
      // console.info(chatNode);
      // if (!chatNode) {
      //    return -4;
      // }
      // let chatNodeArea = chatNode.findOne(id("jp.naver.line.android:id/bnb_button_clickable_area"));
      console.log(1.1);
      let chatNodeArea = id("jp.naver.line.android:id/bnb_button_clickable_area").findOne(5000);
      if (!chatNodeArea || !chatNodeArea.click()) {
         return -4;
      }
      sleep(500);

      console.log(2);
      let addFriendNode = id("jp.naver.line.android:id/add_friends_header_button").findOne(5000);
      if (!addFriendNode || !addFriendNode.click()) {
         return -4;
      }
      sleep(500);


      console.log(3);
      let searchNode = text("Pesquisar").findOne(5000);
      if (!searchNode || !click("Pesquisar")) {
         return -4;
      }
      sleep(500);

      console.log(4);
      let phoneNumberArray = oneData.account.split(" ");
      if (phoneNumberArray.length < 2) {
         let radioNode = className("android.widget.RadioButton").text("ID").findOne(5000);
         if (!radioNode) {
            return -4;
         }
         radioNode.click();
         sleep(500);
         let phoneNumber = id("jp.naver.line.android:id/addfriend_by_userinfo_search_text").findOne(5000);
         phoneNumber.setText(phoneNumberArray[0]);
      } else {
         let radioNode = className("android.widget.RadioButton").text("Número de telefone").findOne(5000);
         if (!radioNode) {
            return -4;
         }
         radioNode.click();
         sleep(500);

         let countryCodeNode = id("jp.naver.line.android:id/addfriend_by_userid_country_code").findOne(5000);
         console.log("国家：", countryCodeNode.text(), "--", phoneNumberArray[0]);
         if (countryCodeNode && countryCodeNode.text() != phoneNumberArray[0]) {
            let countryCodeNode = id("jp.naver.line.android:id/addfriend_by_userid_select_country_code_click_area").findOne(5000);
            if (countryCodeNode && countryCodeNode.click()) {
               findCountry(phoneNumberArray[0]);
            }
            sleep(500);
         }
         let phoneNumber = id("jp.naver.line.android:id/addfriend_by_userinfo_search_text").findOne(5000);
         phoneNumber.setText(phoneNumberArray[1]);
         sleep(500);
      }

      console.log(5);
      let addFriendSearchNode = id("jp.naver.line.android:id/addfriend_search_button").findOne(5000);
      if (!addFriendSearchNode || !addFriendSearchNode.click()) {
         return -4;
      }
      sleep(500);

      console.log(6);
      //  失败
      // text("Usuário não encontrado").findOne(5000);
      // 成功
      let chatAddFriendNode = id("jp.naver.line.android:id/addfriend_add_button").findOne(5000);
      if (null == chatAddFriendNode || (chatAddFriendNode && !chatAddFriendNode.click())) {
         return -30;
      }
      sleep(500);

      console.log(7);
      // 不同操作不同动作
      switch (opt) {
         case 1:
            return sendMsg(indexI, indexJ);
         case 2:
            return checkReply(indexI, indexJ);
         case 3:
            break;
      }
   } catch (error) {
      return -5;
   }

}
function checkReply(indexI, indexJ) {
   let oneData = tmpTaskList[indexI].task_data[indexJ];
   console.log("检查回复");
   try {
      //   var response = utils.startTalk(oneData.detail_id, list.join(","), containsImg ? 1 : 0, 0);
      let editNode = id("jp.naver.line.android:id/chat_ui_message_edit").findOne(5000);
      if (!editNode) {
         return -4;
      }
      let msgListNode = id("jp.naver.line.android:id/chathistory_message_list").findOne(5000);
      if (msgListNode) {
         let tmpMsgList = msgListNode.children().reverse();
         let targetUserMsg = "";

         try {
            tmpMsgList.forEach(function (child) {
               let tmpSendMsgTimeNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_timestamp"));
               if (tmpSendMsgTimeNode) {
                  console.info("时间距离5：", tmpSendMsgTimeNode.bounds().centerX(), device.width);
                  let tmpTextNode = child.findOne(id("jp.naver.line.android:id/chat_ui_message_text"));
                  let leftMsgNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_message_layout"));
                  console.log("时间比较：", tmpSendMsgTimeNode.text(), oneData.lastSendTimeText);
                  if (tmpSendMsgTimeNode.text() == oneData.lastSendTimeText && leftMsgNode && leftMsgNode.bounds().centerX() > device.width / 2) {
                     console.log("跳过了");
                     throw new Error();
                  }

                  console.log("存在", leftMsgNode.bounds(), leftMsgNode.bounds().centerX(), device.width);
                  if (leftMsgNode && (leftMsgNode.bounds().centerX() - 431) < device.width / 2 && tmpSendMsgTimeNode.text() >= oneData.lastSendTimeText) {
                     if (tmpTextNode) {
                        console.log("存在", tmpTextNode.text());
                        targetUserMsg = tmpTextNode.text() + "," + targetUserMsg;
                     } else {
                        containsImg = 1;
                        targetUserMsg = targetUserMsg + "*" + ",";
                     }
                  }

                  // let tmpTimeText = tmpSendMsgTimeNode.text().split(":");
                  // let newTime = new Date();
                  // newTime.setHours(tmpTimeText[0]);
                  // newTime.setMinutes(tmpTimeText[1]);
                  // console.info("时间对比：", newTime.getTime(), oneData.lastSendTime);
                  // if (newTime.getTime() > oneData.lastSendTime) {
                  //    let tmpTextNode = child.findOne(id("jp.naver.line.android:id/chat_ui_message_text"));
                  //    let leftMsgNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_message_layout"));

                  //    // let tmpImgNode =   child.findOne(id("jp.naver.line.android:id/chat_ui_row_image"));
                  //    if (leftMsgNode && leftMsgNode.bounds().centerX() < device.width / 2) {
                  //       if (tmpTextNode) {
                  //          targetUserMsg = targetUserMsg + tmpTextNode.text() + ",";
                  //       } else {
                  //          containsImg = 1;
                  //          targetUserMsg = targetUserMsg + "*" + ",";
                  //       }

                  //    }
                  // }
               }
            });
         } catch (error) {

         }

         console.log("回复消息：", targetUserMsg);
         if (targetUserMsg !== "") {
            console.info("有回复");
            //   有回复
            // tmpTaskList[indexI].task_data[indexJ].message = targetUserMsg;
            let response = utils.startTalk(oneData.detail_id, targetUserMsg, containsImg, 0);
            if (response == null || response.length == 0) {
               return -100;
            }
            // let response = { text: ["好的", "那下次吧"] };
            return sendAIMsg(indexI, indexJ, response);
         } else {
            let offset = Date.now() - oneData.lastSendTime / 1000;
            console.log("收到的回复/时间差：", targetUserMsg, offset, config.reply_timeout);
            if (offset > config.reply_timeout) {
               // console.info("无回复并超时"); return -100;
               let response = utils.startTalk(oneData.detail_id, targetUserMsg, containsImg, 1);
               if (response == null || response.length == 0) {
                  return -100;
               }
               return sendAIMsg(indexI, indexJ, response);
            } else {
               console.info("无回复继续");
               return 0;
            }
         }
      }
      // oneData
      return -4;
   } catch (error) {
      console.error(error);
      return -5;
   }
}
function sendMsg(indexI, indexJ) {
   let oneData = tmpTaskList[indexI].task_data[indexJ];
   try {
      let editNode = id("jp.naver.line.android:id/chat_ui_message_edit").findOne(5000);
      if (!editNode) {
         return -4;
      }
      if (oneData.text) {
         if (!tmpTaskList[indexI].task_data[indexJ].sendedList) {
            tmpTaskList[indexI].task_data[indexJ].sendedList = [];
         }
         // 发送
         for (let index = 0; index < oneData.text.length; index++) {
            console.info("发送过了:", tmpTaskList[indexI].task_data[indexJ].sendedList.includes(index), oneData.text[index]);
            if (oneData.sendedList && tmpTaskList[indexI].task_data[indexJ].sendedList.includes(index)) { continue; }
            let element = oneData.text[index];
            editNode.setText(element);
            sleep(500);
            let sendNode = id("jp.naver.line.android:id/chat_ui_send_button_image").findOne(5000);
            if (sendNode && sendNode.click()) {
               tmpTaskList[indexI].task_data[indexJ].sendedList.push(index);
               tools.storage.put(storeKey, tmpTaskList);
               sleep(500);
               // if (index + 1 < oneData.text.length) {
               let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
               sleep(randTime * 1000);
               // }
            }
         }

         let tmpArray = tmpTaskList[indexI].task_data[indexJ].sendedList;
         tools.storage.put(storeKey, tmpTaskList);

         // 检测
         let msgListNode = id("jp.naver.line.android:id/chathistory_message_list").findOne(5000);
         if (!tmpTaskList[indexI].task_data[indexJ].hasOwnProperty("oldSendTime")) {
            tmpTaskList[indexI].task_data[indexJ].oldSendTime = 0;
         }
         if (msgListNode) {
            let tmpMsgList = msgListNode.children().reverse();
            tmpArray = tmpArray.reverse();
            tmpArray.forEach(element => {
               try {
                  tmpMsgList.forEach(function (child) {
                     let tmpSendMsgNode = child.findOne(text(oneData.text[element]));
                     let leftMsgNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_message_layout"));
                     console.info("距离：", leftMsgNode.bounds().centerX(), device.width);
                     // if (tmpSendMsgNode && (leftMsgNode && leftMsgNode.bounds().centerX() - 431 > device.width / 2)) {
                     if (tmpSendMsgNode) {
                        console.log(tmpSendMsgNode.text());
                        let tmpSendMsgTimeNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_timestamp"));
                        if (tmpSendMsgTimeNode) {
                           console.info("时间距离：", tmpSendMsgTimeNode.bounds().centerX(), device.width);
                           tmpTaskList[indexI].task_data[indexJ].lastSendTimeText = tmpSendMsgTimeNode.text();
                           tmpTaskList[indexI].task_data[indexJ].lastSendTime = Date.now();
                           tools.storage.put(storeKey, tmpTaskList);
                           throw new Error();
                        }
                        return;
                     }
                  });
               } catch (error) {

               }
            });
         }

         if (tmpTaskList[indexI].task_data[indexJ].hasOwnProperty("lastSendTime") &&
            tmpTaskList[indexI].task_data[indexJ].lastSendTime >= tmpTaskList[indexI].task_data[indexJ].oldSendTime) {
            tmpTaskList[indexI].task_data[indexJ].oldSendTime = tmpTaskList[indexI].task_data[indexJ].lastSendTime;
            tools.storage.put(storeKey, tmpTaskList);
            return 1;
         }
         return -4;
      }
      return -4;
   } catch (error) {
      console.error(error);
      return -5;
   }
}

function exeGetInfo() {
   try {
      launchApp();
      console.log("getinfo---", 1);
      // let chatNode = selector().id("jp.naver.line.android:id/bnb_home_v2").findOne(5000);
      // console.info(chatNode);
      // console.log("getinfo---", 1);
      // let chatNode = id("jp.naver.line.android:id/bnb_home_v2").findOne(10000);
      // console.info(chatNode);
      // if (!chatNode) {
      //    return -4;
      // }

      // let chatNodeArea = chatNode.findOne(id("jp.naver.line.android:id/bnb_button_clickable_area"));
      console.log(1.1);
      let chatNodeArea = id("jp.naver.line.android:id/bnb_button_clickable_area").findOne(5000);
      if (!chatNodeArea || !chatNodeArea.click()) {
         return -4;
      }
      sleep(500);

      console.log("getinfo---", 1.1);
      let settingNode = id("jp.naver.line.android:id/settings_header_button").findOne(5000);
      if (!settingNode || !settingNode.click()) {
         return -4;
      }
      sleep(500);

      console.log("getinfo---", 2);
      let settingListNode = id("jp.naver.line.android:id/setting_list").findOne(5000);
      if (!settingListNode) {
         return -4;
      }
      console.log("getinfo---", 3);
      let selfInfoNode = settingListNode.children()[1];
      if (!selfInfoNode || !selfInfoNode.click()) {
         return -4;
      }
      sleep(5000);
      console.log("getinfo---", 4);
      let selfInfoListNode = descStartsWith("ID,").findOne(5000);
      if (selfInfoListNode) {
         console.log("getinfo---", 4.1);
         selfId = selfInfoListNode.desc();
         console.log("自己号码：", selfId);

         if (selfId) {
            return 1;
         }
      }
      return -10;
   } catch (error) {
      console.error(error);
      return -5;
   }
}


//module.exports = instance;
