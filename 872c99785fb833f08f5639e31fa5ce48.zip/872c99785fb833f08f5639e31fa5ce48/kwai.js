var tools = require("./tools.js");
var utils = require("./utils.js");
var storage = storages.create("openstack_kwai_storage");
// kwai userId
var ex_account = "";
var fileDicPath = "/storage/emulated/0/DCIM/Camera/";
var publishVideoOk = true;
var modifyIntroOk = true;
var isOver = false;

events.on("say", function (data) {
   handle(data);
});

events.on("pauseTask", function (data) {
   console.log("pauseTask================================");
   isOver = true;
   try {
      engines.myEngine().forceStop();
      threads.shutDownAll();
      exit();
   } catch (e) {
      console.error(e);
   }
});

//保持脚本运行
var runing = setInterval(() => {
   console.log("定时");
   if (isOver) {
      clearInterval(runing);
   }
}, 1000);

// 启动Kwai
function launchKwaiApp() {
   var intent = new Intent();
   intent.setClassName("com.kwai.video", "com.yxcorp.gifshow.tiny.TinyLaunchActivity");
   intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
   context.startActivity(intent);
};

// 程序运行入口
function handle(data) {
   // engines.stopAll()
   auto.waitFor();
   launchKwaiApp();
   while (!id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click());
   id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click()
   ex_account = id("com.kwai.video.basis:id/tv_user_id").findOne().text();
   console.log("kwai=", '用户id=', ex_account);
   console.log("kwai=", '任务=' + JSON.stringify(data));
   data.list.forEach(value => {
      if (value.task_type == 3) {
         publishVideoOk = false;
      } else if (value.task_type == 5) {
         modifyIntroOk = false;
      }
   });
   data.list.forEach(task => {
      if (task.task_type == 3) {
         var config = task.config;
         for (var index = 0; index < task.task_data.length; index++) {
            console.log("kwai=", "发布视频");
            var publishVideoIndex = storage.get("task_data_publish_index");
            if (publishVideoIndex == undefined || (data.list.length == 1 && publishVideoIndex == 0)) {
               storage.clear();
               publishVideoIndex = -1;
            }
            console.log("kwai=", "发布视频索引 publishVideoIndex=" + publishVideoIndex + " index=" + index);
            if (publishVideoIndex == index) {
               // 已发布视频，但是未获取链接
               var saveTask = storage.get("task_data_video")
               if (saveTask != null && saveTask != undefined) {
                  getVideoLink(saveTask, index);
               } else {
                  getVideoLink(task, index);
               }
            } else if (publishVideoIndex < index) {
               // 未发布视频
               var downloadVideoPath = downloadVideo(task, index);
               while (!files.exists(downloadVideoPath));
               sleep(1000);
               console.log("kwai=", "当前视频下载路径=", "索引=" + index, downloadVideoPath);
               publishVideo(task, downloadVideoPath, index);
               if (config.post_interval.length == 2 && index < task.task_data.length - 1) {
                  let randTime = randomNum(config.post_interval[0], config.post_interval[1]);
                  console.log("kwai=", "等待下一个任务执行时间=" + randTime);
                  sleep(randTime * 1000);
               }
            }
         }
      } else if (task.task_type == 5) {
         for (var index = 0; index < task.task_data.length; index++) {
            console.log("kwai=", "修改资料");
            var modifyIndex = storage.get("task_data_modify_index");
            if (modifyIndex == undefined) {
               modifyIndex = -1;
            }
            if (modifyIndex <= index) {
               var saveTask = storage.get("task_data_intro");
               if (saveTask != null && saveTask !== undefined) {
                  modifyIntro(saveTask, index);
               } else {
                  modifyIntro(task, index);
               }
            }
         }
      }
   });
}

function downloadVideo(task, index) {
   var url = task.task_data[index].video;
   var fileArr = url.split('.');
   var fileType = fileArr[fileArr.length - 1];
   var fileName = "kwaiFile." + fileType;
   var file = fileDicPath + fileName;
   if (files.exists(file)) {
      tools.deleteDownloadFiles(file);
   }
   sleep(1000);
   var downloadVideoPath = tools.downloadFilesRename(url, "kwaiFile");
   console.log("kwai=", "下载完成");
   return downloadVideoPath
}

// 发布视频
function publishVideo(task, filePath, index) {
   console.log("kwai=", "publishVideo=", filePath, index)
   sleep(1000);
   while (!id("com.kwai.video.basis:id/id_record_layout").findOne().click());
   sleep(1000);
   id("com.kwai.video.ca_product:id/camera_album_tab").findOne().click()
   sleep(1000);
   click("Todos");
   click("All");
   click("全部");
   sleep(1000);
   id("com.kwai.video.basis:id/media_duration").findOne().parent().click();
   sleep(1000);
   while (!id("com.kwai.video.ca_product:id/edit_next_button").findOne().click());
   sleep(1000);
   while (!setText(0, "#" + task.task_data[index].tag + " " + task.task_data[index].paperwork));
   sleep(1000);
   click("Publicar");
   click("Post");
   click("发布");
   sleep(2000);
   task.task_data[index].result_text = "";
   task.task_data[index].result_image = "";
   task.task_data[index].status = 1;
   storage.put("task_data_video", task);
   while (id("com.kwai.video:id/progress_bar").exists())
      //while (!id("com.kwai.video:id/progress_bar").find().empty());
      //while (!id("com.kwai.video.basis:id/upload_cover").find().empty());
      console.log("kwai=", "视频发布完成", "索引=" + index, "视频本地路径=" + filePath);
   storage.put("task_data_publish_index", index);
   // 删除已经发布的视频
   tools.deleteDownloadFiles(filePath);
   sleep(1000)
   // 删除快手发布后产生的视频
   var photos = files.listDir(fileDicPath);
   if (photos.length > 0) {
      tools.deleteDownloadFiles(fileDicPath + photos[0]);
   }
   sleep(1000);
   if (!id("com.kwai.video.basis:id/tv_click_cancel").find().empty()) {
      id("com.kwai.video.basis:id/tv_click_cancel").findOne().click();
   }
   sleep(1000);
   var saveTask = storage.get("task_data_video")
   if (saveTask != null && saveTask != undefined) {
      getVideoLink(saveTask, index);
   } else {
      getVideoLink(task, index);
   }

};

// 修改简介
function modifyIntro(task, index) {
   while (!id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click());
   id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click()
   id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click()
   sleep(1000);
   while (!id("com.kwai.video.basis:id/profile_settings_layout").findOne().click());
   sleep(1000);
   while (!id("com.kwai.video.basis:id/intro_layout").findOne().click());
   sleep(1000);
   var userBio = task.task_data[index].text;
   console.log("kwai=", "修改简介", "文案=" + userBio);
   setText(0, userBio);
   sleep(1000);
   while (!id("com.kwai.video.basis:id/finish").findOne().click());
   console.log("kwai=", "资料修改成功!");
   storage.put("task_data_intro", task);
   storage.put("task_data_modify_index", index);
   sleep(1000);
   //    while(!back());
   while (!id("com.kwai.video.basis:id/left_btn").findOne().click());
   task.task_data[index].result_text = userBio;
   task.task_data[index].result_image = "";
   task.task_data[index].status = 1;
   if (index == task.task_data.length - 1) {
      modifyIntroOk = true;
      submitTaskToService(task);
      taskComplete();
   }
};

// 获取视频链接
function getVideoLink(task, index) {
   try {
      // 跳转到资料tab页面
      while (!id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click());
      id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click()
      id("com.kwai.video.basis:id/id_home_bottom_tab_me").findOne().click()
      sleep(2000);
      console.log("kwai=", "点击封面=1");
      // 点击已发布视频列表第一条封面
      while (!id("com.kwai.video.basis:id/tv_user_id").findOne().click());
      sleep(1000);
      while (!back());
      sleep(1000);
      while (!back());
      sleep(1000);
      //       while(!id("recycler_view").className("androidx.recyclerview.widget.RecyclerView").scrollable(true).findOne().findOne(id("com.kwai.video.basis:id/thumb")).click());
      while (!id("com.kwai.video.basis:id/thumb").findOne().click());
      console.log("kwai=", "点击封面=2");
      // 匹配文案
      var desc = task.task_data[index].paperwork;
      var tag = "#" + task.task_data[index].tag
      console.log("kwai=", "需要匹配的文案=", tag + " " + desc);
      var subStr = desc.substring(0, 7);
      sleep(1000);
      var count = 0;
      while (true) {
         if (textContains(tag).exists() && textContains(subStr).exists()) {
            break;
         } else {
            sleep(2000);
            while (!className("androidx.viewpager.widget.ViewPager").scrollable().findOne().scrollForward());
         }
      }
      while (true) {
         if (count > 5) {
            isOver = true;
            try {
               modifyIntroOk = true;
               submitTaskToService(task);
               taskComplete();
               engines.myEngine().forceStop();
               threads.shutDownAll()
               exit();
            } catch (e) {
               console.error(e);
            }
            break;
         }
         if (!textContains(tag).findOne().visibleToUser() && !textContains(subStr).findOne().visibleToUser()) {
            sleep(2000);
            count++;
            className("androidx.viewpager.widget.ViewPager").scrollable().findOne().scrollForward();
         } else {
            console.log("kwai=", "匹配成功的文案2=");
            break;
         }
      }
      var forwardList = id("com.kwai.video.basis:id/forward_button").find();
      console.log("kwai=", "分享按钮数量=", forwardList.length);
      for (var i = 0; i < forwardList.length; i++) {
         if (forwardList[i].visibleToUser()) {
            console.log("分享按钮点击")
            forwardList[i].click();
            break;
         }
      }
      sleep(1000);
      click("Copy Link");
      click("Copiar link");
      sleep(3000);
      while (!back());
      sleep(1000);
      while (!back());
      sleep(1000);
      while (!id("com.kwai.video.basis:id/profile_settings_layout").findOne().click());
      sleep(1000);
      while (!id("com.kwai.video.basis:id/intro_layout").findOne().click());
      sleep(1000);
      id("com.kwai.video.basis:id/input").findOne().setText("");
      id("com.kwai.video.basis:id/input").findOne().paste();
      sleep(2000);
      var clipLink = id("com.kwai.video.basis:id/input").findOne().text();
      console.log("kwai=", "分享内容~=" + clipLink);
      var link = getStrUrl(clipLink);
      console.log("kwai=", "链接获取成功~=" + link);
      task.task_data[index].result_text = link;
      task.task_data[index].result_image = "";
      task.task_data[index].status = 1;
      storage.put("task_data_video", task);
      while (!back());
      sleep(1000);
      while (!back());
      sleep(1000);
      while (!back());
      if (index == task.task_data.length - 1) {
         publishVideoOk = true;
         submitTaskToService(task);
         taskComplete();
      }
   } catch (e) {
      console.log("Error=" + e)
   }
};

// 提交数据到服务器
function submitTaskToService(task) {
   var obj = {
      "task_id": task.task_id, "has_continuous_fail": 0,
      "task_data": JSON.stringify(task.task_data), "ex_account": ex_account,
      "task_sub_id": task.task_sub_id
   };
   console.log("提交数据：", obj);

   utils.submitTask(obj);
   isOver = true;
};


//任务完成终止脚本
function taskComplete() {
   if (modifyIntroOk && publishVideoOk) {
      try {
         // if (tmpTaskList.length > 0) {
         //    tools.addStatus(tmpTaskList[0].pkgName);
         // }
         storage.clear();
         console.log("kwai=", "任务完成!");
         isOver = true;
         try {
            engines.myEngine().forceStop();
            threads.shutDownAll();
            exit();
         } catch (e) {
            console.error(e);
         }
      } catch (e) {
         console.log(e);
      }
   }
};

// 提取出网络地址
function getStrUrl(s) {
   var reg = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-)+)/g;
   var reg = /(https?|http|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/g;
   s = s.match(reg);
   return (s && s.length ? s[0] : null);
};

function isEmpty(e) {
   switch (e) {
      case "":
      case 0:
      case "0":
      case null:
      case false:
      case undefined:
         return true;
      default:
         return false;
   }
}

function randomNum(minNum, maxNum) {
   return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}

