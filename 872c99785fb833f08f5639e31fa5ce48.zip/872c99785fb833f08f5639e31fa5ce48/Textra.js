var utils = require("./utils.js");
var tools = require("./tools.js");
var storage = storages.create("openstack_textra_storage");

var context = context || {};
if (!context) {
    throw new Error("Context is not available");
}


var isText = JSON.parse(files.read("project.json")).build.is_debug || false;


var isOver = false;


events.on("say", function (data) {
    console.info('------------------------------say', JSON.stringify(data, null, 2));
    try {
        sendSmsList(data);
    } catch (e) {
        console.error("事件处理发生错误:", e);
        // if (!e.toString().includes("ScriptInterruptedException")) {
        //     throw e;
        // }
    }
});

events.on("stop", function () {
    console.log("强制结束");
    try {
        let globalTask = loadGlobalTask();
        if (globalTask) {
            //未执行的联系人设置为超时失败
            globalTask.task_data.forEach(item => {
                if (typeof item.status !== 'number') {
                    formatResult(item, "强制结束", BusinessErrorCodes.OTHER_FAILED);
                }
            });
            saveGlobalTask();
            checkAllTasksCompleted();
        }
    } catch (e) {
        console.error("强制结束时发生错误:", e);
    } finally {
        engines.myEngine().forceStop();
    }
})


//保持脚本运行
var runing = setInterval(() => {
    if (isOver) {
        clearInterval(runing);
    }
}, 1000);

// 简化配置对象
const CONFIG = {
    packageName: "com.textra",
    activityName: "com.mplus.lib.ui.main.Main",
    maxRetries: 10,
    retryInterval: 500,
    uiWaitTime: 1000,
    findOneTimeout: 1000
};

// 添加持久化相关的工具函数
const STORAGE_KEY = "textra_global_task";

// 添加新的存储键名常量
const MESSAGE_STATUS_KEY = "message_status_store";
const ACCOUNT_KEY = "textra_account";

function saveGlobalTask() {
    try {
        storage.put(STORAGE_KEY, JSON.stringify(globalTask));
        console.log("全局任务已保存到存储");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存全局任务失败:", e);
        throw e;
    }

}

function loadGlobalTask() {
    try {
        const savedTask = storage.get(STORAGE_KEY);
        return savedTask ? JSON.parse(savedTask) : null;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("加载全局任务失败:", e);
        throw e;
    }

}

// 添加消息状态管理的工具函数
function saveMessageStatus(taskSubId, account, messageIndex, status) {
    try {
        const statusKey = `${taskSubId}_${account}_${messageIndex}`;
        let statusStore = storage.get(MESSAGE_STATUS_KEY);
        let statusMap = statusStore ? JSON.parse(statusStore) : {};
        statusMap[statusKey] = status;
        storage.put(MESSAGE_STATUS_KEY, JSON.stringify(statusMap));
        console.log(`保存消息状态: ${statusKey} -> ${status}`);
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存消息状态失败:", e);
    }
}


function getMessageStatus(taskSubId, account, messageIndex) {
    try {
        const statusKey = `${taskSubId}_${account}_${messageIndex}`;

        let statusStore = storage.get(MESSAGE_STATUS_KEY);

        let statusMap = statusStore ? JSON.parse(statusStore) : {};

        let status = statusMap[statusKey] || MessageStatus.PENDING;

        return status;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("获取消息状态失败:", e);
        return MessageStatus.PENDING;
    }

}

function clearMessageStatuses() {
    try {
        storage.remove(MESSAGE_STATUS_KEY);
        console.log("清除所有消息状态记录");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除消息状态失败:", e);
    }
}


// 修改自定义错误类的实现
function OperationError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = true;
    }
    Error.call(this);
    this.name = 'OperationError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

OperationError.prototype = Object.create(Error.prototype);
OperationError.prototype.constructor = OperationError;

// 错误代码常量
const ErrorCodes = {
    APP_LAUNCH_FAILED: 1001,
    ELEMENT_NOT_FOUND: 1002,
    CLICK_FAILED: 1003,
    INPUT_FAILED: 1004,
    CONTACT_LIST_ERROR: 1005,
    CONTACT_SELECT_ERROR: 1006,
    AI_REPLY_FAILED: 1007,
    SEND_MESSAGE_FAILED: 1008
};

// 错误代码常量
const BusinessErrorCodes = {
    // 1-成功,2-其他失败 3-账号不存在,4-账号被封,5-APP未登录,6-控件未找到,7-结束语未发送成功,8-AI接口无返回,9-执行账号已被绑定
    SUCCESS: 1,
    OTHER_FAILED: 2,
    ACCOUNT_NOT_EXIST: 3,
    ACCOUNT_BLOCKED: 4,
    APP_NOT_LOGIN: 5,
    ELEMENT_NOT_FOUND: 6,
    END_MESSAGE_FAILED: 7,
    AI_REPLY_FAILED: 8,
    EXECUTION_ACCOUNT_BOUND: 9
};


// 修改自定义错误类的实现
function BusinessError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = false;
    }
    Error.call(this);
    this.name = 'BusinessError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

BusinessError.prototype = Object.create(Error.prototype);
BusinessError.prototype.constructor = BusinessError;

// 添加消息状态常量
const MessageStatus = {
    PENDING: 'pending',
    SENDED: 'sending',
    SUCCESS: 'success',
    FAILED: 'failed'
};

// 添加语言相关的常量
const BUTTON_TEXT = {
    SAVE: ["SALVAR", "SAVE", "保存"],
    COPY: ["COPIAR TEXTO", "COPY", "复制"],
    RETRY: ["REPETIR", "RETRY", "重试"]
};

// 添加一个获取随机间隔的辅助函数
function getRandomInterval(intervalArray) {
    // 如果是数字类型,直接返回
    if (typeof intervalArray === 'number') {
        console.error("间隔配置无效，使用默认值1秒");
        return intervalArray;
    }

    // 如果是数组类型,检查格式是否正确
    if (!Array.isArray(intervalArray) || intervalArray.length !== 2) {
        console.error("间隔配置无效，使用默认值1秒");
        return 1;
    }

    const [min, max] = intervalArray;
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// 启动应用函数
function goHome() {
    console.log("开始启动应用:", CONFIG.packageName);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试启动应用 (第" + (retries + 1) + "次)");
            app.startActivity({
                packageName: CONFIG.packageName,
                className: CONFIG.activityName,
                flags: ["activity_new_task", "activity_clear_task", "activity_clear_top"]
            });
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.APP_LAUNCH_FAILED,
                    "应用启动失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

function openChatWithContact(phoneNumber) {
    console.log("准备直接打开与联系人的聊天:", phoneNumber);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            goHome();
            sleep(CONFIG.uiWaitTime);

            waitAndClick(id(CONFIG.packageName + ":id/floating_button"), false, "开始聊天按钮");
            sleep(CONFIG.uiWaitTime);

            editPhoneNumber(phoneNumber);
            sleep(1000);

            clickFirstConcatItem();
            sleep(2000);
            back();
            return;
        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("打开聊天界面失败:", e);
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.APP_LAUNCH_FAILED,
                    "打开聊天界面失败: " + e.message
                );
            }
            console.log("第" + (retries + 1) + "次重试打开聊天界面");
            sleep(CONFIG.retryInterval);
        }
    }
}

// 等待并点击元素的通用函数
function waitAndClick(selector, useBounds, description) {
    console.log("开始等待并点击元素", description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                throw new OperationError(
                    ErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 未找到目标元素"
                );
            }

            sleep(500);
            if (useBounds) {
                var bounds = element.bounds();
                if (!bounds) {
                    throw new OperationError(
                        ErrorCodes.ELEMENT_NOT_FOUND,
                        description + " 获取元素边界失败"
                    );
                }
                click(bounds.centerX(), bounds.centerY());
            } else {
                element.click();
            }
            return;

        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new BusinessError(
                    BusinessErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 点击元素失败: " + e.message, true
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

// 选择联系人函数
function editPhoneNumber(phoneNumber) {
    console.log("开始输入手机号码:", phoneNumber);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let input = className("android.widget.EditText").findOne(CONFIG.findOneTimeout);
            if (!input) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "未找到输入框"
                );
            }
            input.setText("");
            if (!input.setText(phoneNumber)) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "输入手机号失败"
                );
            }
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "输入手机号码失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

// 查找联系人函数
function clickFirstConcatItem() {
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let contactList = id(CONFIG.packageName + ":id/quickContactsList").findOne(CONFIG.findOneTimeout);
            if (!contactList) {
                throw new OperationError(
                    ErrorCodes.CONTACT_LIST_ERROR,
                    "未找到联系人列表"
                );
            }

            let firstContact = contactList.child(0);
            if (!firstContact) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    "未找到第一个联系人"
                );
            }

            if (firstContact.findOne(id(CONFIG.packageName + ":id/contactNumber"))) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    "联系人项无效"
                );
            }

            if (!firstContact.click()) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    "点击联系人失败"
                );
            }
            return;
        } catch (e) {
            // 添加中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    e instanceof OperationError ? e.message : "选择联系人失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

// 修改发送消息的核心函数
function sendChatMessage(phoneNumber, message) {
    console.log("开始发送消息给:", phoneNumber);


    // 设置文本消息
    setTextSafely(id(CONFIG.packageName + ":id/send_text"), message, "聊天输入框");

    sleep(500);
    waitAndClick(id(CONFIG.packageName + ":id/rhs_button"), true, "发送按钮");

    // 记录发送时间并存储到本地
    let sendTime = new Date().getTime();
    storage.put("message_send_time_" + phoneNumber, sendTime);
    console.log("消息发送时间已记录:", sendTime);
}

// 修改处理单个联系人的所有消息函数
function contactSendMessages(contactItem, taskData) {
    console.log("准备发送消息到: " + contactItem.account);

    let retryCount = 0;
    const MAX_RETRIES = 2;

    while (retryCount <= MAX_RETRIES) {
        try {
            retryCount++;
            // 发送联系人的所有消息内容
            for (let i = 0; i < contactItem.text.length; i++) {
                let messageText = contactItem.text[i];
                let currentStatus = getMessageStatus(globalTask.task_sub_id, contactItem.account, i);

                // 跳过已处理的消息
                if (currentStatus === MessageStatus.SUCCESS || currentStatus === MessageStatus.FAILED) {
                    console.log(`跳过已处理的消息 ${i}，状态为:`, currentStatus);
                    continue;
                }

                console.log(`开始发送消息 ${i}，当前状态:`, currentStatus);
                if (!currentStatus || currentStatus === MessageStatus.PENDING) {
                    // 发送消息
                    sendChatMessage(contactItem.account, messageText);
                    saveMessageStatus(globalTask.task_sub_id, contactItem.account, i, MessageStatus.SENDED);
                }

                const randomInterval = getRandomInterval(globalTask.config.single_interval);
                console.log("等待随机间隔时间:", randomInterval, "秒");
                sleep(randomInterval * 1000);
            }
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                console.log("检测到脚本中断");
                throw e;
            }

            console.error(`操作失败: [${e.code}] ${e.message}`);
            retryCount++;
            if (retryCount <= MAX_RETRIES) {
                console.log("准备第" + retryCount + "次重试");
                sleep(CONFIG.retryInterval);
            } else {
                throw e;
            }
        }
    }
}

// 格式化结果的辅助函数
function formatResult(contact, message, status) {
    console.log("处理结果:", contact.account, message, status);
    contact.result_text = message;
    contact.result_image = "";
    contact.status = status;
    return contact;
}

function isSayHelloSendFailed(currentContact) {
    // 检查是否有待处理的回复消息或者所有消息都是失败状态
    let allFailed = currentContact.text.every((msg, index) => {
        let status = getMessageStatus(globalTask.task_sub_id, currentContact.account, index);
        return status === MessageStatus.FAILED;
    });
    return allFailed;

}

// 修改处理消息组函数中的间隔处理
function processItemTask(currentContact, account_interval, taskData) {
    let retryCount = 0;
    const MAX_RETRIES = 1;

    while (retryCount <= MAX_RETRIES) {
        try {
            //如果联系人已经有状态，或者所有消息发送失败，则跳过
            if (typeof currentContact.status === 'number') {
                console.log(`跳过处理: status=${currentContact.status}`);
                return;
            }
            openChatWithContact(currentContact.account);
            //检查打招呼消息是否发送成功
            isSayHelloSuccess(currentContact);
            let allMessagesSent = currentContact.text.every((msg, index) => {
                let status = getMessageStatus(globalTask.task_sub_id, currentContact.account, index);
                return status === MessageStatus.SUCCESS || status === MessageStatus.FAILED || status === MessageStatus.SENDED;
            });

            console.log("联系人:", currentContact.account, "消息状态检查结果:", allMessagesSent ? "全部已处理" : "有未处理消息");
            if (allMessagesSent) {
                console.log("跳过已处理的联系人:", currentContact.account, "所有消息都已发送");
                // 检查是否至少有一条消息发送成功
                let hasAnySuccess = currentContact.text.some((msg, index) => {
                    let status = getMessageStatus(globalTask.task_sub_id, currentContact.account, index);
                    return status === MessageStatus.SUCCESS;
                });

                if (hasAnySuccess) {
                    console.log("至少有一条消息发送成功,设置联系人状态为成功");
                    formatResult(currentContact, "发送成功", 1);
                    saveGlobalTask();
                }
            } else {
                console.log("开始发送打招呼消息:", currentContact.account);
                contactSendMessages(currentContact, taskData);

                if (account_interval) {
                    // 获取随机间隔时间
                    const randomInterval = getRandomInterval(account_interval);
                    console.log("等待随机间隔时间:", randomInterval, "秒");
                    sleep(randomInterval * 1000);
                }
            }
            break;
        } catch (innerError) {
            if (innerError.toString().includes("ScriptInterruptedException")) {
                throw innerError;
            }
            // 检查是否是我们自定义的业务异常
            if (innerError instanceof OperationError) {
                console.error(innerError);
                // 检查是否需要重试
                if (!innerError.retryable) {
                    formatResult(currentContact, "发送失败: " + innerError.message, BusinessErrorCodes.OTHER_FAILED);
                    saveGlobalTask();
                    throw innerError;
                }
            }


            if (innerError instanceof BusinessError) {
                console.log("发送失败: " + innerError.message);
                formatResult(currentContact, "发送失败: " + innerError.message, innerError.code);
                saveGlobalTask();
                return;
            }

            // 进入重试逻辑
            retryCount++;
            console.error(`处理失败 (第${retryCount}次)`);
            if (retryCount <= MAX_RETRIES) {
                console.error(innerError);
                console.log(`准备第${retryCount}次重试...`);
                sleep(CONFIG.retryInterval);
                continue;
            }

            formatResult(currentContact, "发送失败: " + innerError.message, innerError instanceof BusinessError ? innerError.code : BusinessErrorCodes.OTHER_FAILED);
            saveGlobalTask();
            throw innerError;
        }
    }
}

function isSayHelloSuccess(currentContact) {
    console.log("检查打招呼消息是否发送成功:", currentContact.account);
    for (let i = 0; i < currentContact.text.length; i++) {
        let messageText = currentContact.text[i];
        let currentStatus = getMessageStatus(globalTask.task_sub_id, currentContact.account, i);
        // 如果消息状态为发送中,需要检查发送状态
        if (currentStatus === MessageStatus.SENDED || currentStatus === MessageStatus.FAILED) {
            console.log("检查消息发送状态:", messageText);
            try {
                let messageSentSuccessfully = getResultCheck({ text: messageText });
                if (messageSentSuccessfully) {
                    saveMessageStatus(globalTask.task_sub_id, currentContact.account, i, MessageStatus.SUCCESS);
                } else {
                    saveMessageStatus(globalTask.task_sub_id, currentContact.account, i, MessageStatus.FAILED);
                }
            } catch (e) {
                if (e.toString().includes("ScriptInterruptedException")) {
                    throw e;
                }
                console.error("检查消息状态时出错:", e);
                saveMessageStatus(globalTask.task_sub_id, currentContact.account, i, MessageStatus.FAILED);
            }
            continue;
        }
    }
}

// 主要处理函数
function sendSmsList(data) {

    if (isText) {
        // 更新测试数据
        data = {
            "list": [{
                "name": "TGAI私信 ",
                "app_id": 10,
                "config":
                {
                    "has_paid": 1,
                    "reply_timeout": 1,
                    "single_interval":
                        5,
                    "account_interval":
                        3
                },
                "task_id": 15,
                "has_paid": 1,
                "task_data":
                    [
                        {
                            "text":
                                [
                                    "嘿~ 刚刷到你在推特，聊聊？"
                                ],
                            "account": "(",
                            "detail_id": 1826
                        },
                        {
                            "text":
                                [
                                    "嘿~ 刚刷到你在推特，聊聊？"
                                ],
                            "account": ")",
                            "detail_id": 1827
                        }
                    ],
                "task_type": 8,
                "task_length": 5,
                "task_sub_id": 234,
                "times_stop_begin": 0,
                "continuous_fail_stop": 0
            }]
        };
        // 确保在处理新任务前清除数据
        // let cleanResult = cleanALLLocalData();

    }



    if (isOver) {
        console.log("任务已完成");
        return;
    }

    try {
        // checkSendResultStatusSetting();
        console.log("接收到的原始数据:", JSON.stringify(data, null, 2));
        const newTask = data.list[0];

        // 声明为全局变量
        globalTask = loadGlobalTask();

        console.log("加载的本地globalTask:", JSON.stringify(globalTask, null, 2));

        // 检查是否需要提交之前的任务结果
        if (!globalTask || (newTask && newTask.task_sub_id !== globalTask.task_sub_id)) {
            console.log("检测到新任务");
            if (globalTask && globalTask.task_data) {  // 添加额外检查
                console.log("准备上传旧任务结果...");
                try {
                    submitTasks(globalTask, false);
                    console.log("旧任务结果上传完成");
                } catch (e) {
                    console.error("提交任务失败:", e);
                }
                cleanALLLocalData();
                console.log("旧任务结果上传完成");
            }

            globalTask = newTask;
            saveGlobalTask();
            console.log("新任务已保存:");
            if (false) {
                let phoneNumbers = toGetAccount();
                storage.put(ACCOUNT_KEY, phoneNumbers);
                console.log("已保存账号到本地存储");
            } else {
                try {
                    bindAccount(globalTask.app_id);
                } catch (e) {
                    if (e.toString().includes("ScriptInterruptedException")) {
                        throw e;
                    } else if (e instanceof BusinessError && e.code == BusinessErrorCodes.EXECUTION_ACCOUNT_BOUND) {
                        console.log("检测到账号已被绑定,将所有任务标记为已绑定状态");
                        if (globalTask && globalTask.task_data) {
                            globalTask.task_data.forEach(item => {
                                formatResult(item, "账号已被绑定", BusinessErrorCodes.EXECUTION_ACCOUNT_BOUND);
                            });
                            console.log("保存全局任务状态");
                            saveGlobalTask();
                        }
                        return;
                    } else {
                        console.error("绑定账号失败:", e);
                    }
                }
            }

            if (!isText) {
                checkSendResultStatusSetting();
            }
        }

        var config = newTask.config;
        console.log("任务配置:", config);

        console.log("utils.forceStop:", utils.forceStop);
        if (utils.forceStop == true) {
            //未执行的联系人设置为超时失败
            globalTask.task_data.forEach(item => {
                if (typeof item.status !== 'number') {
                    formatResult(item, "强制结束", BusinessErrorCodes.OTHER_FAILED);
                }
            });
            saveGlobalTask();
            return;
        }



        for (var i = 0; i < globalTask.task_data.length; i++) {
            console.log(`开始处理第${i + 1}组消息，共${globalTask.task_data.length}组`);
            try {
                processItemTask(
                    globalTask.task_data[i],
                    config.account_interval,
                    globalTask
                );
            } catch (error) {
                if (error.toString().includes("ScriptInterruptedException")) {
                    throw error;
                }
                console.error(`处理第${i + 1}组消息失败:`, error);
                continue;
            }
            console.log(`第${i + 1}组消息全部完成，进度:${i + 1}/${globalTask.task_data.length}`);
        }
        //本地记录当前时间，如果没有记录，则记录当前时间
        if (!storage.get("last_send_time")) {
            storage.put("last_send_time", new Date().toISOString());
        }

        let lastSendTime = storage.get("last_send_time");
        console.log("lastSendTime:", lastSendTime);
        let timeout = 3 * 60 * 1000;
        if (isText) {
            timeout = 1 * 60 * 1000;
        }
        let isTimeout = lastSendTime && new Date().getTime() - new Date(lastSendTime).getTime() >= timeout;
        console.log("本地记录的时间是否大于三分钟:", isTimeout);
        if (isTimeout) {
            for (var i = 0; i < globalTask.task_data.length; i++) {
                let currentContact = globalTask.task_data[i];
                if (typeof currentContact.status === 'number') {
                    continue;
                }
                // 检查是否有任何一条消息发送成功
                let hasSuccess = currentContact.text.some((msg, index) => {
                    let status = getMessageStatus(globalTask.task_sub_id, currentContact.account, index);
                    return status === MessageStatus.SUCCESS;
                });

                if (hasSuccess) {
                    console.log("至少有一条消息发送成功,设置联系人状态为成功");
                    formatResult(currentContact, "发送成功", BusinessErrorCodes.SUCCESS);
                } else {
                    console.log("所有消息均未发送成功,设置联系人状态为失败");
                    formatResult(currentContact, "发送失败", BusinessErrorCodes.OTHER_FAILED);
                }
                saveGlobalTask();
            }
        }
    } catch (e) {
        // 检查是否是脚本中断异常
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("处理任务失败:", e);
    } finally {
        try {
            checkAllTasksCompleted();
        } catch (e) {
            console.error("检查任务完成状态时出错:", e);
        } finally {
            isOver = true;
            console.log("执行完成");
        }
    }
}

function checkSendResultStatusSetting() {
    console.log("检查发送结果状态");
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试检查发送结果状态设置 (第" + (retries + 1) + "次)");
            goHome();
            sleep(2000);
            waitAndClick(id(CONFIG.packageName + ":id/overflow_item"), false, "菜单按钮");
            sleep(1000);
            waitAndClick(id(CONFIG.packageName + ":id/settings_menu_item"), false, "设置按钮");
            sleep(1000);
            waitAndClick(textMatches(/(短信|SMS)/), true, "短信设置");
            sleep(2000);
            console.log("检查并设置发送结果状态复选框");
            let checkboxSms = id("com.textra:id/checkbox").findOne(5000);
            if (!checkboxSms) {
                throw new OperationError(
                    ErrorCodes.ELEMENT_NOT_FOUND,
                    "未找到发送结果状态复选框"
                );
            }
            if (!checkboxSms.checked()) {
                console.log("复选框未选中,准备点击选中");
                waitAndClick(id(CONFIG.packageName + ":id/checkbox"), true, "短信设置复选框");
                checkboxSms.click();
                sleep(500);
            } else {
                console.log("复选框已经选中,无需操作");
            }
            sleep(1000);
            back();
            sleep(1000);
            waitAndClick(textMatches(/(彩信|MMS)/), true, "彩信设置");
            sleep(1000);
            let checkboxMms = id("com.textra:id/checkbox").findOne(5000);
            if (!checkboxMms) {
                throw new OperationError(
                    ErrorCodes.ELEMENT_NOT_FOUND,
                    "未找到发送结果状态复选框"
                );
            }
            if (!checkboxMms.checked()) {
                console.log("复选框未选中,准备点击选中");
                waitAndClick(id(CONFIG.packageName + ":id/checkbox"), true, "彩信设置复选框");
                sleep(500);
            } else {
                console.log("复选框已经选中,无需操作");
            }
            return; // 成功完成所有操作后退出
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("检查发送结果状态设置失败 (第" + (retries + 1) + "次):", e);
            retries++;
            if (retries < CONFIG.maxRetries) {

                sleep(CONFIG.retryInterval);
                continue;
            }
            throw e; // 达到最大重试次数时抛出异常
        }
    }
}

function cleanALLLocalData() {
    console.log("开始清除所有本地数据");
    try {

        // 清除全局任务数据
        storage.remove(STORAGE_KEY);
        console.log("已清除全局任务数据");

        // 清除消息状态记录
        clearMessageStatuses();

        // 清除账号信息
        storage.remove(ACCOUNT_KEY);
        console.log("已清除账号信息");
        //清除本地记录的时间
        storage.remove("last_send_time");
        console.log("已清除本地记录的时间");

        // 直接清除storage对象并重新创建
        storage.clear();

        console.log("所有本地数据已清除");

        // 验证清除结果
        if (storage.get(STORAGE_KEY)) {
            console.warn("警告: 数据未能完全清除");
            return false;
        }

        return true;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除本地数据时发生错误:", e);
        console.error("错误堆栈:", e.stack);
        return false;
    }
}

// 修改上传结果函数
function submitTasks(task, isRetry) {
    if (isRetry === undefined) {
        isRetry = true;
    }
    if (!task || !task.task_data) {
        console.error("无效的任务数据，取消上传");
        return;
    }

    const MAX_RETRIES = 2;  // 最大重试次数
    const RETRY_DELAY = 1000;  // 重试间隔时间(毫秒)
    let retryCount = 0;

    while (retryCount < MAX_RETRIES) {
        try {
            console.log(`开始上传任务结果... (尝试 ${retryCount + 1}/${MAX_RETRIES})`);
            var obj = {
                "task_id": task.task_id,
                "has_continuous_fail": 0,
                "task_data": JSON.stringify(task.task_data),
                "ex_account": storage.get(ACCOUNT_KEY) || "",
                "task_sub_id": task.task_sub_id
            };
            console.log("准备上传的任务结果:", JSON.stringify(obj));

            utils.submitTask(obj);
            console.log("任务结果上传成功");
            return;  // 上传成功，退出函数

        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;  // 脚本中断异常直接抛出
            }

            retryCount++;
            console.error(`上传任务失败 (第${retryCount}次): ${e}`);

            if (retryCount < MAX_RETRIES) {
                console.log(`${RETRY_DELAY / 1000}秒后进行第${retryCount + 1}次重试...`);
                sleep(RETRY_DELAY);
            } else {
                console.error("上传任务达到最大重试次数，放弃重试");
                throw e;  // 重试次数用完后抛出最后一次的错误
            }
        }
    }
}


// 设置文本的通用函数
function setTextSafely(selector, text, description) {
    console.log("开始设置文本:", text, description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试设置文本 (第" + (retries + 1) + "次)", description);

            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                console.error("未找到输入框元素", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "未找到输入框元素", description);
            }

            sleep(500);
            element.setText("");
            sleep(200);
            let success = element.setText(text);
            if (!success) {
                console.error("设置文本失败", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "设置文本失败", description);
            }
            console.log("文本设置成功");
            return;
        } catch (e) {
            // 修改中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries < CONFIG.maxRetries) {
                sleep(CONFIG.retryInterval);
                continue;
            }
            throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败: " + e.message, description, true);
        }
    }
    throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败，已达到最大重试次数", description, true);
}

function getResultCheck(messageItem) {
    let retryAttempts = 0;
    const MAX_RETRIES = 3;

    while (retryAttempts < MAX_RETRIES) {
        try {
            let messageList = id(CONFIG.packageName + ":id/messageList").findOne(CONFIG.findOneTimeout);
            if (!messageList) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "消息列表不存在");
            }

            if (messageList.childCount() <= 0) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "消息列表为空");
            }

            let lastMessage = messageList.child(messageList.childCount() - 1);
            if (!lastMessage) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "无法获取最后一条消息");
            }
            if (messageItem.image) {
                if (lastMessage.findOne(textContains("已发送"))) {
                    return true;
                }
                return false;
            } else {
                // 获取当前可见的消息
                let messageElements = id("com.textra:id/row").find();
                console.log("找到的元素:", messageElements.length);
                for (let item of messageElements) {
                    if (!item) {
                        console.log("消息元素为空,跳过处理");
                        continue;
                    }
                    let bubble = item.findOne(id("com.textra:id/bubble"));
                    if (!bubble) {
                        console.log("警告：项目中未找到气泡内容");
                        continue;
                    }
                    // 获取消息容器的布局信息
                    let bubbleBounds = bubble.bounds();
                    let itemBounds = item.bounds();
                    // 遍历所有气泡,查找匹配的消息
                    let isLeftAligned = bubbleBounds.left < (itemBounds.right / 5);

                    let currentText = bubble.text();

                    // 获取换行符前的文本进行比较
                    let currentMessageText = currentText.split('\n')[0];

                    // 检查消息文本是否完全匹配
                    if (!isLeftAligned && currentMessageText && currentMessageText === messageItem.text) {
                        console.log("找到右侧匹配消息文本");
                        // 使用统一的消息状态匹配模式
                        const DELIVERY_STATUS = {
                            patterns: [
                                /.*\n\.已送达.*/,  // 中文
                                /.*\n\.Entregue.*/, // 葡萄牙语
                                /.*\n\.Delivered.*/ // 英文
                            ]
                        };

                        if (DELIVERY_STATUS.patterns.some(pattern => pattern.test(currentText))) {
                            console.log("找到匹配消息并确认送达");
                            return true;
                        }
                    }
                }
                console.log("未找到匹配的消息");
                return false;
            }
        } catch (e) {
            // 检查脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("检查消息结果时发生错误:", e);
            retryAttempts++;
            if (retryAttempts >= MAX_RETRIES) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "检查消息结果失败: " + e.message);
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

function checkAllTasksCompleted() {
    // 简化检查逻辑，只检查每个联系人的status
    if (globalTask && globalTask.task_data) {
        let allTasksCompleted = globalTask.task_data.every(contact => typeof contact.status === 'number'
        );
        if (allTasksCompleted) {
            console.log("所有任务消息已完成发送,准备上传结果");
            submitTasks(globalTask);
            console.log("上传结果成功");
            cleanALLLocalData();
            console.log("全局任务已清除");
            tools.addStatus(globalTask.pkgName);
            console.log("添加状态成功");
        } else {
            console.log("仍有未完成的消息任务");
        }
    } else {
        console.log("没有任务数据");
    }
}

function bindAccount(appId) {
    goHome();
    sleep(3000);
    let phoneNumbers = [];
    waitAndClick(id("com.textra:id/overflow_item"), false, "点击菜单按钮");
    sleep(1000);
    waitAndClick(id("com.textra:id/settings_menu_item"), true, "点击设置按钮");
    sleep(1000);
    let screenHeight = device.height;
    let retryCount = 0;
    const MAX_RETRIES = 3;

    while (phoneNumbers.length === 0 && retryCount < MAX_RETRIES) {
        swipe(device.width / 2, screenHeight * 0.7, device.width / 2, screenHeight * 0.6, 300);
        sleep(2000);

        let childs = className("android.widget.LinearLayout").find();
        for (let item of childs) {
            let text = item.findOne(textMatches("Your Mobile Number.*|你的手机号码.*|Seu número de celular.*|Número do Seu Celular.*"));
            if (text) {
                let summarys = item.find(id("android:id/summary"));
                if (!summarys || summarys.length != 1) {
                    continue;
                }
                let accountStr = summarys[0].text();
                console.log("获取到当前账号手机号码:", accountStr);

                if (accountStr && accountStr.trim() != '') {
                    if (phoneNumbers.includes(accountStr)) {
                        continue;
                    }
                    phoneNumbers.push(accountStr);
                }
            }
        }

        retryCount++;
        console.log(`第 ${retryCount} 次尝试获取手机号码，当前获取到: ${phoneNumbers.length} 个号码`);

        if (phoneNumbers.length === 0 && retryCount < MAX_RETRIES) {
            console.log("未获取到手机号码，准备重试...");
            sleep(1000);
        }
    }
    console.log("获取到的手机号码:", phoneNumbers);
    // 存储账号
    storage.put(ACCOUNT_KEY, phoneNumbers);
    console.log("已保存账号到本地存储");
    // 过滤掉带方括号的号码
    phoneNumbers = phoneNumbers.filter(number => !number.match(/^\[.*\]$/));
    console.log("过滤后的手机号码:", phoneNumbers);

    // 如果没有获取到号码，使用默认空值尝试一次
    if (phoneNumbers.length === 0) {
        console.error("未获取到手机号码");
        return;
    }

    // 遍历所有号码尝试绑定
    let bindResults = [];
    for (let accountStr of phoneNumbers) {
        try {
            console.log("尝试绑定账号:", accountStr);
            let result = utils.bindAccount(appId, accountStr, globalTask.task_sub_id, "账号绑定：" + accountStr);
            if (result == -100) {
                bindResults.push({
                    account: accountStr,
                    result: -1
                });
                utils.addBindFail(globalTask.pkgName, 1);
            } else {
                bindResults.push({
                    account: accountStr,
                    result: 1
                });
            }
        } catch (e) {
            console.error("绑定账号时出错:", e);
            bindResults.push({
                account: accountStr,
                result: 1
            });
        }
    }

    // 检查是否所有绑定都失败
    let allFailed = bindResults.every(r => r.result !== 1);
    if (allFailed) {
        throw new BusinessError(BusinessErrorCodes.EXECUTION_ACCOUNT_BOUND, "所有账号绑定失败");
    }

    console.log("绑定结果:", bindResults);
}

function toGetAccount() {
    let phoneNumbers = [];
    try {
        // 尝试获取SIM1的号码
        let sim1 = context.getSystemService(android.content.Context.TELEPHONY_SERVICE)
            .getLine1Number();
        if (sim1) {
            phoneNumbers.push(sim1);
        }

        // 尝试获取SIM2的号码
        let sim2 = context.getSystemService(android.content.Context.TELEPHONY_SUBSCRIPTION_SERVICE)
            .getActiveSubscriptionInfoList()
            .get(1)
            .getNumber();
        if (sim2) {
            phoneNumbers.push(sim2);
        }
    } catch (e) {
        console.log("获取手机号码时出错:", e);
    }

    console.log("获取到的手机号码:", phoneNumbers);
    return phoneNumbers;
}


if (isText) {
    sendSmsList("");
}
