var instance = {};

// 缓存已经创建的日志文件路径
instance.logFileCache = {};

instance.startRecordLog = function (taskId, filename) {
  // 如果已经为该 taskId 创建了日志文件，则直接返回路径
  if (this.logFileCache[taskId]) {
    console.info("日志文件已存在，路径为：" + this.logFileCache[taskId]);
    return this.logFileCache[taskId];
  }

  // 生成当前时间
  var today = new Date();
  var DD = String(today.getDate()).padStart(2, '0');
  var MM = String(today.getMonth() + 1).padStart(2, '0');
  var yyyy = today.getFullYear();
  var hh = String(today.getHours()).padStart(2, '0');
  var mm = String(today.getMinutes()).padStart(2, '0');
  var ss = String(today.getSeconds()).padStart(2, '0');
  var timestamp = yyyy + '-' + MM + '-' + DD + ' ' + hh + ':' + mm + ':' + ss;

  // 生成日志文件路径
  let projectDir = engines.myEngine().cwd();
  let logPath = projectDir + "/" + timestamp + "-" + taskId + "-" + filename;

  // 创建日志文件
  files.createWithDirs(logPath);
  console.setGlobalLogConfig({
    file: logPath
  });

  // 缓存日志文件路径
  this.logFileCache[taskId] = logPath;

  console.info("日志文件创建成功，路径为：" + logPath);
  return logPath;
};

instance.submitLog = function (taskId, app_id, filename) {
  // 读取日志文件内容
  let logContent = files.read(filename);
  let res = {
    task_id: taskId,
    app_id: app_id,
    content: JSON.stringify(logContent)
  };

  // 提交日志到服务器
  utils.submitBug(res);

  // 删除本地日志文件
  files.remove(filename);

  // 清除缓存
  delete this.logFileCache[taskId];

  console.info("日志已提交并删除本地文件：" + filename);
};

module.exports = instance;