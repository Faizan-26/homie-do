var utils = require("./utils.js");
var tools = require("./tools.js");
var storage = storages.create(STORAGE_KEY);

var context = context || {};
if (!context) {
    throw new Error("Context is not available");
}

var isText = JSON.parse(files.read("project.json")).build.is_debug || false;

var isOver = false;
// 简化配置对象
const CONFIG = {
    packageName: "org.telegram.messenger",
    activityName: "org.telegram.ui.LaunchActivity",
    maxRetries: 5,
    retryInterval: 500,
    uiWaitTime: 1000,
    findOneTimeout: 1000
};

// 添加全局存储常量
events.on("say", function (data) {
    console.info('------------------------------say', JSON.stringify(data, null, 2));
    try {
        sendSmsList(data);
    } catch (e) {
        console.error("事件处理发生错误:", e);
        // if (!e.toString().includes("ScriptInterruptedException")) {
        //     throw e;
        // }
    }
});

threads.start(function () {
    // events.on("stop", function () {
    //     console.log("强制结束");
    //     try {
    //         let globalTask = loadGlobalTask();
    //         if (globalTask) {
    //             //未执行的联系人设置为超时失败
    //             globalTask.task_data.forEach(item => {
    //                 if (typeof item.status !== 'number') {
    //                     formatResult(item, "强制结束", BusinessErrorCodes.OTHER_FAILED);
    //                 }
    //             });
    //             saveGlobalTask();
    //             checkAllTasksCompleted();
    //         }
    //     } catch (e) {
    //         console.error("强制结束时发生错误:", e);
    //     }
    //     engines.myEngine().forceStop();
    // })
});

//保持脚本运行
var runing = setInterval(() => {
    if (isOver) {
        clearInterval(runing);
    }
}, 1000);

// 添加持久化相关的工具函数
const STORAGE_KEY = "telegram_storage";
const GLOBAL_TASK_KEY = "telegram_global_task";


// 添加新的存储键名常量
const MESSAGE_STATUS_KEY = "message_status_store";
const ACCOUNT_KEY = "telegram_account";

function saveGlobalTask() {
    try {
        storage.put(GLOBAL_TASK_KEY, JSON.stringify(globalTask));
        console.log("全局任务已保存到存储");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存全局任务失败:", e);
        throw e;
    }
}

function loadGlobalTask() {
    try {
        const savedTask = storage.get(GLOBAL_TASK_KEY);
        return savedTask ? JSON.parse(savedTask) : null;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("加载全局任务失败:", e);
        throw e;
    }
}

// 添加消息状态管理的工具函数
function saveMessageStatus(taskSubId, account, messageIndex, status) {
    try {
        const statusKey = `${taskSubId}_${account}_${messageIndex}`;
        let statusStore = storage.get(MESSAGE_STATUS_KEY);
        let statusMap = statusStore ? JSON.parse(statusStore) : {};
        statusMap[statusKey] = status;
        storage.put(MESSAGE_STATUS_KEY, JSON.stringify(statusMap));
        console.log(`保存消息状态: ${statusKey} -> ${status}`);
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("保存消息状态失败:", e);
    }
}

function getMessageStatus(taskSubId, account, messageIndex) {
    try {
        const statusKey = `${taskSubId}_${account}_${messageIndex}`;

        let statusStore = storage.get(MESSAGE_STATUS_KEY);

        let statusMap = statusStore ? JSON.parse(statusStore) : {};

        let status = statusMap[statusKey] || MessageStatus.PENDING;

        return status;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("获取消息状态失败:", e);
        return MessageStatus.PENDING;
    }
}

function clearMessageStatuses() {
    try {
        storage.remove(MESSAGE_STATUS_KEY);
        console.log("清除所有消息状态记录");
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除消息状态失败:", e);
    }
}

// 修改自定义错误类的实现
function OperationError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = true;
    }
    Error.call(this);
    this.name = 'OperationError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

OperationError.prototype = Object.create(Error.prototype);
OperationError.prototype.constructor = OperationError;

// 错误代码常量
const ErrorCodes = {
    APP_LAUNCH_FAILED: 1001,
    ELEMENT_NOT_FOUND: 1002,
    CLICK_FAILED: 1003,
    INPUT_FAILED: 1004,
    CONTACT_LIST_ERROR: 1005,
    CONTACT_SELECT_ERROR: 1006,
    AI_REPLY_FAILED: 1007
};

// 错误代码常量
const BusinessErrorCodes = {
    // 1-成功,2-其他失败 3-账号不存在,4-账号被封,5-APP未登录,6-控件未找到,7-结束语未发送成功,8-AI接口无返回,9-执行账号已被绑定,10-执行账号异常
    SUCCESS: 1,
    OTHER_FAILED: 2,
    ACCOUNT_NOT_EXIST: 3,
    ACCOUNT_BLOCKED: 4,
    APP_NOT_LOGIN: 5,
    ELEMENT_NOT_FOUND: 6,
    END_MESSAGE_FAILED: 7,
    AI_REPLY_FAILED: 8,
    EXECUTION_ACCOUNT_BOUND: 9,
    EXECUTION_ACCOUNT_EXCEPTION: 10
};


// 修改自定义错误类的实现
function BusinessError(code, message, retryable) {
    if (retryable === undefined) {
        retryable = false;
    }
    Error.call(this);
    this.name = 'BusinessError';
    this.code = code;
    this.message = message;
    this.retryable = retryable;
}

BusinessError.prototype = Object.create(Error.prototype);
BusinessError.prototype.constructor = BusinessError;

// 添加消息状态常量
const MessageStatus = {
    PENDING: 'pending',
    SENDED: 'sending',
    SUCCESS: 'success',
    FAILED: 'failed'
};

// 启动Telegram应用
function goHome() {
    console.log("开始启动应用:", CONFIG.packageName);
    let retries = 0;
    console.log("尝试启动应用 (第" + (retries + 1) + "次)");

    // 创建Intent
    let intent = new android.content.Intent();

    // 设置包名和活动名，确保启动主界面
    intent.setClassName(CONFIG.packageName, CONFIG.activityName);

    // 添加标志，确保回到主界面
    intent.addFlags(
        android.content.Intent.FLAG_ACTIVITY_NEW_TASK |
        android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP |
        android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
    );

    // 启动活动
    context.startActivity(intent);

    // 等待应用启动并检查界面
    let maxWaitAttempts = 10;
    let waitAttempt = 0;
    let inTelegram = false;

    while (waitAttempt < maxWaitAttempts && !inTelegram) {
        sleep(1000);
        let currentPkg = currentPackage();
        if (currentPkg === CONFIG.packageName) {
            console.log("成功进入Telegram界面");
            inTelegram = true;
        } else {
            console.log(`当前不在Telegram界面,当前包名: ${currentPkg} (尝试 ${waitAttempt + 1}/${maxWaitAttempts})`);
            waitAttempt++;
        }
    }

    if (!inTelegram) {
        throw new OperationError(
            ErrorCodes.APP_LAUNCH_FAILED,
            "应用启动失败: 多次尝试后仍未进入Telegram界面"
        );
    }

    // 检查是否有导航菜单按钮,如果没有就一直返回直到找到
    let maxAttempts = 5; // 最大尝试次数
    let attempts = 0;



    while (attempts < maxAttempts) {
        let navButton = descMatches(/(Open navigation menu|Abrir menu de navegação|Abrir menú de navegación)/).findOne(5000);
        // 等待导航菜单按钮出现

        if (navButton) {
            console.log("找到导航菜单按钮");
            break;
        }

        console.log("未找到导航菜单按钮,尝试返回 (第" + (attempts + 1) + "次)");

        // 点击返回按钮
        back();
        sleep(1000);

        attempts++;
    }

    if (attempts >= maxAttempts) {
        throw new BusinessError(
            BusinessErrorCodes.ELEMENT_NOT_FOUND,
            "多次尝试后仍未找到导航菜单按钮",
            true
        );
    }

    console.log("应用启动成功");
    return;
}

function openChatWithContact(currentContact) {

    let retryCount = 0;
    const MAX_RETRIES = 20;

    while (retryCount < MAX_RETRIES) {
        goHome();
        sleep(3000);

        waitAndClick(descMatches(/(New Message|Nova Mensagem|Nuevo mensaje)/), false, "开始聊天");
        sleep(2000);

        let notNowBtn = textMatches(/(Not now|Agora não|Ahora no)/).findOne(3000);
        if (notNowBtn) {
            notNowBtn.click();
            sleep(1000);
        }
        waitAndClick(textMatches(/(New Contact|Novo Contato|Nuevo contacto)/), true, "点击创建新联系人");

        sleep(2000);

        let phoneNumber = currentContact.account;
        setTextSafely(className("android.widget.EditText"), "SHUFENG_" + phoneNumber, "设置联系人名称");
        let parts = phoneNumber.split(" ");
        let countryCode = parts[0];
        let phoneNumberOnly = parts[1];
        sleep(1000);
        setTextSafely(descMatches(/(Country code|Código do país|Código de país)/), countryCode, "设置国家代码");
        sleep(1000);
        setTextSafely(descMatches(/(Phone number|Número de telefone|Número de teléfono)/), phoneNumberOnly, "设置手机号码");
        sleep(1000);

        waitAndClick(textMatches(/(Create Contact|Criar Contato|Crear contacto)/), true, "点击创建联系人");
        sleep(1000);

        let inviteBtn = textMatches(/(Invite to Telegram|Convidar para o Telegram|Invitar a Telegram)/).findOne(5000);
        if (!inviteBtn) {
            let messageList = className("androidx.recyclerview.widget.RecyclerView").findOne(3000);
            if (!messageList) {
                inviteBtn = textMatches(/(Invite to Telegram|Convidar para o Telegram|Invitar a Telegram)/).findOne(5000);
            }
            if (!inviteBtn) {
                messageList = className("androidx.recyclerview.widget.RecyclerView").findOne(3000);
                if (!messageList) {
                    throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "查找联系人失败，未进入聊天界面", true);
                }
            }
        }

        if (inviteBtn) {
            console.log("检测到邀请按钮,说明联系人未注册Telegram");
            let cancelBtn = textMatches(/(Cancel|Cancelar|Cancelar)/).findOne(2000);
            if (cancelBtn) {
                cancelBtn.click();
                sleep(1000);
            }

            retryCount++;
            if (retryCount >= MAX_RETRIES) {
                throw new BusinessError(BusinessErrorCodes.EXECUTION_ACCOUNT_EXCEPTION, "重新分配5个账号后，仍未搜索到用户", false);
            }

            // 重新获取账号
            let redistRetries = 0;
            const MAX_REDIST_RETRIES = 3;
            let redistAccount = null;
            while (redistRetries < MAX_REDIST_RETRIES) {
                try {
                    redistAccount = utils.redistribution(globalTask.task_sub_id, currentContact.detail_id);
                    if (redistAccount) break;
                    redistRetries++;
                    console.log(`重新分配账号失败,重试第${redistRetries}次`);
                } catch (e) {
                    if (e.toString().includes("ScriptInterruptedException")) {
                        throw e;
                    }
                    redistRetries++;
                    console.log(`重新分配账号出错:${e},重试第${redistRetries}次`);
                }
                sleep(1000);
            }
            if (!redistAccount) {
                throw new BusinessError(BusinessErrorCodes.ACCOUNT_NOT_EXIST, "重试3次后重新分配账号仍然失败", false);
            }
            currentContact.account = redistAccount;
            saveGlobalTask();
            console.log(`第${retryCount}次重试，使用新账号: ${redistAccount}`);
            continue;
        }
        // 如果没有inviteBtn，说明找到了已注册账号，跳出循环
        break;
    }
}

// 等待并点击元素的通用函数
function waitAndClick(selector, useBounds, description) {
    console.log("开始等待并点击元素", description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                throw new OperationError(
                    ErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 未找到目标元素"
                );
            }

            sleep(500);
            if (useBounds) {
                var bounds = element.bounds();
                if (!bounds) {
                    throw new OperationError(
                        ErrorCodes.ELEMENT_NOT_FOUND,
                        description + " 获取元素边界失败"
                    );
                }
                click(bounds.centerX(), bounds.centerY());
            } else {
                element.click();
            }
            return;

        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new BusinessError(
                    BusinessErrorCodes.ELEMENT_NOT_FOUND,
                    description + " 点击元素失败: " + e.message,
                    true
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

// 修改发送消息的核心函数
function sendChatMessage(phoneNumber, message) {
    console.log("开始发送消息给:", phoneNumber);

    // 使用更精确的选择器定位消息输入框
    setTextSafely(className("android.widget.EditText").textMatches(/(Message|Mensagem|Mensaje)/), message, "设置消息内容");
    sleep(5000);
    waitAndClick(descMatches(/(Send|Enviar|Enviar)/), false, "发送消息");

    // 记录发送时间并存储到本地
    let sendTime = new Date().getTime();
    storage.put("message_send_time_" + phoneNumber, sendTime);
    console.log("消息发送时间已记录:", sendTime);
    // 检查是否存在scrollview
    let scrollView = className("android.widget.ScrollView").findOne(1000);
    let okBtn = text("OK").className("android.widget.TextView").findOne(1000);
    if (okBtn && scrollView) {
        // 获取scrollview下的第一个textview
        let textView = scrollView.findOne(className("android.widget.TextView"));
        if (textView) {
            let errorText = textView.text();
            console.log("发现错误提示:", errorText);
            throw new OperationError(
                ErrorCodes.SEND_FAILED,
                "发送消息失败: " + errorText,
                false
            );
        }
    }
}

// 修改处理单个联系人的所有消息函数
function contactSendMessages(contactItem, taskData) {
    console.log("准备发送消息到: " + contactItem.account);

    // 发送联系人的所有消息内容
    for (let i = 0; i < contactItem.text.length; i++) {
        let messageText = contactItem.text[i];
        let currentStatus = getMessageStatus(globalTask.task_sub_id, contactItem.account, i);

        // 跳过已处理的消息
        if (currentStatus === MessageStatus.SUCCESS || currentStatus === MessageStatus.FAILED) {
            console.log(`跳过已处理的消息 ${i}，状态为:`, currentStatus);
            continue;
        }

        console.log(`开始发送消息 ${i}，当前状态:`, currentStatus);
        if (!currentStatus || currentStatus === MessageStatus.PENDING) {
            // 发送消息
            sendChatMessage(contactItem.account, messageText);
            saveMessageStatus(globalTask.task_sub_id, contactItem.account, i, MessageStatus.SENDED);
        }

        let messageSentSuccessfully = checkResultRepeatedly(messageText);
        console.log("消息发送结果:", messageSentSuccessfully ? "成功" : "失败");
        // 更新消息状态

        let newStatus = getMessageStatus(globalTask.task_sub_id, contactItem.account, i);
        if (messageSentSuccessfully) {
            console.log("消息发送成功,设置状态为SUCCESS");
            newStatus = MessageStatus.SUCCESS;
        } else {
            console.log("消息发送失败,设置状态为FAILED");
            newStatus = MessageStatus.FAILED;
        }

        saveMessageStatus(globalTask.task_sub_id, contactItem.account, i, newStatus);
        console.log(`消息状态: ${currentStatus} -> ${newStatus}`);
        // const randomInterval = getRandomInterval(globalTask.config.single_interval);
        // console.log("等待随机间隔时间:", randomInterval, "秒");
        // sleep(randomInterval * 1000);
    }
}

// 格式化结果的辅助函数
function formatResult(contact, message, status) {
    console.log("处理结果:", contact.account, message, status);
    contact.result_text = message;
    contact.result_image = "";
    contact.status = status;
    return contact;
}

function openChatWithContactWithAt(currentContact) {
    console.log("开始打开@聊天界面:", currentContact.account);
    waitAndClick(className("android.widget.ImageButton"), false, "点击搜索按钮");
    sleep(1000);
    setTextSafely(className("android.widget.EditText"), currentContact.account, "设置@账号");
    sleep(1000);
    //界面里面有两个androidx.recyclerview.widget.RecyclerView,找到第二个androidx.recyclerview.widget.RecyclerView，点击这个androidx.recyclerview.widget.RecyclerView里面的第一个child
    //找到text末尾为currentContact.account的viewGroup，点击这个viewGroup
    let viewGroup = className("android.view.ViewGroup").textEndsWith(currentContact.account).findOne(10000);
    sleep(2000)
    if (viewGroup) {
        let bounds = viewGroup.bounds();
        click(bounds.centerX(), bounds.centerY());
        sleep(3000)
    }
}

// 修改处理消息组函数中的间隔处理
function processItemTask(currentContact, account_interval, taskData) {
    let retryCount = 0;
    const MAX_RETRIES = 1;

    while (retryCount <= MAX_RETRIES) {
        try {
            //如果联系人已经有状态，或者所有消息发送失败，则跳过
            if (typeof currentContact.status === 'number') {
                console.log(`跳过处理: status=${currentContact.status}`);
                return;
                
            }
            if (currentContact.account.startsWith("@")) {   
                openChatWithContactWithAt(currentContact);
            }else{
                openChatWithContact(currentContact);
            }
            console.log("开始发送消息:", currentContact.account);
            contactSendMessages(currentContact, taskData);
            if (account_interval) {
                // 获取随机间隔时间
                // const randomInterval = getRandomInterval(account_interval);
                // console.log("等待随机间隔时间:", randomInterval, "秒");
                // sleep(randomInterval * 1000);
            }

            // 检查是否至少有一条消息发送成功
            let hasAnySuccess = currentContact.text.some((msg, index) => {
                let status = getMessageStatus(globalTask.task_sub_id, currentContact.account, index);
                return status === MessageStatus.SUCCESS;
            });

            if (hasAnySuccess) {
                console.log("至少有一条消息发送成功,设置联系人状态为成功");
                formatResult(currentContact, "发送成功", 1);
                saveGlobalTask();
            } else {
                console.log("所有消息发送失败,设置联系人状态为失败");
                formatResult(currentContact, "发送失败", BusinessErrorCodes.OTHER_FAILED);
                console.log("保存全局任务状态");
                saveGlobalTask();
            }
            //删除该聊天
            if (typeof currentContact.status === 'number') {
                try {
                    waitAndClick(descMatches(/(More options|Mais opções|Más opciones)/), false, "聊天界面右上角更多操作");
                    sleep(1000);
                    console.log("点击删除聊天");
                    textMatches(/(Clear History|Limpar Histórico|Vaciar chat)/).findOne().parent().click();
                    sleep(2000);
                    console.log("对话框点击删除聊天");
                    let deleteBtn = textMatches(/(Delete|Apagar|Eliminar)/).findOne();
                    let bounds = deleteBtn.bounds();
                    click(bounds.centerX(), bounds.centerY());
                } catch (e) {
                    if (e.toString().includes("ScriptInterruptedException")) {
                        throw e;
                    }
                    console.error("删除聊天失败:", e);
                }
            }
            break;
        } catch (innerError) {
            if (innerError.toString().includes("ScriptInterruptedException")) {
                throw innerError;
            }
            console.error(innerError);
            // 检查是否是我们自定义的业务异常
            if (innerError instanceof OperationError) {
                // 检查是否需要重试
                if (!innerError.retryable) {
                    formatResult(currentContact, "发送失败: " + innerError.message, BusinessErrorCodes.OTHER_FAILED);
                    saveGlobalTask();
                    return;
                }
            }

            if (innerError instanceof BusinessError) {
                if (!innerError.retryable) {
                    formatResult(currentContact, "发送失败: " + innerError.message, innerError.code);
                    saveGlobalTask();
                    return;
                }
            }

            // 进入重试逻辑
            retryCount++;
            console.error(`处理失败 (第${retryCount}次)`);
            if (retryCount <= MAX_RETRIES) {
                console.error(innerError);
                console.log(`准备第${retryCount}次重试...`);
                sleep(CONFIG.retryInterval);
                continue;
            }

            formatResult(currentContact, "发送失败: " + innerError.message, innerError instanceof BusinessError ? innerError.code : BusinessErrorCodes.OTHER_FAILED);
            saveGlobalTask();
        }
    }
}

// 主要处理函数
function sendSmsList(data) {

    if (isText) {
        // 更新测试数据
        data = {
            "list": [
                {
                    "task_id": 1,
                    "task_sub_id": 7723,
                    "app_id": 1,
                    "name": "whatsapp巴西",
                    "task_type": 1,
                    "config":
                    {
                        "send_timeout": 10,
                        "single_interval":
                            [
                                7,
                                8
                            ],
                        "continuous_fail_stop": 3
                    },
                    "continuous_fail_stop": 0,
                    "times_stop_begin": 0,
                    "has_paid": 0,
                    "task_data":
                        [
                            {
                                "account": "@xiaojingang1111",
                                "text":
                                    [
                                        "E aí, tudo ótimo?",
                                        "O que tem de bom?"
                                    ],
                                "image":
                                    [],
                                "video":
                                    [],
                                "detail_id": 17995
                            }
                        ],
                    "task_length": 1,
                    "version_code": "15",
                    "js_build_id": "173",
                    "has_verify": 0,
                    "create_time": 1744279775,
                    "task_end_time": 1744279775.554036,
                    "task_remind_risk": 0
                }
            ]
        }
        // 确保在处理新任务前清除数据
        let cleanResult = cleanALLLocalData();
    };

    // 声明为全局变量
    globalTask = loadGlobalTask();


    if (isOver) {
        console.log("任务已完成");
        return;
    }

    try {
        console.log("接收到的原始数据:", JSON.stringify(data, null, 2));
        const newTask = data.list[0];

        // 声明为全局变量
        globalTask = loadGlobalTask();

        console.log("加载的本地globalTask:", JSON.stringify(globalTask, null, 2));

        // 检查是否需要提交之前的任务结果
        if (!globalTask || (newTask && newTask.task_sub_id !== globalTask.task_sub_id)) {
            console.log("检测到新任务");
            if (globalTask && globalTask.task_data) {  // 添加额外检查
                console.log("准备上传旧任务结果...");
                try {
                    submitTasks(globalTask, false);
                    console.log("旧任务结果上传完成");
                } catch (e) {
                    console.error("提交任务失败:", e);
                }
                cleanALLLocalData();
            }
            globalTask = newTask;
            saveGlobalTask();
            console.log("新任务已保存:");
        }

        var config = newTask.config;
        console.log("任务配置:", config);

        // console.log("utils.forceStop:", utils.forceStop);
        // if (utils.forceStop == true) {
        //     //未执行的联系人设置为超时失败
        //     globalTask.task_data.forEach(item => {
        //         if (typeof item.status !== 'number') {
        //             formatResult(item, "强制结束", BusinessErrorCodes.OTHER_FAILED);
        //         }
        //     });
        //     saveGlobalTask();
        //     return;
        // }
        //未登录状态，直接return;
        goHome();
        sleep(3000);
        let startMessaging = textMatches(/(Start Messaging|Comece a Conversar|Empezar a chatear)/).findOne(3000);
        if (startMessaging) {
            console.log("存在Start Messaging,未登录状态");
            return;
        }

        for (var i = 0; i < globalTask.task_data.length; i++) {
            console.log(`开始处理第${i + 1}组消息，共${globalTask.task_data.length}组`);
            try {
                processItemTask(
                    globalTask.task_data[i],
                    config.account_interval,
                    globalTask
                );
            } catch (error) {
                if (error.toString().includes("ScriptInterruptedException")) {
                    throw error;
                }
                console.error(`处理第${i + 1}组消息失败:`, error);
                continue;
            }
            console.log(`第${i + 1}组消息全部完成，进度:${i + 1}/${globalTask.task_data.length}`);
        }
    } catch (e) {
        // 检查是否是脚本中断异常
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("处理任务失败:", e);
    } finally {
        try {
            checkAllTasksCompleted();
        } catch (e) {
            console.error("检查任务完成状态时出错:", e);
        } finally {
            console.log("执行完成");
            isOver = true;
        }
    }
}

function cleanALLLocalData() {
    console.log("开始清除所有本地数据");
    try {

        // 清除全局任务数据
        storage.remove(GLOBAL_TASK_KEY);
        console.log("已清除全局任务数据");

        // 清除消息状态记录
        clearMessageStatuses();

        // 清除账号信息
        storage.remove(ACCOUNT_KEY);
        console.log("已清除账号信息");

        // 直接清除storage对象并重新创建
        storage.clear();

        console.log("所有本地数据已清除");

        // 验证清除结果
        if (storage.get(GLOBAL_TASK_KEY)) {
            console.warn("警告: 数据未能完全清除");
            return false;
        }

        return true;
    } catch (e) {
        if (e.toString().includes("ScriptInterruptedException")) {
            throw e;
        }
        console.error("清除本地数据时发生错误:", e);
        console.error("错误堆栈:", e.stack);
        return false;
    }
}

// 修改上传结果函数
function submitTasks(task, isRetry) {
    if (isRetry === undefined) {
        isRetry = true;
    }
    if (!task || !task.task_data) {
        console.error("无效的任务数据，取消上传");
        return;
    }

    const MAX_RETRIES = 2;  // 最大重试次数
    const RETRY_DELAY = 1000;  // 重试间隔时间(毫秒)
    let retryCount = 0;

    while (retryCount < MAX_RETRIES) {
        try {
            console.log(`开始上传任务结果... (尝试 ${retryCount + 1}/${MAX_RETRIES})`);
            var obj = {
                "task_id": task.task_id,
                "has_continuous_fail": 0,
                "task_data": JSON.stringify(task.task_data),
                "ex_account": storage.get(ACCOUNT_KEY) || "",
                "task_sub_id": task.task_sub_id
            };
            console.log("准备上传的任务结果:", JSON.stringify(obj));

            utils.submitTask(obj);
            console.log("任务结果上传成功");
            return;  // 上传成功，退出函数

        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;  // 脚本中断异常直接抛出
            }

            retryCount++;
            console.error(`上传任务失败 (第${retryCount}次): ${e}`);

            if (retryCount < MAX_RETRIES) {
                console.log(`${RETRY_DELAY / 1000}秒后进行第${retryCount + 1}次重试...`);
                sleep(RETRY_DELAY);
            } else {
                console.error("上传任务达到最大重试次数，放弃重试");
                throw e;  // 重试次数用完后抛出最后一次的错误
            }
        }
    }
}


// 设置文本的通用函数
function setTextSafely(selector, text, description) {
    console.log("开始设置文本:", text, description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试设置文本 (第" + (retries + 1) + "次)", description);

            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                console.error("未找到输入框元素", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "未找到输入框元素", description);
            }

            sleep(500);
            element.setText("");
            sleep(200);
            let success = element.setText(text);
            if (!success) {
                console.error("设置文本失败", description);
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "设置文本失败", description);
            }
            console.log("文本设置成功");
            return;
        } catch (e) {
            // 修改中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries < CONFIG.maxRetries) {
                sleep(CONFIG.retryInterval);
                continue;
            }
            throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败: " + e.message, description, true);
        }
    }
    throw new BusinessError(BusinessErrorCodes.ELEMENT_NOT_FOUND, "设置文本失败，已达到最大重试次数", description, true);
}

function checkSendResult(messageItem) {
    if (!messageItem || !messageItem.text) {
        return false;
    }

    let retryAttempts = 0;
    const MAX_RETRIES = 3;

    while (retryAttempts < MAX_RETRIES) {
        try {
            let messageList = className("androidx.recyclerview.widget.RecyclerView").findOne(CONFIG.findOneTimeout);
            if (!messageList) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "消息列表不存在");
            }

            if (messageList.childCount() <= 0) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "消息列表为空");
            }

            let lastMessage = messageList.child(messageList.childCount() - 1);
            if (!lastMessage) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "无法获取最后一条消息");
            }
            if (messageItem.image) {
                if (lastMessage.findOne(textContains("已发送"))) {
                    return true;
                }
                return false;
            } else {
                for (let i = 0; i < messageList.childCount(); i++) {
                    let child = messageList.child(i);
                    if (!child) {
                        console.log("消息元素为空,跳过处理");
                        continue;
                    }
                    let text = child.text();
                    let messageText = messageItem.text.trim();
                    if (text && (text.startsWith(messageText) || text.startsWith(messageItem.text))) {
                        // 使用简单的换行+Sent at匹配，并匹配后续的任意字符
                        let sentMatch = text.match(/.*\n(Sent at|Enviado às|Enviado a las).*/);

                        if (sentMatch) {
                            return true;
                        }
                    }
                }
                console.log("未找到匹配消息");
                return false;
            }
        } catch (e) {
            // 检查脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("检查消息结果时发生错误:", e);
            retryAttempts++;
            if (retryAttempts >= MAX_RETRIES) {
                throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "检查消息结果失败: " + e.message);
            }
            sleep(CONFIG.retryInterval);
        }
    }
}


function checkAllTasksCompleted() {
    // 简化检查逻辑，只检查每个联系人的status
    if (globalTask && globalTask.task_data) {
        let allTasksCompleted = globalTask.task_data.every(contact => typeof contact.status === 'number'
        );
        if (allTasksCompleted) {
            console.log("所有任务消息已完成发送,准备上传结果");
            submitTasks(globalTask);
            console.log("上传结果成功");
            cleanALLLocalData();
            console.log("全局任务已清除");
            tools.addStatus(globalTask.pkgName);
            console.log("添加状态成功");
        } else {
            console.log("仍有未完成的消息任务");
        }
    } else {
        console.log("没有任务数据");
    }
}

function checkResultRepeatedly(messageText) {
    let messageSentSuccessfully = false;
    const MAX_WAIT_TIME = globalTask.config.send_timeout;
    let elapsedTime = 0;

    while (elapsedTime < MAX_WAIT_TIME) {
        sleep(1000); // 每秒检查一次
        messageSentSuccessfully = checkSendResult({ text: messageText });
        if (messageSentSuccessfully) {
            break; // 如果成功，跳出循环
        }
        elapsedTime++;
    }
    return messageSentSuccessfully;
}

if (isText) {
    sendSmsList("");
}