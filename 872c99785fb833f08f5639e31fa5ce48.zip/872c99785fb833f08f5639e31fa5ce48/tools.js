
var instance = {};
instance.deleteDownloadFiles = function (fileName) {
    sleep(2000);
    this.refreshAlbum();
    var fileArr = fileName.split('/');
    var fileType = fileArr[fileArr.length - 1];
    // console.info("查找文件名：", fileType);
    var photos = this.getAfterDownloadFiles(fileType);
    // console.info("删除文件：", photos);
    photos.forEach(function (photo) {
        if (files.exists(photo.path)) {
            if (files.remove(photo.path)) {
                console.info("delete file success: " + photo.path);
            } else {
                console.error("delete file failed: " + photo.path);
            }
        } else {
            console.error("file not exists: " + photo.path);
        }
    });
    if (files.exists(fileName)) {
        files.remove(fileName);
    }
}

instance.getAfterDownloadFiles = function (filename) {
    let resolver = context.getContentResolver();
    let uri = android.provider.MediaStore.Files.getContentUri("external");
    let projection = [
        android.provider.MediaStore.MediaColumns.DISPLAY_NAME,
        android.provider.MediaStore.MediaColumns.DATA,
        android.provider.MediaStore.MediaColumns.DATE_ADDED,
        android.provider.MediaStore.MediaColumns.MIME_TYPE
    ];
    let selection = android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE + "=? OR " +
        android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE + "=?";
    let selectionArgs = [
        android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
        android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
    ];
    let sortOrder = android.provider.MediaStore.MediaColumns.DATE_ADDED + " ASC";

    let cursor = resolver.query(uri, projection, selection, selectionArgs, sortOrder);
    let mediaFiles = [];
    let found = false;

    if (cursor != null) {
        while (cursor.moveToNext()) {
            let filePath = cursor.getString(cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.DATA));
            let mimeType = cursor.getString(cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.MIME_TYPE));
            let dateAdded = cursor.getLong(cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.DATE_ADDED)) * 1000;
            let columnName = cursor.getString(cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.DISPLAY_NAME));
            if (filePath.indexOf("Screenshots/") != -1) {
                continue;
            }
            // console.info("文件名：", filename, columnName);
            if (filename == columnName) {
                found = true;
            }
            if (found) {
                mediaFiles.push({
                    path: filePath,
                    name: columnName,
                    mimeType: mimeType,
                    dateAdded: new Date(dateAdded)
                });
            }
        }
        cursor.close();
    }

    return mediaFiles;
}

instance.refreshAlbum = function refreshAlbum() {
    let intent = new android.content.Intent(android.content.Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
    let file = new java.io.File("/storage/emulated/0/DCIM/Camera/");
    let uri = android.net.Uri.fromFile(file);
    intent.setData(uri);
    context.sendBroadcast(intent);
}

instance.downloadFiles = function (url) {
    var nameList = "";
    try {
        var res = http.get(url);
        if (res.statusCode != 200) {
            console.log("get files failed", res.statusCode);
            return nameList;
        }
        var fileArr = url.split('.');
        var fileType = fileArr[fileArr.length - 1];
        var filePath = "/storage/emulated/0/DCIM/Camera/"
        var fileName = new Date().getTime() + "t." + fileType;
        if (!files.exists(filePath)) {
            console.log("没有该路径:", filePath);
            files.createWithDirs(filePath);
        }
        let fullPath = files.join(filePath, fileName);
        files.writeBytes(fullPath, res.body.bytes());
        media.scanFile(fullPath);
        nameList = fullPath;
        return nameList;
    } catch (error) {
        console.log("下载错误", error);
        return "";
    }
};

instance.downloadFilesRename = function (url, name) {
    var nameList = "";
    var res = http.get(url);
    if (res.statusCode != 200) {
        console.log("get files failed", res.statusCode);
        return nameList;
    }
    var fileArr = url.split('.');
    var fileType = fileArr[fileArr.length - 1];
    var filePath = "/storage/emulated/0/DCIM/Camera/"
    var fileName = name + "." + fileType;
    files.writeBytes(files.join(filePath, fileName), res.body.bytes());
    media.scanFile(files.join(filePath, fileName));
    nameList = filePath + fileName;
    // toastLog("下载文件，地址=" + url + "=下载路径=" + nameList);
    return nameList;
};

instance.getAppVersion = function (packageName) {
    try {
        let packageManager = context.getPackageManager();
        let packageInfo = packageManager.getPackageInfo(packageName, 0);
        return packageInfo.versionName;
    } catch (e) {
        return "error version";
    }
}

instance.storage = getStorage();
function getStorage() {
    if (instance.storage) { return instance.storage; }

    return storages.create("ai-bot");
}

// 函数用于返回两个列表中不一样的子项
instance.getDifference = function (list1, list2) {
    let difference = [];

    // 遍历 list1，找出不在 list2 中的元素
    for (let item of list1) {
        if (!list2.includes(item)) {
            difference.push(item);
        }
    }

    // 遍历 list2，找出不在 list1 中的元素
    for (let item of list2) {
        if (!list1.includes(item)) {
            difference.push(item);
        }
    }

    return difference;
}

instance.initStatus = function () {
    instance.storage.remove("doneStatus");
}

instance.addStatus = function (status) {
    if (status == null) {
        console.log("addStatus- status is null");
        return;
    }
    var endStatus = instance.storage.get("doneStatus", null);
    if (endStatus == null) {
        endStatus = [status];
    } else {
        endStatus.push(status);
    }
    instance.storage.put("doneStatus", endStatus); // 重新存储更新后的数组
    console.log("doneStatus", instance.storage.get("doneStatus", null));
}

instance.getStatus = function(){
    return instance.storage.get("doneStatus", []);
}

// 获取当前时间戳
instance.getCurrentTimestamp = function () {
    return new Date().getTime();
}

module.exports = instance;