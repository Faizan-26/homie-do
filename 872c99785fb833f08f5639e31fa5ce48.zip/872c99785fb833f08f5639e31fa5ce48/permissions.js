var Manifest = importClass(android.Manifest);
var packageManager = importClass(android.content.pm.PackageManager);
var instance = {}

instance.checkPermissions = function () {
    // if (auto.service == null) {
    //     console.log("checkPermissions auto.service == null")
    //     app.startActivity({
    //         action: "android.settings.ACCESSIBILITY_SETTINGS"
    //     });
    //     return false;
    // }

    if (!hasAutoServer()) {
        auto.waitFor();
        return false;
    }


    if (!floaty.checkPermission()) {
        console.log("checkPermissions checkPermission == fasle")
        floaty.requestPermission();
        return false;
    }

    // hasAlbumPermission();

    return true;
}

function hasAutoServer() {
    try {
        descStartsWith("Conversas").findOnce();
        return true;
    } catch (error) {
        auto.service.disableSelf();
        return false;
    }
}
function hasAlbumPermission() {
    try {
        let aa = runtime.requestPermissions(["android.permission.READ_MEDIA_IMAGES"]);
        console.info(aa);
    } catch (e) {

    }

}

module.exports = instance;