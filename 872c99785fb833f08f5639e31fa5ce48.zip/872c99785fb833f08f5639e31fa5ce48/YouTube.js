// var pkgName = "com.ss.android.ugc.trill";
var pkgName = "com.google.android.youtube";
var tools = require("./tools.js");
var utils = require("./utils.js");

var tmpTaskList = [];
var storeKey = "YouTube";


var config = {};
var selfId = "";
var isContinueFail = 0;
var isOver = false;

var runing = setInterval(() => {
    if (isOver) {
        clearInterval(runing);
    }
}, 1000);


events.on("say", function (param) {
    // console.log(param);
    // app.launch(pkgName);
    // sleep(20000);
    // let nodes = selector().find(); // 或 let nodes = $$();
    // nodes.forEach(node => {
    //     log("类名: " + node.className());
    //     log("包名: " + currentPackage(), currentActivity());
    //     log("文本: " + node.text());
    //     log("描述: " + node.desc());
    //     log("ID: " + node.id());
    //     log("边界: " + JSON.stringify(node.bounds()));
    //     log("子节点：", node.children().length);
    //     log("---------");
    // });

    // sleep(1000);
    // let title = "我们都有一个加";
    // setClip(title);
    // longClick(device.width / 2, device.height * 14 / 100);
    // sleep(5000);
    // let items = className("android.widget.TextView").find();
    // for (let i = 0; i < items.length; i++) {
    //     console.log("测试：", i);
    //     if (items[i].text().includes(title)) {
    //         items[i].click();
    //         break;
    //     }
    // }
    // if (text(title).exists()) {
    //     click(title);
    //     toast("粘贴成功");
    // } else {
    //     toast("粘贴失败，未找到剪贴板内容");
    // }

    // // let tmpNode = descMatches(/(Colar|abcd)/).findOne(5000);

    // console.log("根节点");

    // console.log("坐标：", device.width * 29 / 100, device.height * 11 / 100);
    // // back();
    // // sleep(1000);
    // // click(device.width / 2, device.height * 90 / 100);
    // // paste();

    // let ceshiNode = text("Legende seu Short").findOne(5000);
    // if (ceshiNode) {
    //     console.log("存在节点");
    // }
    try {
        console.log("say::", param);
        handle(param.list);
    } catch (error) {
        console.error(error);
    }
});
function randomNum(minNum, maxNum) {
    return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}


function handle(taskList) {
    try {
        launchApp();
        packageName(pkgName).descMatches(/(我.*|आप.*|คุณ.*|You.*|Você.*|Tú.*|آپ.*)/).waitFor();
        // 提交旧数据/ 赋值新任务
        tmpTaskList = tools.storage.get(storeKey, []);
        console.info("获取本地缓存", tmpTaskList);
        console.info("传入数据 =>\n", taskList);
        if (tmpTaskList.length > 0) {
            tmpTaskList.forEach((item, index) => {
                console.log("sub_id:", item.task_sub_id, taskList[index].task_sub_id);
                if (item.task_sub_id != taskList[index].task_sub_id) {
                    submitRes(index);
                    tmpTaskList[index] = taskList[index];
                }
            })
        } else {
            tmpTaskList = taskList;
        }
        tools.storage.put(storeKey, tmpTaskList);
        console.log("执行任务");
        // 执行任务
        tmpTaskList.forEach((item, i) => {
            config = item.config;
            item.task_data.forEach((data, j) => {
                if (tmpTaskList[i].task_data[j].finished || tmpTaskList[i].task_data[j].sended) { return; }
                let res = 0;
                switch (tmpTaskList[i].task_type) {
                    case 3:
                        let downFileName = tools.downloadFiles(data.video);
                        if (downFileName == "") {
                            console.error("下载视频失败", data.video);
                            checkRes(-50, i, j);
                            return
                        }
                        console.info("下载文件路径:", downFileName, data.video);
                        res = publishMedia(data, i, j);
                        console.log("结果：", res);
                        if (res == -4 || res == -5) {
                            res = publishMedia(data, i, j);
                            console.log("结果：", res);
                            tools.deleteDownloadFiles(downFileName);
                        }
                        checkRes(res, i, j);
                        break;
                    // case 5:
                    //     s = setUserIntro(i, j);
                    //     break;
                    // case 6:
                    //     s = addComLink(i, j);
                    //     break;
                }

            })
            // 提交前，检查一边失败的，提高成功率
            if (item.task_data && item.task_data.length > 0) {
                launchApp();
                item.task_data.forEach((data, j) => {
                    if (tmpTaskList[i].task_data[j].sended) {
                        console.info("secend check::", i, j);
                        let max = 20;
                        while (max > 0) {
                            max--;
                            if (getLinks(i, j) == 100) {
                                break;
                            }
                        }
                    }
                })
            }

            console.log("提交任务", i);
            submitRes(i);
        })
        isOver = true;
    } catch (error) {
        console.error("运行中报错，保存数据::::", error);
        isOver = true;
        tools.storage.put(storeKey, tmpTaskList);
        if (error.toString().includes("ScriptInterruptedException")) {
            throw error;
        }
    }
}

function checkRes(res, i, j) {
    if (res == -50) {
        console.log(`(s=${res}) 下载失败`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].status = 2;
        tmpTaskList[i].task_data[j].result_text = "下载失败";
    }
    if (res == -51) {
        console.log(`(s=${res}) 上传失败`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].status = 2;
        tmpTaskList[i].task_data[j].result_text = "上传失败";
    }
    if (res == -4) {
        console.log(`(s=${res}) 控件未找到`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].status = 6;
        tmpTaskList[i].task_data[j].result_text = "控件未找到";
    }
    if (res == 100) {
        console.log(`(s=${res}) 成功`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].status = 1;
        tmpTaskList[i].task_data[j].result_text = "成功";
    }
    if (res == -10) {
        console.log(`(s=${res}) 账号被禁`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].result_text = "账号被禁";
        tmpTaskList[i].task_data[j].status = 4;
        isOver = true;
    }
    if (res == -11) {
        console.log(`(s=${res})未登录`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].status = 5;
        tmpTaskList[i].task_data[j].result_text = "未登录";
        isOver = true;
    }
    if (res == -20) {
        console.log(`(s=${res}) 目标账号不存在`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].result_text = "目标账号不存在";
        tmpTaskList[i].task_data[j].status = 3;
    }
    if (tmpTaskList[i].task_data[j].taskFinish) { } else {
        console.log(`(s=${res}) 失败`);
        tmpTaskList[i].task_data[j].taskFinish = true;
        tmpTaskList[i].task_data[j].status = 2;
        tmpTaskList[i].task_data[j].result_text = "失败";
    }
    tools.storage.put(storeKey, tmpTaskList);
}


function getLinks(indexI, indexJ) {
    try {
        sleep(random(5000, 7000));
        let oneData = tmpTaskList[indexI].task_data[indexJ];
        console.log("获取链接-1");
        let perfileNode = packageName(pkgName).descMatches(/(我|आप|คุณ|You|Você|Tú|آپ)/).findOne(6000);
        if (!perfileNode || !perfileNode.click()) {
            return -4;
        }
        sleep(1000);

        // textMatches(/(Subida completada|)/).findOne(5000);

        console.log("获取链接-2");
        perfileNode = id("com.google.android.youtube:id/compact_list_item").findOne(5000);
        if (!perfileNode || !perfileNode.click()) {
            return -4;
        }
        sleep(1000);

        console.log("获取链接-3");
        let gridView = id("com.google.android.youtube:id/results").findOne(5000);
        if (!gridView) {
            return -4;
        }

        console.log("获取链接-4");
        console.log("列表：", gridView.children().length);
        let tmpStr = "#" + oneData.tag + " " + oneData.paperwork;
        tmpStr = tmpStr.length > 12 ? tmpStr.slice(0, 12) : tmpStr;
        let finded = false;
        gridView.children().forEach((child) => {
            if (finded) return;
            let targetNode = child.findOne(textStartsWith(tmpStr));
            let actionNode = descMatches(/(Action menu)/).findOne(6000);
            let isBlockNode = descMatches(/(公开|Público|Público|Public|सार्वजनिक|สาธารณะ|عوامی)/).findOne(6000);

            if (targetNode && actionNode) {

                actionNode.click();
                sleep(1000);

                perfileNode = descMatches(/(分享视频|वीडियो शेयर करें|แชร์วิดีโอ|Share video|Compartilhar vídeo|Compartir vídeo|ویڈیو کا اشتراک کریں)/).findOne(6000);
                if (!perfileNode || !perfileNode.click()) {
                    return -4;
                }
                sleep(1000);

                gridNode = id("com.google.android.youtube:id/bottom_sheet_list").findOne(6000);
                if (!gridNode) {
                    return -4;
                }
                let tmpGridNode = gridNode.children().get(0);
                if (!tmpGridNode) {
                    return -4;
                }
                perfileNode = tmpGridNode.children().get(2);
                if (!perfileNode) {
                    return -4;
                }
                perfileNode.click();
                sleep(1000);

                perfileNode = descMatches(/(搜索|खोजें|ค้นหา|Search|Pesquisar|Buscar|پروفائل)/).findOne(6000);
                if (!perfileNode) {
                    return -4;
                }
                perfileNode.click();
                sleep(1000);

                let editNode = className("android.widget.EditText").findOne(5000);
                if (editNode) {
                    editNode.setText("");
                    editNode.paste();
                }
                editNode = className("android.widget.EditText").findOne(5000);
                let tmpStr = editNode.text();
                tmpTaskList[indexI].task_data[indexJ].result_text = tmpStr;
                if (isBlockNode) {
                    tmpTaskList[indexI].task_data[indexJ].status = 1;
                } else {
                    tmpTaskList[indexI].task_data[indexJ].status = 2;
                    tmpTaskList[indexI].task_data[indexJ].result_text = "版权或者被阻止发送" + tmpStr;
                }
                // tmpTaskList[indexI].task_data[indexJ].status = 1;
                tools.storage.put(storeKey, tmpTaskList);
                finded = true;
            }
        })

        if (finded) {
            return 100;
        }

        return -4;
    } catch (error) {
        console.error("运行中报错，保存数据::::", error);
        isOver = true;
        tools.storage.put(storeKey, tmpTaskList);
        if (error.toString().includes("ScriptInterruptedException")) {
            throw error;
        }
    }




    // perfileNode = descMatches(/(Action menu|Profile|प्रोफ़ाइल|โปรไฟล์|پروفائل)/).findOne(6000);
    // if (!perfileNode) {
    //     return -4;
    // }
    // perfileNode.click();
    // sleep(1000);

    // perfileNode = descMatches(/(分享视频|Profile|प्रोफ़ाइल|โปรไฟล์|پروفائل)/).findOne(6000);
    // if (!perfileNode) {
    //     return -4;
    // }
    // perfileNode.click();
    // sleep(1000);

    // perfileNode = descMatches(/(分享视频|Profile|प्रोफ़ाइल|โปรไฟล์|پروفائل)/).findOne(6000);
    // if (!perfileNode) {
    //     return -4;
    // }
    // perfileNode.click();
    // sleep(1000);

    // gridNode = id("com.google.android.youtube:id/bottom_sheet_list").findOne(6000);
    // if (!gridNode) {
    //     return -4;
    // }
    // let tmpGridNode = gridNode.children().get(0);
    // if (!tmpGridNode) {
    //     return -4;
    // }
    // perfileNode = tmpGridNode.children().get(2);
    // if (!perfileNode) {
    //     return -4;
    // }
    // perfileNode.click();
    // sleep(1000);

    // perfileNode = descMatches(/(搜索|Profile|प्रोफ़ाइल|โปรไฟล์|پروفائل)/).findOne(6000);
    // if (!perfileNode) {
    //     return -4;
    // }
    // perfileNode.click();
    // sleep(1000);


    // let editNode = className("android.widget.EditText").findOne(5000);
    // if (editNode) {
    //     editNode.setText("");
    //     editNode.paste();
    // }
    // editNode = className("android.widget.EditText").findOne(5000);
    // let tmpStr = editNode.text();
    // tmpTaskList[indexI].task_data[indexJ].result_text = tmpStr;
    // tmpTaskList[indexI].task_data[indexJ].status = 1;
    // tools.storage.put(storeKey, tmpTaskList);
    // return 100;
}


function publishMedia(data, i, j) {
    try {
        console.log("0");
        launchApp();
        console.log("1");
        let perfileNode = packageName(pkgName).descMatches(/(我|आप|คุณ|You|Você|Tú|آپ)/).findOne(5000);
        if (perfileNode) {
            perfileNode.click();
            sleep(1000);
        }
        perfileNode = packageName(pkgName).descMatches(/(创作|बनाएं|สร้าง|Create|Criar|Crear|تخلیق کریں.*)/).findOne(5000);
        if (!perfileNode || !perfileNode.click()) {
            return -4;
        }
        sleep(1000);

        console.log("2");
        perfileNode = descMatches(/(视频|वीडियो|วิดีโอ|Video|Vídeo|ویڈیو)/).boundsInside(0, device.height / 2, device.width, device.height).findOne(5000);
        if (!perfileNode || !perfileNode.click()) {
            return -4;
        }
        sleep(random(5000, 7000));

        console.log("3");
        let gridNode = id("com.google.android.youtube:id/thumb_image_view").findOne(5000);
        if (!gridNode) {
            return -4;
        }

        console.log("3.1", gridNode.length);
        // perfileNode = gridNode.child(0);
        // if (!perfileNode) {
        //     return -4;
        // }
        let gridNodeRect = gridNode.bounds();
        click(gridNodeRect.centerX(), gridNodeRect.centerY());
        sleep(1000);

        console.log("4");
        perfileNode = id("com.google.android.youtube:id/shorts_trim_finish_trim_button").findOne(5000);
        if (!perfileNode || !perfileNode.click()) {
            return -4;
        }
        sleep(1000);

        console.log("5");
        perfileNode = id("com.google.android.youtube:id/shorts_post_bottom_button").findOne(5000);
        if (!perfileNode || !perfileNode.click()) {
            return -4;
        }
        sleep(2000);

        console.log("6");
        // perfileNode = className("android.widget.EditText").findOne(5000);
        // if (!perfileNode) {
        //     return -4;
        // }

        // perfileNode.click();
        // sleep(1000);
        // console.log("6.1");
        // let tmpStrAddTag = "#" + data.tag + " " + data.paperwork;
        // console.log("set text is::", tmpStrAddTag)
        // perfileNode = className("android.widget.EditText").findOne(1000);
        // perfileNode.setText(tmpStrAddTag);
        // sleep(1000);

        console.log("6.3");
        perfileNode = className("android.widget.EditText").findOne(5000);
        let tmpStrAddTag = "#" + data.tag + " " + data.paperwork;
        console.log("set text is::", tmpStrAddTag)
        if (!perfileNode) {
            setClip(tmpStrAddTag);
            sleep(1000);
            // click(device.width / 2, device.height * 14 / 100);
            // sleep(1000);
            longClick(device.width / 2, device.height * 14 / 100);
            sleep(3000);

            events.broadcast.emit("move_center", "来自子脚本的消息");
            // console.log("坐标：", device.width * 29 / 100, device.height * 10 / 100);
            // click(device.width * 29 / 100, device.height * 11 / 100);
            for (var pixIndex = 10; pixIndex < device.width * 29 / 100; pixIndex += 10) {
                click(pixIndex, device.height * 10 / 100);
                sleep(2000);
            }
            events.broadcast.emit("move_zero", "来自子脚本的消息");
            sleep(2000);

            // let colarNode = text("Colar").findOne(5000);
            // if (colarNode) {
            //     console.log("找到粘贴");
            // }
            back();
            sleep(1000);
            click(device.width / 2, device.height * 90 / 100);
        } else {
            // 获取账户信息
            console.log("6");
            let selfNode = id("com.google.android.youtube:id/recycler_view").findOne(5000);
            if (!selfNode) {
                return -4;
            }
            console.log("信息：000", selfNode.children().length)
            selfNode = selfNode.child(0);
            console.log("6.1");
            if (!selfNode) {
                return -4;
            }

            console.log("信息：111", selfNode.children().length);
            console.log("6.2");
            selfNode = selfNode.child(1);
            if (selfNode && selfNode.children().length > 1) {
                console.log("信息：222", selfNode.children().length);
                selfId = selfNode.child(1).text();
                console.log("信息", selfId);
            }

            perfileNode.click();
            sleep(1000);
            console.log("6.4");
            perfileNode = className("android.widget.EditText").findOne(1000);
            perfileNode.setText(tmpStrAddTag);
            sleep(1000);


            console.log("信息：222", selfNode.children().length);
            selfId = selfNode.child(1).text();
            console.log("信息", selfId);

            console.log("7");
            perfileNode = id("com.google.android.youtube:id/upload_bottom_button").findOne(5000);
            if (!perfileNode || !perfileNode.click()) {
                return -4;
            }
            sleep(1000);
        }

        sleep(random(30000, 50000));
        perfileNode = packageName(pkgName).descMatches(/(我|आप|คุณ|You|Você|Tú|آپ)/).findOne(5000);
        if (perfileNode) {
            perfileNode.click();
            sleep(1000);
        }

        // 判断发送成功
        // textMatches(/( .*上传失败| No se ha podido completar la subida|Upload complete)/).findOne(5000);
        perfileNode = textMatches(/(上传完毕|上传完成|Subida completada|Upload complete|Envio concluído)/).findOne(20000);
        if (!perfileNode) {
            return -51;
        }
        sleep(1000);
        tmpTaskList[i].task_data[j].sended = true;
        // tmpTaskList[i].task_data[j].status = 1;
        tools.storage.put(storeKey, tmpTaskList);

        return 100;
    } catch (error) {
        console.error("运行中报错，保存数据::", error);
        isOver = true;
        tools.storage.put(storeKey, tmpTaskList);
        if (error.toString().includes("ScriptInterruptedException")) {
            throw error;
        }

        return -5;
    }
}

function setUserIntro(indexI, indexJ) {
    let oneData = tmpTaskList[indexI].task_data[indexJ];
    // let maxExe = config.continuous_fail_stop;
    let maxReture = 3;
    launch(pkgName);
    while (true) {
        setTimeout(function () { }, 0);
        let perfileNode = packageName(pkgName).desc("Perfil").className("android.widget.FrameLayout").findOne(5000);
        if (perfileNode) {
            perfileNode.click();
            sleep(500);
            let editPerfileNode = text("Editar perfil").findOne(5000);
            if (editPerfileNode) {
                let selfName = textStartsWith("@").className("android.widget.Button").findOne(6000);
                if (selfName) {
                    selfId = selfName.text();
                }

                let tRect = editPerfileNode.bounds();
                click(tRect.centerX(), tRect.centerY());
                let personalProfileNode = descStartsWith("Descrição").className("android.widget.Button").findOne(5000);
                if (personalProfileNode) {
                    personalProfileNode.click();
                    sleep(500);
                    let editNode = className("android.widget.EditText").findOne(5000);
                    if (editNode) {
                        editNode.setText(oneData.text);
                        sleep(500);
                        let editBtnNode = text("Salvar").className("android.widget.Button").enabled(true).findOne(5000);
                        if (editBtnNode) {
                            editBtnNode.click();
                            tmpTaskList[indexI].task_data[indexJ].result_text = "res" + 1;
                            tmpTaskList[indexI].task_data[indexJ].result_image = "";
                            tmpTaskList[indexI].task_data[indexJ].status = 1;
                            tools.storage.put("TikTok_Brazil", tmpTaskList);
                            return 1;
                        } else {
                            console.log("1===TikTok_Brazil===setUserIntro===step 4")
                        }
                    } else {
                        console.log("1===TikTok_Brazil===setUserIntro===step 3")
                    }
                } else {
                    console.log("1===TikTok_Brazil===setUserIntro===step 2")
                }
            } else {
                console.log("1===TikTok_Brazil===setUserIntro===step 1")
            }
        } else {
            maxReture--;
            if (maxReture < 1) {
                // sum.setAndNotify(-3);
                return -3;
            }
            back();
            back();
            launch(pkgName);
        }
    }

    return -1;
}

// ************************************************************************
// function submitBlocked(i) {
//     try {
//         let res = {};
//         res.app_id = tmpTaskList[i].app_id;

//         utils.submitBlocked(res);
//         submitRes(i);

//     } catch (error) {
//         console.error("-1===== submit exp -1");
//     }
// }

function launchApp() {
    console.log("");
    var intent = new Intent();
    intent.setClassName(pkgName, "com.google.android.youtube.HomeActivity");
    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
    context.startActivity(intent);
};

function submitRes(i) {
    try {
        let res = {};
        res.task_id = tmpTaskList[i].task_id;
        res.task_sub_id = tmpTaskList[i].task_sub_id;
        res.ex_account = selfId;
        res.has_continuous_fail = isContinueFail;
        res.task_data = JSON.stringify(tmpTaskList[i].task_data);
        console.error("提交结果", res);
        utils.submitTask(res);
        tmpTaskList[i] = [];
        tools.storage.put(storeKey, tmpTaskList);
        console.info(" submit TikTok_Brazil end");
    } catch (error) {
        console.error("-1===== submit TikTok_Brazil exp -1");
    }
}