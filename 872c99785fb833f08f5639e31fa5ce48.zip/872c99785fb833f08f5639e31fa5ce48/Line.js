var tools = require("./tools.js");
var utils = require("./utils.js");
var pkgName = "jp.naver.line.android";
var storeKey = "Line";
var config = {};
var tmpTaskList = [];
var isContinueFail = 0;
var selfId = "";
var instance = {};
var isOver = false;
const isTest = false;
const countries = {
   '+1': 'United States',
   '+86': 'China',
   '+81': 'Japan',
   '+82': '대한민국',
   '+44': 'United Kingdom',
   '+49': 'Germany',
   '+33': 'France',
   '+61': 'Australia',
   '+91': 'India',
   // 继续添加其他国家
   '+55': 'Brazil',
};
var runing = setInterval(() => {
   if (isOver) {
      clearInterval(runing);
   }
}, 1000);

var fadeData = ` [{
            "name": "TGAI私信 ",
            "app_id": 10,
            "config":
            {
                "has_paid": 1,
                "reply_timeout": 10,
                "single_interval":
                    [
                        2,
                        5
                    ],
                "account_interval":
                    [
                        1,
                        2
                    ]
            },
            "task_id": 15,
            "has_paid": 1,
            "task_data":
                [
                    {
                        "text":
                            [
                                "走咯，打球去了"
                            ],
                        "account": "+66 886464361",
                        "detail_id": 1826
                    }
                ],
            "task_type": 8,
            "task_length": 5,
            "task_sub_id": 1316,
            "times_stop_begin": 0,
            "continuous_fail_stop": 0
        }]`;

var fakeContent = ["Olá~ Acabei de ver você no Twitter, quer bater um papo?",
   "Ouvi dizer que esse lugar é divertido. Por que você não dá uma olhada?",
   "Há muitas comidas deliciosas aqui~",
   "Pode",
   "Sem chance! ! Você não ouviu falar dessa animação? ! ! !",
   "Sem problemas",
   "Todas as manhãs quando acordo, sou grato pela sua companhia 🌅✨.",
   "Bom dia, vamos saudar o novo dia juntos com belas expectativas em nossos corações 🌞🌈.",
   "mas...",
   "Bom dia! Espero que tudo corra como você deseja hoje e que tudo seja repleto de icidade e alegria! 🥰🌻.",
   "Desejo a você um dia cheio de energia positiva e que comece o novo dia com total alidade 💪😊.",
   "Bom dia! Você é a pessoa mais especial do meu coração, desejo-lhe um bom dia! 💖✨.",
   "bom",
   "Ao amanhecer, desejo a você um dia feliz e alegre. 🌟🌱.",
   "Bom dia! Que seu dia seja repleto de bênçãos e alegrias, e que você aproveite cada momento dele! 🎉😄",
   "O sol da manhã também é minha saudação para você, que você tenha um dia maravilhoso ☀️💕.",
   "Bom dia! Cada manhã é um novo milagre. Vamos saudar o novo dia com confiança! 🌈🌼.",
   " Acorde cedo, que você sorria todos os dias e comece o dia com gratidão e carinho! 😊🌸.",
   "Ok, eu entendo",
   "Pode",
   "mas...",
   "Sem problemas",
   "Mas!",
   `${random(1, 3000)}`,
];

events.on("say", function (param) {
   console.log("进入Line", param.list);
   try {
      instance.handle(param.list);
   } catch (error) {
      console.error(error);
   }
});



instance.handle = function (taskList) {
   try {
      // 缓存检查
      tmpTaskList = tools.storage.get(storeKey, []);
      console.info("获取本地缓存=>\n", tmpTaskList);
      if (tmpTaskList.length > 0) {
         tmpTaskList.forEach((item, index) => {
            try {
               if (item.task_sub_id != taskList[index].task_sub_id) {
                  console.info("task_sub_id 与传入的taskList 不一致，判断为历史数据，准备提交");
                  submitRes(index);
                  tmpTaskList[index] = taskList[index];
               }
            } catch (error) {

            }
         })
      } else {
         tmpTaskList = taskList;
      }
      // 获取号码
      exeGetInfo();
      tools.storage.put(storeKey, tmpTaskList);

      // 开始任务
      tmpTaskList.forEach((item, i) => {
         config = tmpTaskList[i].config;
         console.info("当前任务" + item.task_data);
         exeAll(item, i);
         // 提交前，检查一边失败的，提高成功率
         recheckFailed(item, i);
         console.log("提交任务", i);
         submitRes(i);
      });
      isOver = true;
      console.log("Line exe  end");

   } catch (error) {
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
      console.error("运行中报错，保存数据::::", error);
      tools.storage.put(storeKey, tmpTaskList);
   }
}

function recheckFailed(item, i) {
   item.task_data.forEach((data, j) => {
      console.log("检查失败", tmpTaskList[i].task_data[j].status, tmpTaskList[i].task_data[j].result_text);
      if (tmpTaskList[i].task_data[j].status == 2) {
         let res = exeTask(data, i, j);
         checkRes(res, i, j);
      }
   })
}

function exeAll(item, i) {
   item.task_data.forEach((data, j) => {
      if (tmpTaskList[i].task_data[j].taskFinish) { } else {
         let res = exeTask(data, i, j);
         console.log("结果：", res);
         if (res == -4 || res == -5) {
            res = exeTask(data, i, j);
         }
         checkRes(res, i, j);
      }
      console.log("执行完一个", i, j);
   })
}

if (isTest) {
   instance.handle(fadeData);
}

function randomNum(minNum, maxNum) {
   return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}

function submitRes(i) {
   let res = {};
   res.task_id = tmpTaskList[i].task_id;
   res.task_sub_id = tmpTaskList[i].task_sub_id;
   res.ex_account = selfId;
   res.has_continuous_fail = isContinueFail;
   res.task_data = JSON.stringify(tmpTaskList[i].task_data);
   console.error("提交", res);
   let result = utils.submitTask(res);
   tools.storage.remove(storeKey);
   tmpTaskList = [];
}

function submitBlocked(i) {
   let res = {};
   res.app_id = tmpTaskList[i].app_id;

   utils.submitBlocked(res, function () {
      tools.addStatus(tmpTaskList[i].pkgName);
      console.log("账号被封禁提交成功");
   });
}

function checkRes(res, i, j) {
   if (res == -4) {
      console.log(`(s=${res}) 控件未找到`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 6;
      tmpTaskList[i].task_data[j].result_text = "控件未找到";
   }
   if (res == 100) {
      console.log(`(s=${res}) 成功`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 1;
      tmpTaskList[i].task_data[j].result_text = "成功";
   }
   if (res == -10) {
      console.log(`(s=${res}) 账号被禁`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "账号被禁";
      tmpTaskList[i].task_data[j].status = 4;
      isOver = true;
   }
   if (res == -11) {
      console.log(`(s=${res})未登录`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 5;
      tmpTaskList[i].task_data[j].result_text = "未登录";
      isOver = true;
   }
   if (res == -20) {
      console.log(`(s=${res}) 目标账号不存在`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "目标账号不存在";
      tmpTaskList[i].task_data[j].status = 3;
   }
   if (tmpTaskList[i].task_data[j].taskFinish) { } else {
      console.log(`(s=${res}) 失败`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 2;
      tmpTaskList[i].task_data[j].result_text = "失败";
   }
   tools.storage.put(storeKey, tmpTaskList);
}

// **************************************辅助函数**************************************
function launchApp() {
   try {
      app.startActivity({
         action: "android.intent.action.MAIN",
         packageName: "jp.naver.line.android",
         className: "jp.naver.line.android.activity.SplashActivity",
         flags: ["grant_read_uri_permission", "grant_write_uri_permission", "activity_clear_top", "activity_new_task", "activity_clear_task"]
      });
      sleep(3000);
      if (currentPackage() !== pkgName) {
         launchApp();
      }
   } catch (error) {
      console.error("启动失败:", e);
   }
};

function findCountry(tmpCountryCode) {
   try {
      let isFind = false;
      console.info(countries[tmpCountryCode]);
      let phone_country_listNode = id("jp.naver.line.android:id/phone_country_list").findOne(5000);
      if (phone_country_listNode) {
         console.log(3);
         phone_country_listNode.children().forEach(function (child) {
            let tmpCodeNode = child.findOne(text(countries[tmpCountryCode]));
            if (tmpCodeNode) {
               child.click();
               sleep(500);
               back();
               sleep(500);
               isFind = true;
               console.info("找到了");
            }
         })
         console.log(4);
         if (!isFind && text("Zimbabwe").findOne(2000)) {
            console.info("到底了");
            isFind = true;
         }
         console.log(5);
         if (isFind) return 100;
         console.log(6);
         let posX = device.width / 2;
         let posY = device.height / 3 * 2;
         swipe(posX, posY, posX, posY - device.height / 3, 500);
         sleep(1000);
         console.log(7);
         return findCountry(tmpCountryCode);
      }
   } catch (error) {
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
      console.error("查找国家Code异常", error);
      tools.storage.put(storeKey, tmpTaskList);
      return -5;
   }
}

function exeTask(data, i, j) {
   try {
      launchApp();
      sleep(random(3000, 5000));

      // let chatNode = packageName(pkgName).id("jp.naver.line.android:id/bnb_home_v2").findOne(5000);
      // console.info(chatNode);
      // if (!chatNode) {
      //    return -4;
      // }
      // let chatNodeArea = chatNode.findOne(id("jp.naver.line.android:id/bnb_button_clickable_area"));
      console.log(1)
      let chatNodeArea = id("jp.naver.line.android:id/bnb_button_clickable_area").findOne(5000);
      if (!chatNodeArea || !chatNodeArea.click()) {
         //    let notAccountNode = textStartsWith("Esta conta não").findOne(5000);
         //    if (notAccountNode) {
         //       submitBlocked(indexI);
         //       console.info("准备提交任务");
         //       return -10;
         //    }

         let notLoginNode = id("jp.naver.line.android:id/login").findOne(5000);
         if (notLoginNode) {
            return -11;
         }
         return -4;
      }
      sleep(500);

      console.log(2);
      let addFriendNode = id("jp.naver.line.android:id/add_friends_header_button").findOne(5000);
      if (!addFriendNode || !addFriendNode.click()) {
         return -4;
      }
      sleep(500);


      console.log(3);

      let searchNode = textMatches(/(Pesquisar|Buscar|Search|ค้นหา)/).findOne(5000);
      if (!searchNode) {
         return -4;
      }
      click("Pesquisar");
      click("Buscar");
      click("Search");
      click("ค้นหา");
      sleep(500);

      console.log(4);
      data.account = "+66 886464361";
      let phoneNumberArray = data.account.split(" ");
      if (phoneNumberArray.length < 2) {
         let radioNode = className("android.widget.RadioButton").textMatches(/(ID|LINE ID)/).findOne(5000);
         if (!radioNode) {
            return -4;
         }
         radioNode.click();
         sleep(500);
         let phoneNumber = id("jp.naver.line.android:id/addfriend_by_userinfo_search_text").findOne(5000);
         phoneNumber.setText(phoneNumberArray[0]);
      } else {
         let radioNode = className("android.widget.RadioButton").textMatches(/(Número de telefone|abc)/).findOne(5000);
         if (!radioNode) {
            return -4;
         }
         radioNode.click();
         sleep(500);

         let countryCodeNode = id("jp.naver.line.android:id/addfriend_by_userid_country_code").findOne(5000);
         console.log("国家：", countryCodeNode.text(), "--", phoneNumberArray[0]);
         if (countryCodeNode && countryCodeNode.text() != phoneNumberArray[0]) {
            let countryCodeNode = id("jp.naver.line.android:id/addfriend_by_userid_select_country_code_click_area").findOne(5000);
            if (countryCodeNode && countryCodeNode.click()) {
               let isOk = findCountry(phoneNumberArray[0]);
               if (isOk != 100) {
                  return -4;
               }
            }
            sleep(500);
         }
         let phoneNumber = id("jp.naver.line.android:id/addfriend_by_userinfo_search_text").findOne(5000);
         phoneNumber.setText(phoneNumberArray[1]);
         sleep(500);
      }

      console.log(5);
      let addFriendSearchNode = id("jp.naver.line.android:id/addfriend_search_button").findOne(5000);
      if (!addFriendSearchNode || !addFriendSearchNode.click()) {
         return -4;
      }
      sleep(500);

      console.log(6);
      //  失败
      // text("Usuário não encontrado").findOne(5000);
      // 成功
      let chatAddFriendNode = id("jp.naver.line.android:id/addfriend_add_button").findOne(5000);
      if (!chatAddFriendNode || (chatAddFriendNode && !chatAddFriendNode.click())) {
         return reGetTarget(data, i, j, 20);
      }
      sleep(500);

      console.log(7);
      return sendMsg(i, j);
   } catch (error) {
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
      console.error("运行中报错，保存数据::::", error);
      tools.storage.put(storeKey, tmpTaskList);
      return -5;
   }
}

function reGetTarget() {
   if (maxNum < 1) return -20;

   var result = utils.redistributionWs(tmpTaskList[i].task_sub_id, data.detail_id);
   if (result == -100) {
      console.log('重新分配账号接口');
      return -20;
   }
   if (result == -2) {
      console.log('重试3次后重新分配账号仍然失败');
      return -20;
   }
   data.account = result;
   data.account = "+66 886464361";
   let phoneNumberArray = data.account.split(" ");
   if (phoneNumberArray.length < 2) {
      let radioNode = className("android.widget.RadioButton").textMatches(/(ID|LINE ID)/).findOne(5000);
      if (!radioNode) {
         return -4;
      }
      radioNode.click();
      sleep(500);
      let phoneNumber = id("jp.naver.line.android:id/addfriend_by_userinfo_search_text").findOne(5000);
      phoneNumber.setText(phoneNumberArray[0]);
   } else {
      let radioNode = className("android.widget.RadioButton").textMatches(/(Número de telefone|abc)/).findOne(5000);
      if (!radioNode) {
         return -4;
      }
      radioNode.click();
      sleep(500);

      let countryCodeNode = id("jp.naver.line.android:id/addfriend_by_userid_country_code").findOne(5000);
      console.log("国家：", countryCodeNode.text(), "--", phoneNumberArray[0]);
      if (countryCodeNode && countryCodeNode.text() != phoneNumberArray[0]) {
         let countryCodeNode = id("jp.naver.line.android:id/addfriend_by_userid_select_country_code_click_area").findOne(5000);
         if (countryCodeNode && countryCodeNode.click()) {
            let isOk = findCountry(phoneNumberArray[0]);
            if (isOk != 100) {
               return -4;
            }
         }
         sleep(500);
      }
      let phoneNumber = id("jp.naver.line.android:id/addfriend_by_userinfo_search_text").findOne(5000);
      phoneNumber.setText(phoneNumberArray[1]);
      sleep(500);
   }

   console.log(5);
   let addFriendSearchNode = id("jp.naver.line.android:id/addfriend_search_button").findOne(5000);
   if (!addFriendSearchNode || !addFriendSearchNode.click()) {
      return -4;
   }
   sleep(500);

   console.log(6);
   //  失败
   // text("Usuário não encontrado").findOne(5000);
   // 成功
   let chatAddFriendNode = id("jp.naver.line.android:id/addfriend_add_button").findOne(5000);
   if (!chatAddFriendNode || (chatAddFriendNode && !chatAddFriendNode.click())) {
      return reGetTarget(data, i, j, 20);
   }

   return sendMsg(i, j);
}

function sendMsg(indexI, indexJ) {
   let oneData = tmpTaskList[indexI].task_data[indexJ];
   try {
      let editNode = id("jp.naver.line.android:id/chat_ui_message_edit").findOne(5000);
      if (!editNode) {
         return -4;
      }
      if (oneData.text) {
         if (!tmpTaskList[indexI].task_data[indexJ].sendedList) {
            tmpTaskList[indexI].task_data[indexJ].sendedList = [];
         }
         // 发送
         for (let index = 0; index < oneData.text.length; index++) {
            console.info("发送过了:", tmpTaskList[indexI].task_data[indexJ].sendedList.includes(index), oneData.text[index]);
            if (oneData.sendedList && tmpTaskList[indexI].task_data[indexJ].sendedList.includes(index)) { continue; }
            let element = oneData.text[index];
            editNode.setText(element);
            sleep(500);
            let sendNode = id("jp.naver.line.android:id/chat_ui_send_button_image").findOne(5000);
            if (sendNode && sendNode.click()) {
               tmpTaskList[indexI].task_data[indexJ].sendedList.push(index);
               tools.storage.put(storeKey, tmpTaskList);
               sleep(500);
               // if (index + 1 < oneData.text.length) {
               let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
               sleep(randTime * 1000);
               // }
            }
         }

         let tmpArray = tmpTaskList[indexI].task_data[indexJ].sendedList;
         tools.storage.put(storeKey, tmpTaskList);

         // 检测
         let msgListNode = id("jp.naver.line.android:id/chathistory_message_list").findOne(5000);
         if (!tmpTaskList[indexI].task_data[indexJ].hasOwnProperty("oldSendTime")) {
            tmpTaskList[indexI].task_data[indexJ].oldSendTime = 0;
         }
         if (msgListNode) {
            let tmpMsgList = msgListNode.children().reverse();
            tmpArray = tmpArray.reverse();
            tmpArray.forEach(element => {
               try {
                  tmpMsgList.forEach(function (child) {
                     let tmpSendMsgNode = child.findOne(text(oneData.text[element]));
                     let leftMsgNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_message_layout"));
                     console.info("距离：", leftMsgNode.bounds().centerX(), device.width);
                     // if (tmpSendMsgNode && (leftMsgNode && leftMsgNode.bounds().centerX() - 431 > device.width / 2)) {
                     if (tmpSendMsgNode) {
                        console.log(tmpSendMsgNode.text());
                        let tmpSendMsgTimeNode = child.findOne(id("jp.naver.line.android:id/chat_ui_row_timestamp"));
                        if (tmpSendMsgTimeNode) {
                           console.info("时间距离：", tmpSendMsgTimeNode.bounds().centerX(), device.width);
                           tmpTaskList[indexI].task_data[indexJ].lastSendTimeText = tmpSendMsgTimeNode.text();
                           tmpTaskList[indexI].task_data[indexJ].lastSendTime = Date.now();
                           tools.storage.put(storeKey, tmpTaskList);
                           throw new Error();
                        }
                        return;
                     }
                  });
               } catch (error) {

               }
            });
         }

         if (tmpTaskList[indexI].task_data[indexJ].hasOwnProperty("lastSendTime") &&
            tmpTaskList[indexI].task_data[indexJ].lastSendTime >= tmpTaskList[indexI].task_data[indexJ].oldSendTime) {
            tmpTaskList[indexI].task_data[indexJ].oldSendTime = tmpTaskList[indexI].task_data[indexJ].lastSendTime;
            tools.storage.put(storeKey, tmpTaskList);
            return 100;
         }
         return -4;
      }
      return -4;
   } catch (error) {
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
      console.error("运行中报错，保存数据::::", error);
      tools.storage.put(storeKey, tmpTaskList);
      return -5;
   }
}

function exeGetInfo() {
   try {
      launchApp();
      console.log("getinfo---", 1);
      // let chatNode = selector().id("jp.naver.line.android:id/bnb_home_v2").findOne(5000);
      // console.info(chatNode);
      // console.log("getinfo---", 1);
      // let chatNode = id("jp.naver.line.android:id/bnb_home_v2").findOne(10000);
      // console.info(chatNode);
      // if (!chatNode) {
      //    return -4;
      // }

      // let chatNodeArea = chatNode.findOne(id("jp.naver.line.android:id/bnb_button_clickable_area"));
      console.log(1.1);
      let chatNodeArea = id("jp.naver.line.android:id/bnb_button_clickable_area").findOne(5000);
      if (!chatNodeArea || !chatNodeArea.click()) {
         return -4;
      }
      sleep(500);

      console.log("getinfo---", 1.1);
      let settingNode = id("jp.naver.line.android:id/settings_header_button").findOne(5000);
      if (!settingNode || !settingNode.click()) {
         return -4;
      }
      sleep(500);

      console.log("getinfo---", 2);
      let settingListNode = id("jp.naver.line.android:id/setting_list").findOne(5000);
      if (!settingListNode) {
         return -4;
      }
      console.log("getinfo---", 3);
      let selfInfoNode = settingListNode.children()[1];
      if (!selfInfoNode || !selfInfoNode.click()) {
         return -4;
      }
      sleep(5000);
      console.log("getinfo---", 4);
      let selfInfoListNode = descStartsWith("ID,").findOne(5000);
      if (selfInfoListNode) {
         console.log("getinfo---", 4.1);
         selfId = selfInfoListNode.desc();
         console.log("自己号码：", selfId);

         if (selfId) {
            return 1;
         }
      }
      return -10;
   } catch (error) {
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
      console.error("运行中报错，保存数据::::", error);
      tools.storage.put(storeKey, tmpTaskList);
      return -5;
   }
}


//module.exports = instance;
