// 使用构造函数模拟类
function Utils() {
    // 初始化语言和区域设置
    this.locale = new java.util.Locale.getDefault();
    this.language = this.locale.getLanguage();

    // 从引擎参数中获取 host 和 token
    this.host = engines.myEngine().execArgv.host;
    this.token = engines.myEngine().execArgv.token;
    this.forceStop = engines.myEngine().execArgv.forceStop;

    // 绑定方法，确保 this 始终指向 Utils 的实例
    this.checkLogin = this.checkLogin.bind(this);
    this.getTask = this.getTask.bind(this);
    this.submitTask = this.submitTask.bind(this);
    this.submitBug = this.submitBug.bind(this);
    this.submitBlocked = this.submitBlocked.bind(this);
    this.redistribution = this.redistribution.bind(this);
    this.bindAccount = this.bindAccount.bind(this);
}

// 在原型上定义方法
Utils.prototype.checkLogin = function () {
    console.log("checkLogin token:" + this.token);
    console.log("this:", this.token); // 打印 this 的值
    if (!this.token || this.token.length < 1) {
        toast("aplicativo não logado!");
        return false;
    }
    return true;
};

Utils.prototype.getTask = function (jsonData, forceStop, handle) {
    try {
        if (!this.checkLogin()) return null;
        console.log("[getTask]host:" + this.host);
        console.log("[getTask]handle:" + handle);
        // let res = http.post(this.host + "/app/task/receive/round", {
        //     "app_id": app_id
        // }, {
        //     headers: {
        //         "content-type": "application/json",
        //         "Authorized-Key": this.token,
        //         "lang": this.language,
        //     }
        // });
        // if (res.statusCode != 200) {
        //     console.error("get data error[getTask]: ", res.statusCode + " " + res.statusMessage);
        //     return null;
        // }
        // let jsonData = res.body.json();
        console.log("getTask任务数据:", jsonData);
        console.log("[getTask]:contentStr:" + this.contentStr);
        let e = engines.execScriptFile(handle, {
            arguments: {
                host: this.host,
                token: this.token,
                forceStop: forceStop,
                key: this.contentStr,
            }
        });
        console.log("[getTask]:engines execScriptFile");
        let time = random(4000, 6000);
        console.log("[getTask]:等待" + (time / 1000) + "秒");
        sleep(time);
        if (!e.getEngine()) {
            console.error("[getTask]:引擎未初始化，脚本可能执行失败");
            return;
        }
        e.getEngine().emit("say", { list: jsonData });
        console.log("[getTask]:getEngine().emit(say)");
        if (e.getEngine()) {
            return e;
        }
        return null;
    } catch (error) {
        console.error(error);
        return null;
    }
};


Utils.prototype.startTalk = function (detail_id, msg_content, is_pic, is_end) {
    const MAX_RETRIES = 3; // 最大重试次数
    let retries = 0;
    // var jk = [
    //     "Eu não disse isso.",
    //     "Eu não gosto muito disso",
    //     "Algo mais?",
    //     "Um pouco mais",
    //     "Não é bom, troque por outro",
    // ];
    // var mm = `{ "text": [ " 111"],"is_end":0 }`;
    // var kl = JSON.parse(mm);
    // if (is_end == 1) {
    //     kl.text = ["ByeBye~"];
    //     kl.is_end = 1;
    // } else {
    //     kl.text = [jk[random(0, jk.length)]];
    // }
    // return kl;
    const attemptTalk = () => {
        try {
            let res = http.post(this.host + "/app/task/chat", {
                "detail_id": detail_id,
                "message": msg_content,
                "is_pic": is_pic,
                "is_end": is_end,
            }, {
                headers: {
                    "content-type": "application/json",
                    "Authorized-Key": this.token,
                    "lang": this.language,
                },
            });
            if (res.statusCode != 200) {
                console.error("get data error[getTask]: ", res.statusCode + " " + res.statusMessage);
                return null;
            }
            let jsonData = res.body.json();
            if (jsonData.code == 0) {
                console.log("会话请求结果 ::", jsonData.data);
                return jsonData.data;
            } else {
                console.log("[对话接口报错]:" + jsonData.message);
                return null;
            }
        } catch (e) {
            if (e.toString().includes("StreamResetException")) {
                if (retries < MAX_RETRIES) {
                    retries++;
                    console.log(`对话请求，重试第 ${retries} 次...`);
                    return attemptTalk();
                } else {
                    console.error("对话请求，重试次数已达上限，返回 null");
                    return null;
                }
            } else {
                console.log("对话请求接口报错：", e);
                return null;
            }
        }
    };
    return attemptTalk();
}


Utils.prototype.submitTask = function (res) {
    console.log("submitTask");
    if (!this.checkLogin()) throw new Error("提交任务失败[submitTask]: 未登录");
    console.log("host:" + this.host);
    let timestamp = new Date().getTime();
    res.sign = engines.myEngine().executeTask(res.task_data.replace(/\s+/g, ''), timestamp);
    res.timestamp = timestamp;
    console.log(res);
    let result = http.post(this.host + "/app/task/submitting", res, {
        headers: {
            "content-type": "application/json",
            "Authorized-Key": this.token,
            "lang": this.language,
        }
    });
    console.log(result);
    if (result == null || result.statusCode != 200) {
        console.error("提交任务失败[submitTask]: ");
        if (result.statusCode) {
            console.info("失败原因:", result.statusCode + " " + result.statusMessage);
        }
        throw new Error("提交任务失败");
    } else {
        let jsonData = result.body.json();
        if (jsonData.code == 0) {
            console.error("提交任务成功: ", jsonData);
        } else {
            console.error("提交任务失败: ", jsonData);
        }
    }
};

Utils.prototype.redistribution = function (task_sub_id, detail_id) {
    console.log("redistribution");
    if (!this.checkLogin()) throw new Error("重新分配任务失败[redistribution]: 未登录");
    console.log("host:" + this.host);

    let result = http.post(this.host + "/app/task/redistribution", {
        "task_sub_id": task_sub_id,
        "detail_id": detail_id
    }, {
        headers: {
            "content-type": "application/json",
            "Authorized-Key": this.token,
            "lang": this.language,
        }
    });

    console.log("重新分配任务结果:", result);
    return result.body.json().data.account;
};


Utils.prototype.redistributionWs = function (task_sub_id, detail_id) {
    console.log("redistributionWs");
    if (!this.checkLogin()) throw new Error("重新分配任务失败[redistributionWs]: 未登录");
    console.log("host:" + this.host);

    const MAX_RETRIES = 3; // 最大重试次数
    let retries = 0;

    const attemptReAccount = () => {
        try {
            console.log("redistributionWs attemptReAccount执行");
            let result = http.post(this.host + "/app/task/redistribution", {
                "task_sub_id": task_sub_id,
                "detail_id": detail_id
            }, {
                headers: {
                    "content-type": "application/json",
                    "Authorized-Key": this.token,
                    "lang": this.language,
                }
            });
            console.log(result);
            if (result == null || result.statusCode != 200) {
                console.error("请求重新分配失败[redistribution]: ");
                if (result.statusCode) {
                    console.info("失败原因:", result.statusCode + " " + result.statusMessage);
                }
                if (retries < MAX_RETRIES) {
                    retries++;
                    console.log(`重试第 ${retries} 次...`);
                    return attemptReAccount();
                } else {
                    console.error("重试次数已达上限，返回 -2");
                    return -2;
                }
            }
            let jsonData = result.body.json();
            if (jsonData.code == 0) {
                if (jsonData.data.account) {
                    console.error("请求重新分配成功: ", jsonData.data.account);
                    return jsonData.data.account;
                } else {
                    console.error("请求重新分配code = 0: ", jsonData.data.account);
                    return -100;
                }
            } else {
                console.error("请求重新分配失败: ", jsonData);
                if (retries < MAX_RETRIES) {
                    retries++;
                    console.log(`重试第 ${retries} 次...`);
                    return attemptReAccount();
                } else {
                    console.error("重试次数已达上限，返回 -2");
                    return -2;
                }
            }
        } catch (error) {
            console.error(error);
            if (retries < MAX_RETRIES) {
                retries++;
                console.log(`重试第 ${retries} 次...`);
                return attemptReAccount();
            } else {
                console.error("重试次数已达上限，返回 -2");
                return -2;
            }
        }
    }

    return attemptReAccount();
};

Utils.prototype.redistributionWsLink = function (task_sub_id, detail_id) {
    console.log("redistributionWs");
    if (!this.checkLogin()) throw new Error("重新分配任务失败[redistributionWs]: 未登录");
    console.log("host:" + this.host);

    const MAX_RETRIES = 3; // 最大重试次数
    let retries = 0;

    const attemptReAccount = () => {
        try {
            console.log("redistributionWs attemptReAccount执行");
            let result = http.post(this.host + "/app/task/reset_source", {
                "task_sub_id": task_sub_id,
                "detail_id": detail_id
            }, {
                headers: {
                    "content-type": "application/json",
                    "Authorized-Key": this.token,
                    "lang": this.language,
                }
            });
            console.log(result);
            if (result == null || result.statusCode != 200) {
                console.error("请求重新分配失败[redistribution]: ");
                if (result.statusCode) {
                    console.info("失败原因:", result.statusCode + " " + result.statusMessage);
                }
                if (retries < MAX_RETRIES) {
                    retries++;
                    console.log(`重试第 ${retries} 次...`);
                    return attemptReAccount();
                } else {
                    console.error("重试次数已达上限，返回 -2");
                    return -2;
                }
            }
            let jsonData = result.body.json();
            if (jsonData.code == 0) {
                if (jsonData.data.res_content) {
                    console.error("请求重新分配成功: ", jsonData.data.res_content);
                    return jsonData.data.res_content;
                } else {
                    console.error("请求重新分配code = 0: ",jsonData.data.res_content);
                    return -100;
                }
            } else {
                console.error("请求重新分配失败: ", jsonData);
                if (retries < MAX_RETRIES) {
                    retries++;
                    console.log(`重试第 ${retries} 次...`);
                    return attemptReAccount();
                } else {
                    console.error("重试次数已达上限，返回 -2");
                    return -2;
                }
            }
        } catch (error) {
            console.error(error);
            if (retries < MAX_RETRIES) {
                retries++;
                console.log(`重试第 ${retries} 次...`);
                return attemptReAccount();
            } else {
                console.error("重试次数已达上限，返回 -2");
                return -2;
            }
        }
    }

    return attemptReAccount();
};

Utils.prototype.addBindFail = function (pkgName, bindOther) {
    engines.myEngine().addBindFail(pkgName, bindOther);
}

Utils.prototype.bindAccount = function (app_id, account, task_sub_id, remark) {
    console.log("bindAccount:app_id:" + app_id + " account:" + account + " task_sub_id:" + task_sub_id + " remark:" + remark);
    const MAX_RETRIES = 3; // 最大重试次数
    let retries = 0;

    const attemptBind = () => {
        try {
            console.log("bindAccount");
            if (!this.checkLogin()) throw new Error("请求绑定失败[bindAccount]: 未登录");
            console.log("host:" + this.host);
            let result = http.post(this.host + "/app/task/bind_account", {
                "app_id": app_id,
                "account": account,
                "task_sub_id": task_sub_id,
                "remark": remark
            }, {
                headers: {
                    "content-type": "application/json",
                    "Authorized-Key": this.token,
                    "lang": this.language,
                }
            });
            console.log(result);
            if (result == null || result.statusCode != 200) {
                console.error("请求绑定失败[submitTask]: ");
                if (result.statusCode) {
                    console.info("失败原因:", result.statusCode + " " + result.statusMessage);
                }
                throw new Error("请求绑定失败");
            }

            let jsonData = result.body.json();
            if (jsonData.code == 0) {
                console.error("请求绑定成功: ", jsonData);
                return 1;
            } else {
                console.error("请求绑定失败: ", jsonData);
                if (jsonData.code == 1001) {
                    return -100;
                }
                return -1;
            }
        } catch (error) {
            console.error(error);
            if (retries < MAX_RETRIES) {
                retries++;
                console.log(`重试第 ${retries} 次...`);
                return attemptBind();
            } else {
                console.error("重试次数已达上限，返回 -1");
                return -2;
            }
        }
    };

    return attemptBind();
};

Utils.prototype.submitBug = function (res) {
    try {
        if (!this.checkLogin()) return;
        console.log("host:" + this.host);
        let result = http.post(this.host + "/app/debug", res, {
            headers: {
                "content-type": "application/json",
                "Authorized-Key": this.token,
            }
        });
        if (result == null || result.statusCode != 200) {
            console.error("提交任务失败[submitBug]: ");
            if (result.statusCode) {
                console.info("失败原因:", result.statusCode + " " + result.statusMessage);
            }
        } else {
            let jsonData = result.body.json();
            if (jsonData.code == 0) {
                console.error("[submitBug]提交成功: ", jsonData);
                // handle(jsonData.data);
            } else {
                console.error("[submitBug]提交失败: ", jsonData);
            }
        }
    } catch (error) {
        console.error(error);
    }
    return;
};

Utils.prototype.submitBlocked = function (res, handle) {
    try {
        if (!this.checkLogin()) return;
        console.log("host:" + this.host);
        let result = http.post(this.host + "/app/account/blocked", res, {
            headers: {
                "content-type": "application/json",
                "Authorized-Key": this.token,
            }
        });
        if (result == null || result.statusCode != 200) {
            console.error("提交任务失败[submitBlocked]: ");
            if (result.statusCode) {
                console.info("失败原因:", result.statusCode + " " + result.statusMessage);
            }
        } else {
            let jsonData = result.body.json();
            if (jsonData.code == 0) {
                console.error("[submitBlocked]提交成功: ", jsonData);
                handle();
            } else {
                console.error("[submitBlocked]提交失败: ", jsonData);
            }
        }
    } catch (error) {
        console.error(error);
    }
    return;
};

// 导出 Utils 的实例
module.exports = new Utils();