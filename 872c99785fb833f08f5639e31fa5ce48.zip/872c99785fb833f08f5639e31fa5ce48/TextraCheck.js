// 错误代码常量
const ErrorCodes = {
    APP_LAUNCH_FAILED: 1001,
    ELEMENT_NOT_FOUND: 1002,
    CLICK_FAILED: 1003,
    INPUT_FAILED: 1004,
    CONTACT_LIST_ERROR: 1005,
    CONTACT_SELECT_ERROR: 1006,
    UPLOAD_FAILED: 1007
};

function OperationError(code, message) {
    Error.call(this);
    this.name = 'OperationError';
    this.code = code;
    this.message = message;
}

// 简化配置对象
const CONFIG = {
    packageName: "com.textra",
    activityName: "com.mplus.lib.ui.main.Main",
    maxRetries: 10,
    retryInterval: 500,
    uiWaitTime: 1000,
    findOneTimeout: 1000
};

// 添加全局存储常量
const STORAGE = storages.create("textra_messages");

// 等待并点击元素的通用函数
function waitAndClick(selector, useBounds, description) {
    console.log("开始等待并点击元素:", description || "未指定元素");
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试查找元素 (第" + (retries + 1) + "次)");
            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                console.error("未找到目标元素:", description);
                throw new OperationError(
                    ErrorCodes.ELEMENT_NOT_FOUND,
                    "未找到目标元素: " + description
                );
            }
            console.log("已找到目标元素");

            sleep(500);
            if (useBounds) {
                console.log("使用bounds方式点击");
                var bounds = element.bounds();
                if (!bounds) {
                    console.error("获取元素边界失败:", description);
                    throw new OperationError(
                        ErrorCodes.CLICK_FAILED,
                        "获取元素边界失败: " + description
                    );
                }
                console.log("点击坐标:", bounds.centerX(), bounds.centerY());
                click(bounds.centerX(), bounds.centerY());
            } else {
                element.click();
            }
            console.log("点击成功");
            return;

        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                console.log("检测到脚本中断");
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                console.error("达到最大重试次数，点击失败");
                throw new OperationError(
                    ErrorCodes.CLICK_FAILED,
                    "点击元素失败: " + description + " - " + e.message
                );
            }
            console.log("点击失败，等待重试");
            sleep(CONFIG.retryInterval);
        }
    }
}

function setTextSafely(selector, text) {
    console.log("开始设置文本:", text);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试设置文本 (第" + (retries + 1) + "次)");

            let element = selector.findOne(CONFIG.findOneTimeout);
            if (!element) {
                console.error("未找到输入框元素");
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "未找到输入框元素");
            }

            sleep(500);
            element.setText("");
            sleep(200);
            let success = element.setText(text);
            if (!success) {
                console.error("设置文本失败");
                retries++;
                if (retries < CONFIG.maxRetries) {
                    sleep(CONFIG.retryInterval);
                    continue;
                }
                throw new OperationError(ErrorCodes.INPUT_FAILED, "设置文本失败");
            }
            console.log("文本设置成功");
            return;
        } catch (e) {
            // 修改中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries < CONFIG.maxRetries) {
                sleep(CONFIG.retryInterval);
                continue;
            }
            throw new OperationError(ErrorCodes.INPUT_FAILED, "设置文本失败: " + e.message);
        }
    }
    throw new OperationError(ErrorCodes.INPUT_FAILED, "设置文本失败，已达到最大重试次数");
}

// 启动Telegram应用
function launchApp() {
    console.log("开始启动应用:", CONFIG.packageName);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            console.log("尝试启动应用 (第" + (retries + 1) + "次)");
            app.startActivity({
                packageName: CONFIG.packageName,
                className: CONFIG.activityName,
                flags: ["activity_new_task", "activity_clear_task", "activity_clear_top"]
            });
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.APP_LAUNCH_FAILED,
                    "应用启动失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

function findElement(selector, description) {
    console.log("查找元素的选择器:", selector);
    description = description || "元素";
    console.log("开始查找" + description);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let element = selector.findOne(CONFIG.findOneTimeout);
            console.log("找到元素:", element);
            if (element) {
                return element;
            }
            console.log("元素无效或为空对象");
        } catch (e) {
            // 添加中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("查找" + description + "时发生错误:", e);
        }
        console.log("第" + (retries + 1) + "次尝试查找" + description);
        retries++;
        sleep(CONFIG.retryInterval);
    }
    throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "多次尝试后仍找不到" + description);
}

function editPhoneNumber(phoneNumber) {
    console.log("开始输入手机号码:", phoneNumber);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let input = className("android.widget.EditText").findOne(CONFIG.findOneTimeout);
            if (!input) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "未找到输入框"
                );
            }
            input.setText("");
            if (!input.setText(phoneNumber)) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "输入手机号失败"
                );
            }
            return;
        } catch (e) {
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.INPUT_FAILED,
                    "输入手机号码失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

function openChatWithContact(phoneNumber) {
    console.log("准备直接打开与联系人的聊天:", phoneNumber);
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            launchApp();
            sleep(CONFIG.uiWaitTime);

            waitAndClick(id(CONFIG.packageName + ":id/floating_button"), false);
            sleep(CONFIG.uiWaitTime);

            editPhoneNumber(phoneNumber);
            sleep(1000);

            clickFirstConcatItem();
            sleep(1000);
            return;
        } catch (e) {
            // 检查是否是脚本中断
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            console.error("打开聊天界面失败:", e);
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.APP_LAUNCH_FAILED,
                    "打开聊天界面失败: " + e.message
                );
            }
            console.log("第" + (retries + 1) + "次重试打开聊天界面");
            sleep(CONFIG.retryInterval);
        }
    }
}

function clickFirstConcatItem() {
    let retries = 0;
    while (retries < CONFIG.maxRetries) {
        try {
            let contactList = id(CONFIG.packageName + ":id/quickContactsList").findOne(CONFIG.findOneTimeout);
            if (!contactList) {
                throw new OperationError(
                    ErrorCodes.CONTACT_LIST_ERROR,
                    "未找到联系人列表"
                );
            }

            let firstContact = contactList.child(0);
            if (!firstContact) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    "未找到第一个联系人"
                );
            }

            if (firstContact.findOne(id(CONFIG.packageName + ":id/contactNumber"))) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    "联系人项无效"
                );
            }

            if (!firstContact.click()) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    "点击联系人失败"
                );
            }
            return;
        } catch (e) {
            // 添加中断检查
            if (e.toString().includes("ScriptInterruptedException")) {
                throw e;
            }
            retries++;
            if (retries >= CONFIG.maxRetries) {
                throw new OperationError(
                    ErrorCodes.CONTACT_SELECT_ERROR,
                    e instanceof OperationError ? e.message : "选择联系人失败: " + e.message
                );
            }
            sleep(CONFIG.retryInterval);
        }
    }
}

function readReceivedMessages() {
    console.log("开始读取消息记录");

    try {
        console.log("尝试获取消息列表元素");
        // 查找并点击 Go to bottom 按钮
        let goToBottomBtn = desc("Go to bottom").findOne(2000);
        if (goToBottomBtn) {
            console.log("找到 Go to bottom 按钮,准备点击");
            goToBottomBtn.click();
            sleep(2000); // 等待滚动完成
        }
        let messageList = className("androidx.recyclerview.widget.RecyclerView").findOne(5000);
        if (!messageList) {
            throw new OperationError(ErrorCodes.ELEMENT_NOT_FOUND, "未找到消息列表");
        }

        let messages = [];
        let pendingMessages = [];
        let previousHeight = 0;
        let sameHeightCount = 0;
        let noNewMessagesCount = 0;
        const MAX_SCROLL_ATTEMPTS = 30;

        for (let scrollAttempt = 0; scrollAttempt < MAX_SCROLL_ATTEMPTS; scrollAttempt++) {
            console.log(`第${scrollAttempt + 1}次滚动`);

            // 等待内容加载完成
            sleep(1000);

            // 重要修改：每次滚动后重新获取消息列表
            let visibleMessages = [];
            let messageElements = id("com.textra:id/row").find();
            console.log("找到的元素:", messageElements.length);
            // 遍历当前可见的消息
            // 将消息元素转换为数组并倒序遍历
            Array.from(messageElements).reverse().forEach(item => {
                if (!item) {
                    console.log("消息元素为空,跳过处理");
                    return;
                }

                try {
                    // 重要修改：确保获取最新的文本内容
                    item.refresh();
                    // 获取消息内容
                    let bubble = item.findOne(id("com.textra:id/bubble"));
                    if (!bubble) {
                        console.log("警告：项目中未找到气泡内容");
                        return;
                    }

                    let content = bubble.text();
                    if (content) {
                        console.log("获取到消息内容:", content);
                        console.log("消息内容类型:", typeof content);
                        console.log("消息内容长度:", content.length);
                        visibleMessages.push(content);
                    } else {
                        console.log("消息内容为空");
                    }

                    // 首先检查是否是日期标签
                    let dateLabel = item.findOne(id("com.textra:id/date_label"));
                    if (dateLabel) {
                        let currentTime = dateLabel.text();
                        console.log("找到日期标签，当前时间:", currentTime);
                        console.log("时间标签类型:", typeof currentTime);
                        console.log(`处理 ${visibleMessages.length} 条待处理消息`);
                        // 处理之前收集的消息
                        visibleMessages.forEach(content => {
                            console.log("添加消息到列表:", content, currentTime);
                            console.log("消息对象结构:", { content, time: currentTime });
                            pendingMessages.push({
                                content: content,
                                time: currentTime
                            });
                        });
                        visibleMessages = [];
                    }
                } catch (itemError) {
                    console.log("处理消息元素时出错:", itemError);
                    console.log("错误详情:", itemError.stack);
                }
            });

            // 修改添加新消息的逻辑
            let foundUploadedMessage = false;
            let newMessagesCount = 0;
            console.log("当前可见消息数:", pendingMessages.length);

            // 获取上一次上传的消息
            let lastUploadedMessage = getLastUploadMessage(phoneNumber);
            console.log("上次上传的消息:", lastUploadedMessage);

            for (let msg of pendingMessages) {
                let isDuplicate = messages.some(m =>
                    m.content === msg.content && m.time === msg.time
                );

                if (!isDuplicate) {
                    let currentMessageId = `${msg.content}_${msg.time}`;

                    // 如果当前消息与上次上传的消息相同，停止添加新消息
                    if (lastUploadedMessage && currentMessageId === lastUploadedMessage) {
                        console.log("发现与上次上传相同的消息，停止添加");
                        foundUploadedMessage = true;
                        break;
                    }

                    messages.unshift(msg);
                    newMessagesCount++;
                }
            }

            // 如果发现已上传的消息，跳出主循环
            if (foundUploadedMessage) {
                console.log("检测到已上传消息，停止滚动");
                break;
            }

            console.log(`本次循环添加了 ${newMessagesCount} 条新消息`);

            // 检查是否需要继续滚动
            if (newMessagesCount === 0) {
                noNewMessagesCount++;
                if (noNewMessagesCount >= 10) {
                    console.log("连续3次未发现新消息，停止滚动");
                    break;
                }
            } else {
                noNewMessagesCount = 0;
            }

            // 滚动到下一页
            let currentHeight = messageList.bounds().height();
            let success = messageList.scrollBackward();

            if (!success || currentHeight === previousHeight) {
                sameHeightCount++;
                if (sameHeightCount >= 10) {
                    console.log("已到达消息列表顶部");
                    break;
                }
            } else {
                sameHeightCount = 0;
            }

            previousHeight = currentHeight;
        }

        console.log("消息读取完成,共读取到", messages.length, "条消息");
        console.log("消息列表:", messages);
        return messages;

    } catch (e) {
        console.error("读取消息失败:", e);
        throw new OperationError(
            ErrorCodes.ELEMENT_NOT_FOUND,
            "读取消息失败: " + e.message
        );
    }
}

// 修改获取已上传消息记录的函数
function getLastUploadMessage(phoneNumber) {
    try {
        let lastMessage = STORAGE.get("last_message_" + phoneNumber);
        return lastMessage ? lastMessage : null;  // 直接返回字符串，不需要JSON.parse
    } catch (e) {
        console.error("读取最后消息记录失败:", e);
        return null;
    }
}

// 相应的保存函数也需要修改
function saveLastUploadedMessage(phoneNumber, message) {
    try {
        let value = `${message.content}_${message.time}`;
        STORAGE.put(
            "last_message_" + phoneNumber,
            value  // 直接存储messageId字符串，不需要JSON.stringify
        );
    } catch (e) {
        console.error("保存最后消息记录失败:", e);
    }
}

function uploadUnreadMessages(phoneNumber, messages) {
    console.log("开始上传未读消息，联系人:", phoneNumber);

    if (!messages || messages.length === 0) {
        console.log("没有新消息需要上传");
        return;
    }

    try {
        console.log(`联系人 ${phoneNumber} 共有 ${messages.length} 条新消息需要上传`);

        // 检查最新消息是否超过30秒
        let latestMessage = getLastUploadMessage(phoneNumber);
        let isMessageExpired = false;
        if (latestMessage) {
            let currentTime = new Date().getTime();
            let messageTime = new Date(latestMessage.time).getTime();
            isMessageExpired = currentTime - messageTime > 30000;
        }
        if (isMessageExpired) {
            console.log("最新消息已超过30秒,删除联系人消息记录");
            STORAGE.remove("last_message_" + phoneNumber);
        } else {
            // 保存最后一条消息记录
            let lastMessage = messages[messages.length - 1];
            console.log("保存最后一条消息记录:", lastMessage);
            saveLastUploadedMessage(phoneNumber, lastMessage);
        }

        // TODO: 实现具体的上传逻辑
        console.log("消息上传完成");
    } catch (e) {
        console.error("上传消息失败:", e);
        throw new OperationError(
            ErrorCodes.UPLOAD_FAILED,
            "上传消息失败: " + e.message
        );
    }
}

function replying() {
    let messages = readReceivedMessages();
    uploadUnreadMessages(phoneNumber, messages);
    sleep(2000);
    setTextSafely(className("android.widget.EditText"), "测试");
    // waitAndClick(desc("Send"), false, "Send");
}


let phoneNumber = "+8619540863735";
openChatWithContact(phoneNumber);
sleep(1000);
replying();









