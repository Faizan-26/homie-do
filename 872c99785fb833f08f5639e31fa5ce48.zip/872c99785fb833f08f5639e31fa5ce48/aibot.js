auto.waitFor();
var permission = require("./permissions.js");
const tools = require("./tools.js");
const utils = require("./utils.js");


var logowidth = 250;
var isSigleClick = false;
var taskScript;
var currentTaskScript = null;
var currentPkgName = "";

// 创建悬浮窗
var floatyWindow = floaty.rawWindow(
    <frame bg="#88000000" w="*" h="auto">
        <TextView
            id="closeAll"
            text="X"
            layout_width="25dp"
            layout_height="25dp"
            textColor="#FFFFFF"
            gravity="center"
            textSize="20sp"
            layout_gravity="right|top"
        />
        <vertical gravity="center">
            <img id="pause" src="@mipmap/pause" w="40dp" h="35dp" />
            <text id="marquee" text="Aviso: A tarefa está em andamento. Clicar aleatoriamente na tela causará falha."
                textSize="15sp"
                textColor="#FFFFFF"
                singleLine="true"
                ellipsize="marquee"
                focusable="true"
                focusableInTouchMode="true"
                marqueeRepeatLimit="marquee_forever"
                layout_gravity="center"
                w="auto"
                h="auto" gravity="center" />
        </vertical>
    </frame>
);

// 确保悬浮窗已创建
if (floatyWindow) {
    console.log("悬浮窗已创建");
} else {
    console.error("悬浮窗创建失败");
}
// 延迟操作悬浮窗
floatyWindow.setSize(device.width / 4, 150);
floatyWindow.marquee.setSelected(true);
floatyWindow.setPosition(-device.width, 0);// 延迟 1 秒

var onceTime = true;
floatyWindow.pause.click(function () {
    try {
        if (!onceTime) {
            return;
        }
        onceTime = false;
        isSigleClick = !isSigleClick;
        if (isSigleClick) {
            device.keepScreenOn(3600 * 1000);
            setTimeout(function () {
                engines.all().forEach(engine => {
                    if (engine != engines.myEngine()) {
                        console.info("Child script stopped.");
                        engine.forceStop();
                    }
                });
                taskScript.interrupt();
                threads.shutDownAll();
                onceTime = true;
            }, 500);
            showRause();
        } else {
            setTimeout(function () {
                startOn(global.taskList);
                onceTime = true;
            }, 500);
            showRuning();
        }

    } catch (error) {
    }
});
var forceExit = false;
var timeoutExit = false;
floatyWindow.closeAll.click(function () {
    dialogs.confirm("Dica", "Tem certeza de fechá-lo?", (confirmed) => {
        if (confirmed) {
            forceExit = true;
            taskScript.interrupt();
            setTimeout(function () {
                console.log("强制结束:拉起任务网");
                currentTaskScript = null;
                engines.all().forEach(engine => {
                    if (engine != engines.myEngine()) {
                        console.info("Child script stopped.");
                        engine.forceStop();
                    }
                });
                exit();
                launch(global.milePkg);
            }, 500);
        }
    });
});

function notifyNativeApp() {
    // 发送广播
    context.sendBroadcast(new Intent("com.bot.AUTOJS_READY"));
    console.log("已通知原生应用");
}

function showRuning() {
    floatyWindow.pause.attr("src", "@mipmap/pause");
    floatyWindow.marquee.attr("text", "Aviso: A tarefa está em andamento. Clicar aleatoriamente na tela causará falha.");
    floatyWindow.pause.invalidate();
    floatyWindow.marquee.invalidate();
}

function showRause() {
    floatyWindow.pause.attr("src", "@mipmap/pay");
    floatyWindow.marquee.attr("text", "Dica: Clique para continuar a tarefa.");
    floatyWindow.pause.invalidate();
    floatyWindow.marquee.invalidate();
}

pkgNameList = [
    { appName: "whatsapp", name: "com.whatsapp", instance: "./WhatsApp.js" },
    // { appName: "whatsapp", name: "com.whatsapp", instance: "./Line.js" },
    // { appName: "tiktok", name: "com.ss.android.ugc.trill", instance: "./TikTok_Brazil.js" },
    { appName: "tiktok", name: "com.zhiliaoapp.musically", instance: "./TikTok_Brazil.js" },
    { appName: "kwai", name: "com.kwai.video", instance: "./kwai.js" },
    { appName: "textra", name: "com.textra", instance: "./Textra.js" },
    { appName: "telegram", name: "org.telegram.messenger", instance: "./Telegram.js" },
    { appName: "line", name: "jp.naver.line.android", instance: "./Line.js" },
    { appName: "facebook", name: "com.facebook.katana", instance: "./facebook.js" },
    { appName: "googleMessage", name: "com.google.android.apps.messaging", instance: "./GoogleMessage.js" },
    { appName: "youtube", name: "com.google.android.youtube", instance: "./YouTube.js" }

];

global.applist = JSON.parse(engines.myEngine().execArgv.apps);
global.taskList = JSON.parse(engines.myEngine().execArgv.list);
global.milePkg = engines.myEngine().execArgv.package_name;

let isCurrentApp = 0;

// app.startActivity("console");

setInterval(function () {
    if (currentTaskScript && currentTaskScript.getEngine().isDestroyed() == false) {
        let foregroundApp = currentPackage();
        const isSystemPackage = systemPackagePrefixes.some(prefix => foregroundApp.startsWith(prefix));
        // console.log(foregroundApp, "-/-", currentPkgName);
        // if (foregroundApp == "android" && currentPkgName) { }
        if (isSystemPackage && currentPkgName) { }
        else if (foregroundApp !== currentPkgName) {
            isCurrentApp++
        } else {
            isCurrentApp = 0;
        }
        if (isCurrentApp > 30) {
            if (!isSigleClick) {
                console.info("被打断");
                engines.all().forEach(engine => {
                    if (engine != engines.myEngine()) {
                        console.info("Child script stopped.");
                        engine.forceStop();
                    }
                });
                taskScript.interrupt();
                threads.shutDownAll();
                isSigleClick = true;
                showRause();
                isCurrentApp = 0;
            }
        }
    }
}, 1000);

getList()

function getList() {
    var appInfoList = global.taskList;
    console.info("getapplist--->", global.applist);
    console.info("getList--->", appInfoList);
    if (appInfoList.length < 1) {
        dialogs.confirm("Dica", "A tarefa de hoje foi concluída", (confirmed) => {
            if (confirmed) {
            } else {
            }
            // exit();
        });
        return;
    }
    for (var j = 0; j < appInfoList.length; j++) {
        var t = global.applist.find(sub => sub.app_id == appInfoList[j].app_id);
        if (t) {
            appInfoList[j].pkgName = t.package_name;
        }
    }
    for (let i = 0; i <= appInfoList.length - 1; i++) {
        let target = pkgNameList.find(item => item.name === appInfoList[i].pkgName);
        if (target) {
            appInfoList[i].instance = target.instance;
        }
    }
    console.info("can be exe app list ------", appInfoList);
    ui.run(() => {
        if (permission.checkPermissions()) {
            let isOk = StartAll();
            console.log("=====StartAll is ok", isOk);
        }
    })
}


function StartAll() {
    tools.initStatus();
    if (!permission.checkPermissions()) return false;
    floatyWindow.setPosition(0, 0);
    console.info("task list is :", JSON.stringify(global.taskList, null, 2));
    notifyNativeApp()
    device.keepScreenOn(3600 * 1000);
    for (var i = 0; i < global.taskList.length; i++) {
        var item = global.taskList[i];
        if (item.task_end_time) {
            stopTime = item.task_end_time;
            console.log("stopTime = ", stopTime);
        }
    }
    if (stopTime) {
        setTimeout(function () {
            console.log("已到任务强制终止时间");
            timeoutExit = true;
            engines.all().forEach(engine => {
                if (engine != engines.myEngine()) {
                    engine.forceStop();
                }
            });
            if (taskScript) {
                taskScript.interrupt();
            }
            threads.shutDownAll();
            console.log("已到任务强制终止时间-重启流程，强制提交任务");
            startOn(global.taskList);
        }, stopTime * 1000);
    }
    //避免stopTime设置错误
    if (timeoutExit == false) {
        startOn(global.taskList);
    }
    return true;
};

function startOn(taskList) {
    try {
        taskScript = threads.start(function () {
            try {
                executeTasks(taskList); // 执行任务
            } catch (error) {
                currentTaskScript = null;
                console.error("task exe catch on :", error);
            }
        });
        taskScript.waitFor();
        console.log("线程已启动！");
    } catch (error) {
        device.cancelKeepingAwake();
        console.error("start on :", error);
        currentTaskScript = null;
    }
}

var stopTime = null;

function executeTasks(taskList) {
    // 用于存储分组结果的 Map
    var groupedData = {};
    // 遍历原始数据
    for (var i = 0; i < taskList.length; i++) {
        var item = taskList[i];
        var appId = item.app_id;
        // 如果 app_id 不存在于 Map 中，则创建一个新的数组
        if (!groupedData[appId]) {
            groupedData[appId] = [];
        }
        // 将当前对象添加到对应的 app_id 分组中
        groupedData[appId].push(item);
    }
    // 执行任务逻辑
    createTaskScript(taskList, groupedData);
    // let endStatus = tools.getStatus();
    // console.log("endStatus = ", endStatus);
    var result = [];
    for (var i = 0; i < taskList.length; i++) {
        let pkgName = taskList[i].pkgName;
        // if (endStatus.includes(pkgName)) {
        // console.log(`任务 ${pkgName} 已经完成，跳过`);
        result.push(pkgName);
        // }
    }
    // 检查任务是否全部完成
    if (result.length != taskList.length) {
        console.log("任务未全部完成，重新执行");
        if (!forceExit) {
            executeTasks(taskList); // 递归调用
        }
    } else {
        var subIdList = [];
        for (var i = 0; i < taskList.length; i++) {
            var item = taskList[i];
            subIdList.push(item.task_sub_id);
        }
        var subIdString = subIdList.join(',');

        device.cancelKeepingAwake();

        var intent = new Intent("com.bot.AUTOJS_DONE");
        intent.putExtra("subIdList", subIdString);
        context.sendBroadcast(intent);
        console.log("全部结束");
        currentTaskScript = null;
        launch(global.milePkg);
        console.log("全部结束:拉起任务网", global.milePkg);
        engines.stopAll();
        exit();
    }
}

function createTaskScript(taskList, groupedData) {
    for (var i = 0; i < taskList.length; i++) {
        if (forceExit) {
            return;
        }
        console.info("exe task name ::", taskList[i].name, taskList[i].pkgName);
        if (taskList[i].instance == null || taskList[i].instance == "") {
            continue; // 跳过无效任务
        }

        // let endStatus = tools.getStatus();
        // if (endStatus.includes(taskList[i].pkgName)) {
        //     console.log(`任务 ${taskList[i].name} 已经完成，跳过`);
        //     continue;
        // }

        currentTaskScript = utils.getTask(groupedData[taskList[i].app_id], timeoutExit, taskList[i].instance);
        console.log("index => " + i);
        console.log("app list goes to =>" + taskList);
        currentPkgName = taskList[i].pkgName;

        // 避免忙等待
        while (true) {
            if (currentTaskScript) {
                if (currentTaskScript.getEngine().isDestroyed() == false) {
                    sleep(1000);
                } else {
                    console.log("终止");
                    break;
                }
            } else {
                console.log("终止");
                break;
            }
        }
        currentTaskScript = null;
    }
}

const systemPackagePrefixes = [
    "com.android",
    "com.google.android",
    "com.miui",
    "com.qualcomm",
    "android",
    "com.sohu",
    "com.touchtype.swiftkey",
    "ssme.ttl.task",
    "ssme.ttl.task.brazil",
    "ssme.ttl.task.mexco",
    "ssme.ttl.task.singapore"
];

events.broadcast.on("move_center", (text) => {
    floatyWindow.setPosition(device.width / 2, 0);
});

events.broadcast.on("move_zero", (text) => {
    floatyWindow.setPosition(0, 0);
});