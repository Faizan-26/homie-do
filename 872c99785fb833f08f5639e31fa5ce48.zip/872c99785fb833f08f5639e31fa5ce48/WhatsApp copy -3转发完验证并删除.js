var tools = require("./tools.js");
var utils = require("./utils.js");
var pkgName = "com.whatsapp";
var config = {};
var tmpTaskList = [];
var isContinueFail = 0;
var instance = {};
var isOver = false;
var storeKey = "whatsapp";

let locale = java.util.Locale.getDefault();
let language = locale.getLanguage();
console.log("语言", language);
let showText = "";
if (language == "pt") {
   showText = "Preparação da Missão...";
} else if (language == "es") {
   showText = "Preparación de la misión...";
}
// // 定义多语言文本映射
// const i18nText = {
//    Chats: ["Chats", "Conversas"], // 墨西哥 / 巴西
//    Selft: ["(Tú)",],
//    Chatear: ["Chatear",],
//    SuccessTag: ["Enviado", "Leído", "Entregado"],
// }

// 通用函数，查找匹配任一语言
// function findTextEnd(keys, timeout) {
//    let tmpNode = null;
//    keys.forEach((item, index) => {
//       const node = textEndsWith(item).findOne(timeout);
//       if (node) {
//          tmpNode = node;
//       }
//    })
//    return tmpNode;
// }
// function findTextStart(keys, timeout) {
//    let tmpNode = null;
//    keys.forEach((item, index) => {
//       const node = textStartsWith(item).findOne(timeout);
//       if (node) {
//          tmpNode = node;
//       }
//    })
//    return tmpNode;
// }

// function findDescStart(keys, timeout) {
//    let tmpNode = null;
//    keys.forEach((item, index) => {
//       const node = descStartsWith(item).findOne(timeout);
//       if (node) {
//          tmpNode = node;
//       }
//    })
//    return tmpNode;
// }

var fadeData = ` [{
            "name": "TGAI私信 ",
            "app_id": 10,
            "config":
            {
                "has_paid": 1,
                "reply_timeout": 1,
                "single_interval":
                    [
                        2,
                        5
                    ],
                "account_interval":
                    [
                        1,
                        2
                    ]
            },
            "task_id": 15,
            "has_paid": 1,
            "task_data":
                [
                    {
                        "text":
                            [
                                "嘿~ 刚刷到你在推特，聊聊？"
                            ],
                        "account": "+55 11 94603-3714",
                        "detail_id": 1826
                    }
                ],
            "task_type": 8,
            "task_length": 5,
            "task_sub_id": 1316,
            "times_stop_begin": 0,
            "continuous_fail_stop": 0
        }]`;

var fakeContent = ["Olá~ Acabei de ver você no Twitter, quer bater um papo?",
   "Ouvi dizer que esse lugar é divertido. Por que você não dá uma olhada?",
   "Há muitas comidas deliciosas aqui~",
   "Pode",
   "Sem chance! ! Você não ouviu falar dessa animação? ! ! !",
   "Sem problemas",
   "Todas as manhãs quando acordo, sou grato pela sua companhia 🌅✨.",
   "Bom dia, vamos saudar o novo dia juntos com belas expectativas em nossos corações 🌞🌈.",
   "mas...",
   "Bom dia! Espero que tudo corra como você deseja hoje e que tudo seja repleto de icidade e alegria! 🥰🌻.",
   "Desejo a você um dia cheio de energia positiva e que comece o novo dia com total alidade 💪😊.",
   "Bom dia! Você é a pessoa mais especial do meu coração, desejo-lhe um bom dia! 💖✨.",
   "bom",
   "Ao amanhecer, desejo a você um dia feliz e alegre. 🌟🌱.",
   "Bom dia! Que seu dia seja repleto de bênçãos e alegrias, e que você aproveite cada momento dele! 🎉😄",
   "O sol da manhã também é minha saudação para você, que você tenha um dia maravilhoso ☀️💕.",
   "Bom dia! Cada manhã é um novo milagre. Vamos saudar o novo dia com confiança! 🌈🌼.",
   " Acorde cedo, que você sorria todos os dias e comece o dia com gratidão e carinho! 😊🌸.",
   "Ok, eu entendo",
   "Pode",
   "mas...",
   "Sem problemas",
   "Mas!",
   `${random(1, 3000)}`,
];

events.on("say", function (param) {
   try {
      instance.handle(param.list);
   } catch (error) {
      console.error(error);
   }
});

var runing = setInterval(() => {
   if (isOver) {
      clearInterval(runing);
   }
}, 1000);

instance.handle = function (taskList) {
   try {
      // var taskFinishCount = 0;
      tmpTaskList = tools.storage.get(storeKey, []);
      console.info("获取本地缓存", tmpTaskList);
      console.info("传入数据 =>\n", taskList);
      // 提交旧数据/ 赋值新任务
      if (tmpTaskList.length > 0) {
         tmpTaskList.forEach((item, index) => {
            try {
               if (item.task_sub_id != taskList[index].task_sub_id) {
                  console.log("提交旧任务：", item.task_sub_id, taskList[index].task_sub_id);
                  submitRes(index);
                  tmpTaskList[index] = taskList[index];
               }
            } catch (error) {

            }
         })
      } else {
         tmpTaskList = taskList;
      }
      tools.storage.put(storeKey, tmpTaskList);

      // 执行任务
      tmpTaskList.forEach((item, i) => {
         config = item.config;
         switch (tmpTaskList[i].task_type) {
            case 1:
               // 执行所有人
               exeAll(item, i);
               // 提交前，检查一边失败的，提高成功率
               recheckFailed(item, i);
               break;
            case 9:
               forwardMsg(item, i);
               console.log("验证并删除");
               checkSuccess(item, i);
               // 删除自己
               deletSelfConntent();
               break;

         }

         // 无操作不提交
         let isOpt = false;
         for (var index = 0; index < tmpTaskList[i].task_data.length; index++) {
            if (tmpTaskList[i].task_data[index].status) {
               isOpt = true;
               break;
            }
         }
         console.log("提交任务", i);
         if (isOpt) {
            submitRes(i);
         }
      })
      isOver = true;
   } catch (error) {
      console.error("运行中报错，保存数据::::", error);
      isOver = true;
      tools.storage.put(storeKey, tmpTaskList);
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }

      // submitRes(-1);
      // engines.myEngine().forceStop();
   }
}

function checkSuccess(item, i) {
   launchApp();
   // 检查封号
   let notAccountNode = textMatches(/(Esta conta não.*|Esta conta não.*)/).findOne(1000);
   if (notAccountNode) {
      for (var k = 0; k < item.task_data.length; k++) {
         if (tmpTaskList[i].task_data[k].sended) {
            tmpTaskList[i].task_data[k].result_text = "封号已发送的成功";
            tmpTaskList[i].task_data[k].status = 1;
         }
      }
      return
   }

   let msgLink = "";
   item.task_data.forEach((data, j) => {
      if (msgLink == "") {
         msgLink = data.text;
      }
   })

   let userListNode = descMatches(/(Conversas.*|Chats.*|चैट.*|แชท.*|.*‏چیٹس.*)/).findOne(5000);
   if (!userListNode) {
      return -4;
   }

   if (!userListNode.isSelected()) {
      userListNode.select();
      sleep(2000);
   }

   for (var j = 0; j < item.task_data.length; j++) {
      // 检查封号
      let notAccountNode = textMatches(/(Esta conta não.*|Esta conta não.*)/).findOne(1000);
      if (notAccountNode) {
         for (var k = 0; k < item.task_data.length; k++) {
            if (tmpTaskList[i].task_data[k].sended) {
               tmpTaskList[i].task_data[k].result_text = "封号已发送的成功";
               tmpTaskList[i].task_data[k].status = 1;
            }
         }
         return
      }

      if (tmpTaskList[i].task_data[j].status && tmpTaskList[i].task_data[j].status == 1) {
         continue;
      }

      // 检验并删除
      if (tmpTaskList[i].task_data[j].sended) {
         let searchNode = id("com.whatsapp:id/my_search_bar").findOne(5000);
         if (searchNode && searchNode.click()) {
            sleep(1000);
            let res = deleteMsgForCount(tmpTaskList[i].task_data[j], i, j, msgLink);
            if (res < 0) {
               tmpTaskList[i].task_data[j].result_text = "未检验到成功，执行步骤" + res;
               tmpTaskList[i].task_data[j].status = 2;
            }
            back();
         }
      }
   }
}

function checkRes(res, i, j) {
   if (res == -4) {
      console.log(`(s=${res}) 控件未找到`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 6;
      tmpTaskList[i].task_data[j].result_text = "控件未找到";
   }
   if (res == 100) {
      console.log(`(s=${res}) 成功`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 1;
      tmpTaskList[i].task_data[j].result_text = "成功";
   }
   if (res == -10) {
      console.log(`(s=${res}) 账号被禁`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "账号被禁";
      tmpTaskList[i].task_data[j].status = 4;
      isOver = true;
   }
   if (res == -11) {
      console.log(`(s=${res})未登录Ws`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 5;
      tmpTaskList[i].task_data[j].result_text = "未登录WS";
      isOver = true;
   }
   if (res == -20) {
      console.log(`(s=${res}) 目标账号不存在`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].result_text = "目标账号不存在";
      tmpTaskList[i].task_data[j].status = 3;
   }
   if (tmpTaskList[i].task_data[j].taskFinish) { } else {
      console.log(`(s=${res}) 失败`);
      tmpTaskList[i].task_data[j].taskFinish = true;
      tmpTaskList[i].task_data[j].status = 2;
      tmpTaskList[i].task_data[j].result_text = "失败";
   }
   tools.storage.put(storeKey, tmpTaskList);
}

function recheckFailed(item, i) {
   item.task_data.forEach((data, j) => {
      console.log("检查失败", tmpTaskList[i].task_data[j].status, tmpTaskList[i].task_data[j].result_text);
      if (tmpTaskList[i].task_data[j].status == 2) {
         let res = exeTask(data, i, j);
         checkRes(res, i, j);
      }
   })
}

function exeAll(item, i) {
   item.task_data.forEach((data, j) => {
      console.log("任务-", i, j, "数据", tmpTaskList[i].task_data[j])
      if (tmpTaskList[i].task_data[j].taskFinish) { } else {
         let res = exeTask(data, i, j);
         console.log("结果：", res);
         if (res == -4 || res == -5) {
            res = exeTask(data, i, j);
         }
         checkRes(res, i, j);
      }
      console.log("执行完一个", i, j);
   })
}

// // 选择发送列表并删除
// function selectAllSendContact() {
//    try {


//       let gridView = id("acom.whatsapp:id/result_list").findOne(3000);
//       if (gridView) {
//          console.log("列表元素", gridView.children().length);
//          for (let child of gridView.children()) {
//             let tmpChildNode = child.findOne(id("com.whatsapp:id/conversations_row_contact_name"))
//             if (tmpChildNode) {
//                child.longClick();
//                let tmpStr = ["(Tú)", "(você)", "(Ikaw)", "(You)", "(आप)", "(คุณ)", "(آپ)"]
//                if (tmpStr.some(keyword => tmpChildNode.text().includes(keyword))) {
//                   let deleteNode = id("com.whatsapp:id/menuitem_conversations_delete").findOne(5000);
//                   if (deleteNode && deleteNode.click()) {
//                      sleep(500);
//                   }
//                   deleteNode = descMatches(/(Apagar conversas|abc)/).findOne(5000);
//                   if (deleteNode && deleteNode.click()) {
//                      sleep(500);
//                   }
//                   return
//                }
//             }
//          }
//       }
//       let deleteNode = id("com.whatsapp:id/menuitem_conversations_delete").findOne(5000);
//       if (deleteNode && deleteNode.click()) {
//          sleep(500);
//       }
//       deleteNode = descMatches(/(Apagar conversas|abc)/).findOne(5000);
//       if (deleteNode && deleteNode.click()) {
//          sleep(500);
//       }
//       //  滑动删除
//       // let posX = device.width / 2;
//       let posY = device.height / 3;
//       swipe(posX, posY, posX, posY + device.height / 2, 500);
//       sleep(1000);
//       selectAllSendContact();

//    } catch (error) {
//       console.error("运行中报错，保存数据::::", error);
//       isOver = true;
//       tools.storage.put("whatsapp", tmpTaskList);
//       if (error.toString().includes("ScriptInterruptedException")) {
//          isOver = true;
//          throw error;
//       }

//    }
// }
// 删除自己
function deletSelfConntent() {
   try {
      launchApp();
      sleep(500);
      let userListNode = descMatches(/(Conversas.*|Chats.*|चैट.*|แชท.*|.*‏چیٹس.*)/).findOne(5000);
      if (!userListNode) {
         return
      }

      if (!userListNode.isSelected()) {
         userListNode.select();
         sleep(2000);
      }
      let listNode = id("android:id/list").findOne(5000);
      if (listNode) {
         listNode.children().forEach((child) => {
            {
               let tmpChildNode = child.findOne(id("com.whatsapp:id/conversations_row_contact_name"))
               if (tmpChildNode) {
                  let tmpStr = ["(Tú)", "(você)", "(Ikaw)", "(You)", "(आप)", "(คุณ)", "(آپ)"]
                  if (tmpStr.some(keyword => tmpChildNode.text().includes(keyword))) {
                     child.longClick();
                     sleep(500)
                     let deleteNode = id("com.whatsapp:id/menuitem_conversations_delete").findOne(5000);
                     if (deleteNode && deleteNode.click()) {
                        sleep(500);
                     }
                     deleteNode = descMatches(/(Apagar conversa|Delete chat|I-delete ang chat|चैट डिलीट करें|Eliminar chat|ลบแชท|‏چیٹ حذف کریں)/).findOne(5000);
                     if (deleteNode) {
                        deleteNode.click();
                        sleep(500);
                     }
                     return
                  }
               }
            }
         })
      }
   } catch (error) {

   }
}
// 验证并删除
function deleteMsgForCount(data, i, j, msgLink) {
   try {
      let inputNode = className("android.widget.EditText").findOne(5000);
      if (!inputNode) {
         return -1;
      }
      inputNode.setText(data.account);
      sleep(500);
      let gridView = id("com.whatsapp:id/result_list").findOne(5000);
      if (!gridView) {
         return -2;
      }
      for (var index = 0; index < gridView.children().length; index++) {
         let currentChild = gridView.children().get(index);
         let okNode = currentChild.findOne(textMatches(/(Conversas|Chats|चैट|แชท|‏چیٹس)/));
         if (!okNode) {
            continue;
         }
         let secondChild = gridView.children().get(index + 1);
         if (!secondChild || !secondChild.click()) {
            return -4;
         }
         sleep(1000);
         console.log("查找并删除");
         // 单击删除
         let tmpNode = id("android:id/list").findOne(5000);
         if (!tmpNode) {
            return -5;
         }
         console.log("查找并删除0000", tmpNode.children().length, msgLink);
         for (var index1 = 0; index1 < tmpNode.children().length; index1++) {
            let currentChild = tmpNode.children().get(index1);
            let childNode = currentChild.findOne(text(msgLink));
            let childNodeStatus = currentChild.findOne(id("com.whatsapp:id/status"));
            if (!childNode || !childNodeStatus) {
               continue;
            }
            console.log("查找并删除1111", data.text);
            let descStutas = childNodeStatus.desc();
            let successTag = ["Enviado", "Leído", "Entregado", "Enviada", "Entregue", "Lida", "Naihatid", "Naipadala", "Nabasa", "Read", "Sent", "Delivered",
               "ส่งแล้ว", "ส่งถึงแล้ว", "อ่าน", "प्रेषित", "पहुँच गया", "पढ़ लिया", "‏بھیجا ہوا", "‏ڈیلیور شدہ", "‏پڑھ لیا"];

            if (!successTag.includes(descStutas)) {
               return -6;
            }

            currentChild.longClick();
            console.log("查找并删除22222", data.text);
            sleep(500);
            let deleteNode = descMatches(/(删除|Apagar|Delete|I-delete|डिलीट करें|Eliminar|ลบ|‏حذف کریں)/).findOne(5000);
            if (!deleteNode || !deleteNode.click()) {
               return -7;
            }

            sleep(500);
            deleteNode = textMatches(/(为我删除|Apagar para mim|Delete for me|I-delete sa akin|मेरे लिए डिलीट करें|Eliminar para mí|ลบสำหรับฉัน|‏میرے لیے حذف کریں)/).findOne(5000);
            if (!deleteNode || !deleteNode.click()) {
               return -8;
            }

            console.log("查找并删除3333", data.text);
            sleep(500);
            tmpTaskList[i].task_data[j].result_text = "检验并删除成功";
            tmpTaskList[i].task_data[j].status = 1;
            tools.storage.put(storeKey, tmpTaskList);
            return 100;
         }
      }
      return -3;
   } catch (error) {
      console.error("运行中报错，保存数据::::", error);
      isOver = true;
      tools.storage.put(storeKey, tmpTaskList);
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
      return -100;
   }
}
// 删除聊天对话
function deleteTaskContent(data, i, j) {
   try {
      let inputNode = className("android.widget.EditText").findOne(5000);
      if (inputNode) {
         inputNode.setText(data.account);
         sleep(500);
         let gridView = id("com.whatsapp:id/result_list").findOne(5000);
         if (gridView) {
            gridView.children().forEach((child, index) => {
               let okNode = child.findOne(textMatches(/(Conversas|Chats|चैट|แชท|‏چیٹس)/));
               if (okNode) {
                  gridView.children().get(1);
                  let secondChild = gridView.children().get(index + 1);
                  if (secondChild && secondChild.click()) {
                     // 单击删除
                     let tmpNode = id("android:id/list").findOne(5000);
                     if (tmpNode) {
                        tmpNode.children().forEach((child, index) => {
                           let childNode = child.findOne(text(data.text));
                           let childNodeStatus = child.findOne(id("com.whatsapp:id/status"));
                           if (childNode && childNodeStatus) {
                              let descStutas = childNodeStatus.desc();
                              let successTag = ["Enviado", "Leído", "Entregado", "Enviada", "Entregue", "Lida", "Naihatid", "Naipadala", "Nabasa", "Read", "Sent", "Delivered",
                                 "ส่งแล้ว", "ส่งถึงแล้ว", "อ่าน", "प्रेषित", "पहुँच गया", "पढ़ लिया", "‏بھیجا ہوا", "‏ڈیلیور شدہ", "‏پڑھ لیا"];
                              if (successTag.includes(descStutas)) {
                                 child.longClick();
                                 sleep(500);
                                 let deleteNode = descMatches(/(删除|Apagar|Delete|I-delete|डिलीट करें|Eliminar|ลบ|‏حذف کریں)/).findOne(5000);
                                 if (deleteNode && deleteNode.click()) {
                                    // click("Apagar conversa");
                                    deleteNode = textMatches(/(为我删除|Apagar para mim|Delete for me|I-delete sa akin|मेरे लिए डिलीट करें|Eliminar para mí|ลบสำหรับฉัน|‏میرے لیے حذف کریں)/).findOne(5000);
                                    if (deleteNode && deleteNode.click()) {
                                       tmpTaskList[i].task_data[j].status = 1;

                                    }

                                 }
                                 return 100;
                              }
                           }
                        })
                     }
                     back();


                     // 长按删除
                     // secondChild.longClick();
                     // let deleteNode = textMatches(/(Apagar conversa|Delete chat|I-delete ang chat|चैट डिलीट करें|Eliminar chat|ลบแชท|‏چیٹ حذف کریں)/).findOne(5000);
                     // if (deleteNode) {
                     //    click("Apagar conversa");
                     //    click("Delete chat");
                     //    click("I-delete ang chat");
                     //    click("चैट डिलीट करें");
                     //    click("Eliminar chat");
                     //    click("ลบแชท");
                     //    click("منسوخ کریں")
                     //    deleteNode = descMatches(/(Apagar conversa|Delete chat|I-delete ang chat|चैट डिलीट करें|Eliminar chat|ลบแชท|‏چیٹ حذف کریں)/).findOne(5000);
                     //    if (deleteNode) {
                     //       // click("Apagar conversa");
                     //       deleteNode.click();
                     //       sleep(500);
                     //    }
                     // }
                  }
               }
            })
         }
      }
   } catch (error) {
      console.error("运行中报错，保存数据::::", error);
      isOver = true;
      tools.storage.put(storeKey, tmpTaskList);
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }

   }
}


function randomNum(minNum, maxNum) {
   return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}

function submitRes(i) {
   let res = {};
   res.task_id = tmpTaskList[i].task_id;
   res.task_sub_id = tmpTaskList[i].task_sub_id;
   res.ex_account = tmpTaskList[i].ex_account;
   res.has_continuous_fail = isContinueFail;
   res.task_data = JSON.stringify(tmpTaskList[i].task_data);
   console.error("提交数据", res);
   let result = utils.submitTask(res);
   console.log("提交结果", result);
   tools.storage.remove(storeKey);
   tmpTaskList = [];
}

function submitBlocked(i) {
   let res = {};
   res.app_id = tmpTaskList[i].app_id;

   utils.submitBlocked(res, function () {
      tools.addStatus(tmpTaskList[i].pkgName);
      console.log("账号被封禁提交成功");
   });
}

// function deleteUserList() {
//    // try {
//    back();
//    back();
//    sleep(500);
//    let selfNode = textEndsWith(")").findOne(5000);
//    if (selfNode) {
//       longClick(")");
//       let selfNodeRect = selfNode.bounds();
//       let deleteTargetNode = id("com.whatsapp:id/conversations_row_contact_name").find();
//       deleteTargetNode.each(function (child) {
//          let childRect = child.bounds();
//          if (childRect.centerY() < selfNodeRect.centerY()) {
//             console.log(child.text());
//             click(child.text());
//             sleep(500);
//          }
//       });

//       let pinNode = id("com.whatsapp:id/menuitem_conversations_pin").findOne(5000);
//       if (pinNode) {
//          let deleteRect = pinNode.bounds();
//          click(deleteRect.centerX() + deleteRect.width(), deleteRect.centerY());
//          sleep(1000);
//          let deleteNode = descStartsWith("Apagar").findOne(5000);
//          if (deleteNode) {
//             deleteNode.click();
//             console.log("0=====  delete success");
//             return;
//          } else {
//             console.warn("3=====  delete step  3");
//          }
//       } else {
//          console.warn("2=====  delete step  2");
//       }
//    } else {
//       console.warn("1=====  delete step  1");
//    }
//    // } catch (error) {
//    //    console.warn("-1=====  delete  exp", error);
//    // }
// }


function sendMsg(data, i, j) {
   try {
      console.log("sendMsg:-1", data, data.text);
      let isScuccess = false;
      if (data.text && data.text.length > 0) {
         let inputNode = id("com.whatsapp:id/entry").findOne(5000);
         if (!inputNode) {
            return -4;
         }
         console.log("sendMsg:-2");
         data.text.forEach((item, index) => {
            console.log("sendMsg:", tmpTaskList[i].task_data[j].sendIndex, item, index);
            if (tmpTaskList[i].task_data[j].sendIndex && index < tmpTaskList[i].task_data[j].sendIndex) { } else {
               inputNode.setText(item);
               sleep(500);
               var sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (sendNode && sendNode.click()) {
                  sleep(500);
                  tmpTaskList[i].task_data[j].sendIndex = index + 1;
                  tools.storage.put(storeKey, tmpTaskList);
               }
               let randTime = randomNum(config.single_interval[0], config.single_interval[1]);
               sleep(randTime * 1000);
            }
         })
         console.log("sendMsg:-3", tmpTaskList[i].task_data[j].sendIndex);
         sleep(config.send_timeout * 1000);
         if (tmpTaskList[i].task_data[j].sendIndex) {
            let isSuccessNode = id("com.whatsapp:id/status").find();
            console.log("检查节点：111111");
            let checkNodes = isSuccessNode.slice((tmpTaskList[i].task_data[j].sendIndex + 1) * -1);
            console.log("检查节点：222222");
            console.log("检查节点：", checkNodes);

            checkNodes.forEach(function (child) {
               let descStutas = child.desc();
               console.log("状态", descStutas, data.account);
               // ‏بھیجا ہوا
               let successTag = ["Enviado", "Leído", "Entregado", "Enviada", "Entregue", "Lida", "Naihatid", "Naipadala", "Nabasa", "Read", "Sent", "Delivered",
                  "ส่งแล้ว", "ส่งถึงแล้ว", "อ่าน", "प्रेषित", "पहुँच गया", "पढ़ लिया", "‏بھیجا ہوا", "‏ڈیلیور شدہ", "‏پڑھ لیا"];
               if (successTag.includes(descStutas)) {
                  // tmpTaskList[i].task_data[j].taskFinish = true;
                  // tools.storage.put("whatsapp", tmpTaskList);
                  console.log("sendMsg:", 3);
                  isScuccess = true;
                  return;
               }
            });
         }
      }
      if (data.video && data.video.length > 0) {
         data.video.forEach((item, index) => {
            if (tmpTaskList[i].task_data[j].sendIndexVideo && index <= tmpTaskList[i].task_data[j].sendIndexVideo) { } else {
               let downFileName = tools.downloadFiles(item);
               if (downFileName == "") {
                  videoOkNum = -1;
                  console.log("1=====  send msg  download video failed");
                  return;
               }

               var attachNode = id("com.whatsapp:id/input_attach_button").findOne(5000);
               if (!attachNode) {
                  return;
               }
               attachNode.click();
               sleep(500);

               var medioNode = id("com.whatsapp:id/pickfiletype_gallery_holder").findOne(5000);
               if (!medioNode) {
                  return;
               }
               medioNode.click();
               sleep(500);

               var targeVidowtNode = idContains("com.whatsapp:string/(name removed)").findOne(5000);
               if (!targeVidowtNode) {
                  return;
               }
               targeVidowtNode.click();
               sleep(500);

               var sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (!sendNode) {
                  return;
               }
               sendNode.click();
               sleep(500);
               tmpTaskList[i].task_data[j].sendIndexVideo = index;

               let randTime = randomNum(config.single_interval[0], config.single_interval[1])
               sleep(randTime * 1000);
            }
         })
      }
      if (data.image) {
         if (data.image.length > 0) {
            data.image.forEach(() => {

            })
         }
      }
      if (isScuccess) {
         return 100;
      }
      return -5;
   } catch (error) {
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
   }
}

function reGetTarget(data, i, j, maxNum) {
   back();
   if (maxNum < 1) return -20;

   var result = utils.redistributionWs(tmpTaskList[i].task_sub_id, data.detail_id);
   if (result == -100) {
      console.log('重新分配账号接口');
      return -20;
   }
   if (result == -2) {
      console.log('重试3次后重新分配账号仍然失败');
      return -20;
   }
   data.account = result;
   let inputNode = className("android.widget.EditText").findOne(5000);
   if (!inputNode) {
      return -4;
   }
   inputNode.setText(data.account);
   sleep(1000);

   console.log(5);
   let sendNode = id("com.whatsapp:id/send").findOne(5000);
   if (sendNode == null) {
      sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
   }
   if (!sendNode) {
      return -4;
   }
   sendNode.click();
   sleep(500);

   console.log(6);
   let targetNode = desc(data.account).className("android.view.View").findOne(5000);
   if (!targetNode) {
      return -4;
   }
   targetNode.click();
   sleep(5000);

   console.log(7);
   // let targetCallNode = (/^(Conversar|Chatear)/).clickable(true).findOne(25000);
   // let tmpTargetList = ["Conversar", "Chatear"];
   // let targetCallNode = findTextStart(tmpTargetList, 7000);
   let targetCallNode = textMatches(/(Conversar.*|Chatear.*|Makipag-chat sa.*|Chat with.*|.*के साथ चैट करें|แชทกับ.*|.*کے ساتھ چیٹ کریں)/).clickable(true).findOne(20000);
   if (!targetCallNode) {
      console.log("目标号码不存在", data.account);
      // let noWsNode = textStartsWith("Ligar para").findOne(5000);
      // if (noWsNode) {
      //    console.log("目标号码不存在", data.account);
      //    // return -20;
      //    return reGetTarget(data, i, j, maxNum - 1);
      // }
      return reGetTarget(data, i, j, maxNum - 1);
   }
   targetCallNode.click();
   sleep(500);

   let tmpCheckNode = id("com.whatsapp:id/ephemeral_nux_ok").findOne(2000);
   if (tmpCheckNode) {
      tmpCheckNode.click();
   }

   console.log(8);
   return sendMsg(data, i, j);
}

function getNameBeforeLangTag(text, langTags) {
   for (let tag of langTags) {
      const idx = text.indexOf(tag);
      const index1 = text.indexOf(" (آپ)");
      if (index1 !== -1) {
         return text.substring(0, index1).trim();
      }
      if (idx !== -1) {
         return text.substring(0, idx).trim();
      }
   }
   // 
   return text;
}
function getNameAfterLangTag(text, langTags) {
   for (let tag of langTags) {
      const idx = text.indexOf(tag);
      if (idx !== -1) {
         return text.substring(idx).trim();
      }
   }
   return text;
}
//  exe task
function exeTask(data, i, j) {
   console.log("打开执行");
   launchApp();
   sleep(random(5000, 7000));
   while (true) {
      console.log(1);
      // ‏چیٹس, ۱ نئی اطلاع
      let userListNode = descMatches(/(Conversas.*|Chats.*|चैट.*|แชท.*|.*‏چیٹس.*)/).findOne(1000);
      if (!userListNode) {
         // let noAccountList = ["Esta conta não"]
         // let notAccountNode = findTextStart(noAccountList, 1000);
         let notAccountNode = textMatches(/(Esta conta não.*|Esta conta não.*)/).findOne(1000);
         if (notAccountNode) {
            console.info("账号被封");
            return -10;
         }
         console.log("第一步没找到111111");
         let notLoginNode = textMatches(/(CONCORDAR E CONTINUAR|ACEPTAR Y CONTINUAR)/).findOne(2000);
         if (notLoginNode) {
            console.info("未登录");
            return -11;
         }
         return -4;
      }
      if (!userListNode.isSelected()) {
         userListNode.select();
         sleep(3000);
      }

      console.log(2);
      let addTagNode = id("com.whatsapp:id/fab").findOne(10000);
      if (!addTagNode) {
         addTagNode = id("com.whatsapp:id/fabText").findOne(5000);
      }
      if (!addTagNode) {
         return -4;
      }
      if (addTagNode.click()) {
         console.log("点击+好友");
      }
      sleep(2000);

      console.log(3);
      // let tmpSelfList = ["(você)", "(Tú)"];
      // let selfNode = findTextEnd(tmpSelfList, 2000); ‏‪Jinggang3‬‏ (آپ)
      let selfNode = textMatches(/(.*\(você\)|.*\(Tú\)|.*\(Ikaw\)|.*\(You\)|.*\(आप\)|.*\(คุณ\)|.*\(آپ\))/).findOne(5000);
      if (!selfNode) {
         return -4;
      }
      let selfName = selfNode.text();
      console.log("执行账户：", selfName);
      tmpTaskList[i].ex_account = getNameBeforeLangTag(selfName, [" (Tú)", " (você)", " (Ikaw)", " (You)", " (आप)", " (คุณ)", " (آپ)"]);

      click("(Tú)");
      click("(você)");
      click("(Ikaw)");
      click("(You)");
      click("(आप)");
      click("(คุณ)");
      click("(آپ)");
      sleep(1000);

      console.log(4);
      console.log(4, data.account);
      let inputNode = className("android.widget.EditText").findOne(5000);
      if (!inputNode) {
         return -4;
      }
      let targetNode = desc(data.account).className("android.view.View").findOne(5000);
      if (!targetNode) {
         inputNode.setText(data.account);
         sleep(1000);

         console.log(5);
         let sendNode = id("com.whatsapp:id/send").findOne(5000);
         if (sendNode == null) {
            sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
         }
         if (!sendNode) {
            return -4;
         }
         sendNode.click();
         sleep(500);
      }

      console.log(6);
      targetNode = desc(data.account).className("android.view.View").findOne(5000);
      if (!targetNode) {
         return -4;
      }
      targetNode.click();
      sleep(5000);

      console.log(7);
      // let tmpTargetList = ["Conversar", "Chatear"];
      // let targetCallNode = findTextStart(tmpTargetList, 7000); ‏‏‪+55 11 98551-0381‬‏ .*کے ساتھ چیٹ کریں
      let targetCallNode = textMatches(/(Conversar.*|Chatear.*|Makipag-chat sa.*|Chat with.*|.*के साथ चैट करें|แชทกับ.*|.*کے ساتھ چیٹ کریں)/).clickable(true).findOne(20000);

      if (!targetCallNode) {
         // let noWsNode = textStartsWith("Ligar para").findOne(5000);
         // if (noWsNode) {
         //    console.log("目标号码不存在", data.account);
         //    // return -20;
         //    return reGetTarget(data, i, j, 20);

         // }
         return reGetTarget(data, i, j, 20);
      }
      targetCallNode.click();
      sleep(500);

      let tmpCheckNode = id("com.whatsapp:id/ephemeral_nux_ok").findOne(2000);
      if (tmpCheckNode) {
         tmpCheckNode.click();
      }

      console.log(8);
      return sendMsg(data, i, j);
   }
}

function launchApp() {
   console.log("启动");
   var intent = new Intent();
   intent.setClassName(pkgName, "com.whatsapp.HomeActivity");
   intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
   context.startActivity(intent);
}


function writeContact(name, phone) {
   try {
      let Phone = android.provider.ContactsContract.CommonDataKinds.Phone;
      let ContentValues = android.content.ContentValues;
      let ContentUris = android.content.ContentUris;
      let ContactsContract = android.provider.ContactsContract;
      var rawA = new ContentValues();
      rawA.put("account_type", android.accounts.AccountManager.KEY_ACCOUNT_TYPE);
      rawA.put("account_name", android.accounts.AccountManager.KEY_ACCOUNT_NAME);

      var contacts = context.getContentResolver().insert(ContactsContract.RawContacts.CONTENT_URI, rawA);
      var rawContactId = ContentUris.parseId(contacts);
      var values = new ContentValues();
      console.log(rawContactId);
      values['put(java.lang.String,java.lang.Long)'](ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
      values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE);
      values.put(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name);
      context.getContentResolver().insert(ContactsContract.Data.CONTENT_URI, values);
      values.clear();
      values['put(java.lang.String,java.lang.Long)'](ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
      values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
      values.put("data1", phone);
      //        values.put(ContactsContract.CommonDataKinds.Phone.NUMBER,"123456789");
      values['put(java.lang.String,java.lang.Integer)']("data2", 2);
      //        values.put(ContactsContract.CommonDataKinds.Phone.TYPE,ContactsContractCommonDataKinds.Phone.TYPE_MOBILE);
      context.getContentResolver().insert(ContactsContract.Data.CONTENT_URI, values);
      console.log("添加成功");
   } catch (error) {
      console.log("添加失败", error);
   }

};
// 获取并居中显示 floaty.rawWindow
// function centerWindow(window) {
//    getWindowSize(window, (w, h) => {
//       let x = (device.width - w) / 2;
//       let y = (device.height - h) / 2;
//       window.setPosition(x, y);
//    });
// }

// 测量悬浮窗实际宽高
// function getWindowSize(window, callback) {
//    ui.run(() => {
//       try {
//          let view = Java.cast(window, android.view.View);
//          view.measure(
//             android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED),
//             android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED)
//          );
//          let width = view.getMeasuredWidth();
//          let height = view.getMeasuredHeight();
//          callback(width, height);
//       } catch (e) {
//          log("测量失败: " + e);
//          callback(0, 0);
//       }
//    });
// }
function showCircleLoading() {
   let window = floaty.rawWindow(
      <frame gravity="center" bg="#00000000">
         <vertical gravity="center" padding="20dp">
            <progressbar
               id="loading"
               style="@android:style/Widget.ProgressBar.Large"
            />
            <text
               text="Loading..."
               textColor="#ffffff"
               textSize="18sp"
               marginTop="10dp"
               gravity="center"
            />
         </vertical>
      </frame>
   );

   // 内容自适应大小
   window.setSize(-2, -2);
   window.setTouchable(false);

   // 居中定位
   const { width, height } = device;
   let x = (width - 300) / 2;
   let y = (height - 300) / 2;
   window.setPosition(x, y);
   // centerWindow(window);

   return {
      close: () => {
         ui.run(() => {
            window.close();
         });
      },
   };
}
//  转发功能
function forwardMsg(item, i) {
   try {
      launchApp();
      var intent = new Intent("com.bot.AUTOJS_CONTACT_DONE");
      context.sendBroadcast(intent);

      let loadingWindow = showCircleLoading();
      let accountList = [];
      let msgLink = "";
      // 添加通讯录
      console.log("添加通讯录");
      item.task_data.forEach((data, j) => {
         if (msgLink == "") {
            msgLink = data.text;
         }
         if (tmpTaskList[i].task_data[j].addedContact) { } else {
            writeContact(data.account, data.account);
            tmpTaskList[i].task_data[j].addedContact = true;
            tools.storage.put(storeKey, tmpTaskList);
         }
         if (tmpTaskList[i].task_data[j].taskFinish) { } else {
            accountList.push(data.account);
         }
      })

      loadingWindow.close();     // 关闭悬浮

      console.log("添加通讯录完成", accountList);

      // 执行转发
      forwardSend(item, i, msgLink);

   } catch (error) {
      console.error("运行中报错，保存数据::::", error);
      tools.storage.put(storeKey, tmpTaskList);
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
   }
}

function forwardSend(item, i, msgLink) {
   try {
      launchApp();
      sleep(random(5000, 7000));
      console.log(1);
      let userListNode = descMatches(/(Conversas.*|Chats.*|चैट.*|แชท.*|.*‏چیٹس.*)/).findOne(1000);
      if (!userListNode) {
         // let noAccountList = ["Esta conta não"]
         // let notAccountNode = findTextStart(noAccountList, 1000);
         let notAccountNode = textMatches(/(Esta conta não.*|Esta conta não.*)/).findOne(1000);
         if (notAccountNode) {
            console.info("账号被封");
            return -10;
         }
         console.log("第一步没找到111111");
         let notLoginNode = textMatches(/(CONCORDAR E CONTINUAR|ACEPTAR Y CONTINUAR)/).findOne(2000);
         if (notLoginNode) {
            console.info("未登录");
            return -11;
         }
         return -4;
      }
      if (!userListNode.isSelected()) {
         userListNode.select();
         sleep(3000);
      }

      console.log(2);
      let addTagNode = id("com.whatsapp:id/fab").findOne(10000);
      if (!addTagNode) {
         addTagNode = id("com.whatsapp:id/fabText").findOne(5000);
      }
      if (!addTagNode || !addTagNode.click()) {
         return -4;
      }
      console.log("点击+好友");
      sleep(2000);

      console.log(3);
      let selfNode = textMatches(/(.*\(você\)|.*\(Tú\)|.*\(Ikaw\)|.*\(You\)|.*\(आप\)|.*\(คุณ\)|.*\(آپ\))/).findOne(5000);
      if (!selfNode) {
         return -4;
      }
      let selfName = selfNode.text();
      console.log("执行账户：", selfName);
      tmpTaskList[i].ex_account = getNameBeforeLangTag(selfName, [" (Tú)", " (você)", " (Ikaw)", " (You)", " (आप)", " (คุณ)", " (آپ)"]);

      click("(Tú)");
      click("(você)");
      click("(Ikaw)");
      click("(You)");
      click("(आप)");
      click("(คุณ)");
      click("(آپ)");
      sleep(1000);

      console.log(4);
      console.log(4, msgLink);
      let inputNode = className("android.widget.EditText").findOne(5000);
      if (!inputNode) {
         return -4;
      }

      // window.location.href = url;
      console.log("发送的链接：", msgLink);
      let targetNode = text(msgLink).className("android.widget.TextView").findOne(5000);
      if (!targetNode) {
         console.log("发送的链接：不存在", msgLink);
         inputNode.setText(msgLink);
         sleep(random(1000, 3000));
         let sendNode = id("com.whatsapp:id/send").findOne(5000);
         if (sendNode == null) {
            sendNode = id("com.whatsapp:id/send_media_btn").findOne(5000);
         }
         if (!sendNode || !sendNode.click()) {
            return -4;
         }
         sleep(1000);
      }
      // ‏انہیں فارورڈ کریں
      console.log(5);
      // let isSuccessNode = descMatches(/(Encaminhar para.*|Reenviar a.*|Forward to.*|इन्हेें फ़ॉरवर्ड करें.*|I-forward kay.*|ส่งต่อไปยัง.*|.*انہیں فارورڈ کریں.*)/).find();
      // console.log("检查节点：111111");
      // let checkNodes = isSuccessNode.slice(-1);
      // console.log("检查节点：222222", checkNodes);


      let isSuccessNode = text(msgLink).findOne(5000);
      if (!isSuccessNode) {
         return -4;
      }
      console.log(5.1);
      longClick(msgLink);
      sleep(2000);

      console.log(6);
      let forwardNode = descMatches(/(Encaminhar.*|Reenviar.*|Forward.*|फ़ॉरवर्ड करें.*|I-forward.*|ส่งต่อ.*|.*فارورڈ کریں.*)/).findOne(5000);
      if (!forwardNode || !forwardNode.click()) {
         return -4;
      }
      sleep(2000);

      let searchNode = descMatches(/(Pesquisar|Buscar|Search|सर्च करें|Maghanap|ค้นหา|.*تلاش.*کریں.*)/).findOne(5000);
      if (!searchNode || !searchNode.click()) {
         return -4;
      }
      sleep(1000);

      console.log(7);
      inputNode = className("android.widget.EditText").findOne(5000);
      sleep(1000);
      if (inputNode) {
         // item.task_data.forEach((data, j) => {
         let tmpList = [];
         for (var j = 0; j < item.task_data.length; j++) {
            let data = tmpTaskList[i].task_data[j];
            if (tmpTaskList[i].task_data[j].taskFinish) {
               console.log("已发送：", i, j, tmpTaskList[i].task_data[j].taskFinish);
               continue;
            }
            console.log("已发送0000：", i, j, tmpTaskList[i].task_data[j]);

            inputNode = className("android.widget.EditText").findOne(5000);
            inputNode.setText(data.account);
            sleep(4000);
            let gridView = id("android:id/list").findOne(5000);
            if (gridView) {
               console.log("找到了点击00000");
               gridView.children().forEach(function (child) {
                  let tmpStr = data.account.match(/\d+/)[0];
                  console.log("获取字符串：", tmpStr);
                  sleep(1000);
                  let targetNode = child.findOne(textContains(tmpStr));
                  console.log("获取字符串：选中");
                  let yaoqing = child.findOne(textMatches(/(CONVIDAR|INVITAR|INVITE|आमंत्रित करें|MAG-IMBITA|เชิญ|.*مدعو.*کریں.*)/));
                  if (!yaoqing && targetNode) {
                     child.click();
                     tmpTaskList[i].task_data[j].selected = true;
                     tools.storage.put(storeKey, tmpTaskList);
                  }
               })
            }
            if (tmpTaskList[i].task_data[j].selected) {
               tmpList.push(j);
            } else {
               tmpTaskList[i].task_data[j].taskFinish = true;
               tmpTaskList[i].task_data[j].status = 2;
               tmpTaskList[i].task_data[j].result_text = "未搜索到用户";
            }
            if (tmpList.length > 0 && (tmpList.length == 5 || j == item.task_data.length - 1)) {
               console.log("5组一发送", tmpList);
               // if (tmpTaskList[i].task_data[j - index].selected) { } else {
               //    tmpTaskList[i].task_data[j - index].status = 2;
               //    tmpTaskList[i].task_data[j - index].result_text = "未搜索到用户";
               // }
               var sendNode = id("com.whatsapp:id/send").findOne(5000);
               if (sendNode && sendNode.click()) {
                  sleep(2000);
                  for (let index = 0; index < tmpList.length; index++) {
                     tmpTaskList[i].task_data[tmpList[index]].taskFinish = true;
                     tmpTaskList[i].task_data[tmpList[index]].sended = true;
                     tmpTaskList[i].task_data[tmpList[index]].result_text = "已转发";
                  }
                  tmpList = [];

                  tools.storage.put(storeKey, tmpTaskList);
                  console.log("5组一发送00000");

                  sleep(2000);
                  console.log(5);
                  let isSuccessNode = text(msgLink).findOne(5000);
                  if (!isSuccessNode) {
                     return -4;
                  }
                  console.log(5.1);
                  longClick(msgLink);
                  sleep(2000);

                  console.log(6);
                  let forwardNode = descMatches(/(Encaminhar.*|Reenviar.*|Forward.*|फ़ॉरवर्ड करें.*|I-forward.*|ส่งต่อ.*|.*فارورڈ کریں.*)/).findOne(5000);
                  if (!forwardNode) {
                     return -4;
                  }
                  forwardNode.click();
                  sleep(2000);

                  console.log(6.1);
                  searchNode = descMatches(/(Pesquisar|Buscar|Search|सर्च करें|Maghanap|ค้นหา|.*تلاش.*کریں.*)/).findOne(5000);
                  if (searchNode) {
                     searchNode.click();
                     sleep(1000);
                  }
               }
            }
         }
      }
   } catch (error) {
      console.error("运行中报错，保存数据::::", error);
      tools.storage.put(storeKey, tmpTaskList);
      if (error.toString().includes("ScriptInterruptedException")) {
         isOver = true;
         throw error;
      }
   }
}