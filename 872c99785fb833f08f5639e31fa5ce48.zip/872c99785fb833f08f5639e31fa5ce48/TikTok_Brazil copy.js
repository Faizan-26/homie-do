var pkgName = "com.ss.android.ugc.trill";
// var pkgName = "com.zhiliaoapp.musically";
var withLog = require("./withlog.js");
var tools = require("./tools.js");
var utils = require("./utils.js");
var tmpTaskList = [];


var config = {};
var selfId = "";
var isContinueFail = 0;
var isOver = false;

var res = {};

// 通用函数，查找匹配任一语言
function findTextEnd(keys, timeout) {
    let tmpNode = null;
    keys.forEach((item, index) => {
        const node = textEndsWith(item).findOne(timeout);
        if (node) {
            tmpNode = node;
        }
    })
    return tmpNode;
}
function findTextStart(keys, timeout) {
    let tmpNode = null;
    keys.forEach((item, index) => {
        const node = textStartsWith(item).findOne(timeout);
        if (node) {
            tmpNode = node;
        }
    })
    return tmpNode;
}

function findDescStart(keys, timeout) {
    let tmpNode = null;
    keys.forEach((item, index) => {
        const node = descStartsWith(item).findOne(timeout);
        if (node) {
            tmpNode = node;
        }
    })
    return tmpNode;
}

var runing = setInterval(() => {
    if (isOver) {
        clearInterval(runing);
    }
}, 1000);


events.on("say", function (param) {
    console.info(param);
    handle(param.list);
});
function randomNum(minNum, maxNum) {
    return parseInt(Math.random() * (maxNum - minNum) + minNum, 10);
}


function handle(taskList) {
    tmpTaskList = tools.storage.get("TikTok_Brazil", []);
    if (tmpTaskList.length > 0) {
        for (var i = tmpTaskList.length - 1; i >= 0; i--) {
            if (tmpTaskList[i] == null || taskList[i] == null) { tmpTaskList.splice(i, 1);; continue; }
            console.info("tmp::", tmpTaskList[i]);
            console.info("not tmp::", taskList[i]);
            if (tmpTaskList[i].task_sub_id != taskList[i].task_sub_id) {
                submitTask(i);
                // tmpTaskList = [];
            }
        }
    }

    if (tmpTaskList.length < 1) {
        tmpTaskList = taskList;
        tools.storage.put("TikTok_Brazil", tmpTaskList);
    } else {
        console.info("has TikTok_Brazil storage:::", tmpTaskList.length);
    }

    console.log("：：：：：：：", tmpTaskList);
    for (var i = tmpTaskList.length - 1; i >= 0; i--) {
        setTimeout(function () { }, 0);
        if (tmpTaskList[i] == null) { continue; }
        let fileName = withLog.startRecordLog(tmpTaskList[i].task_type + "-TikTok_Brazil.log");
        console.info(i, ":::", tmpTaskList[i])
        config = tmpTaskList[i].config;
        for (var j = 0; j < tmpTaskList[i].task_data.length; j++) {
            console.info("开始执行", tmpTaskList[i].task_data[j]);
            if (tmpTaskList[i].task_data[j].result_text && tmpTaskList[i].task_data[j].result_text != "") {
                console.log("is finishd");
                continue;
            }
            let s = -1;
            switch (tmpTaskList[i].task_type) {
                case 3:
                    s = publishMedia(i, j);
                    break;
                // case 5:
                //     s = setUserIntro(i, j);
                //     break;
                // case 6:
                //     s = addComLink(i, j);
                //     break;
            }
            if (!tmpTaskList[i].task_data[j].result_text || tmpTaskList[i].task_data[j].result_text == null || tmpTaskList[i].task_data[j].result_text == "") {
                tmpTaskList[i].task_data[j].result_text = "res" + s;
                tmpTaskList[i].task_data[j].result_image = "";
                tmpTaskList[i].task_data[j].status = 2;
                tools.storage.put("TikTok_Brazil", tmpTaskList);
            }

            console.log("间隔：", config.post_interval);
            let randTime = randomNum(config.post_interval[0], config.post_interval[1]);
            sleep(randTime * 1000);
        }

        for (var j = 0; j < tmpTaskList[i].task_data.length; j++) {
            setTimeout(function () { }, 0);
            if (tmpTaskList[i].task_data[j].status == 2 && tmpTaskList[i].task_type == 3 && tmpTaskList[i].task_data[j].result_text == "sended") {
                console.info("secend check::", i, j);
                checkSuccess(i, j);
            }
        }
        submitTask(i);
        withLog.submitLog(i, 1, fileName);
    }

    // if (tmpTaskList.length > 0) {
    //     tools.addStatus(tmpTaskList[0].pkgName);
    // }

    tmpTaskList = [];
    tools.storage.remove("TikTok_Brazil");

    isOver = true;
    console.log("TikTok_Brazil exe  end");
}

function addComLink(indexI, indexJ) {
    let oneData = tmpTaskList[indexI].task_data[indexJ];
    // let maxExe = config.continuous_fail_stop;
    let maxReture = 2;
    launchApp();
    while (true) {
        setTimeout(function () { }, 0);
        let perfileNode = packageName(pkgName).desc("Perfil").className("android.widget.FrameLayout").findOne(5000);
        if (perfileNode) {
            perfileNode.click();
            sleep(1000);
            let selfName = textStartsWith("@").className("android.widget.Button").findOne(6000);
            if (selfName) {
                console.info("用户：", selfName.text());
                selfId = selfName.text();
            }
            console.log("0000");
            let perfileNodeRect = perfileNode.bounds();
            let menuNode = className("android.widget.ImageView").boundsInside(perfileNodeRect.left, 0, device.width, device.height / 4).findOne(10000);
            if (menuNode) {
                console.log("1111");
                let tRect = menuNode.bounds();
                click(tRect.centerX(), tRect.centerY());
                sleep(500);
                let comNode = text("Configurações e privacidade").findOne(5000);
                if (comNode) {
                    console.log("222");
                    click("Configurações");
                    sleep(2000);
                    let accountNode = text("Conta").find();
                    console.log(accountNode.length);
                    if (accountNode) {
                        let accountNodeBtn = accountNode.get(1);
                        if (accountNodeBtn) {
                            console.log("333");
                            click("Conta", 1);
                            sleep(2000);

                            // "Trocar para a Conta Pessoal"
                            let changeComNode = text("Trocar para Conta Corporativa").findOne(5000);
                            if (changeComNode) {
                                console.log("444");
                                let tRect = changeComNode.bounds();
                                click(tRect.centerX(), tRect.centerY());
                                sleep(3000);
                                console.log(device.height * 0.82);
                                click(device.width / 2, device.height * 0.76);
                                sleep(1000);
                                click(device.width / 2, device.height * 0.76);
                                sleep(1000);
                                click(device.width / 2, device.height * 0.76);
                                sleep(1000);
                                click(device.width / 2, device.height * 0.76);
                                sleep(1000);
                                click(device.width / 2, device.height / 2);
                                sleep(1000);
                                click(device.width / 2, device.height * 0.88);
                                sleep(1000);
                                // click(device.width / 2, device.height * 0.44);
                                sleep(1000);
                                console.log("5555");
                                let pularNode = text("Pular").findOne(5000);
                                if (pularNode) {
                                    click("Pular");
                                    sleep(500);
                                }
                                back();
                                sleep(1000);
                                // launchApp();

                                // console.log("55556666");
                                // let perfileNode= desc("Perfil").className("android.widget.FrameLayout").findOne(5000);
                                // if(perfileNode){
                                perfileNode.click();
                                sleep(500);
                                let editPerfileNode = text("Editar perfil").findOne(5000);
                                if (editPerfileNode) {
                                    let tRect = editPerfileNode.bounds();
                                    click(tRect.centerX(), tRect.centerY());
                                    console.log("6666");
                                    sleep(500);
                                    let linkNode = descStartsWith("Links").findOne(5000);
                                    if (linkNode) {
                                        linkNode.click();
                                        sleep(500);
                                        let siteNode = descStartsWith("Site").findOne(5000);
                                        if (siteNode) {
                                            siteNode.click();
                                            console.log("7777");
                                            sleep(500);
                                            let editNode = className("android.widget.EditText").findOne(5000);
                                            if (editNode) {
                                                editNode.setText(oneData.link);
                                                sleep(500);
                                                let sendNode = text("Salvar").findOne(5000);
                                                if (sendNode) {
                                                    click("Salvar");
                                                    tmpTaskList[indexI].task_data[indexJ].result_text = "res" + 1;
                                                    tmpTaskList[indexI].task_data[indexJ].result_image = "";
                                                    tmpTaskList[indexI].task_data[indexJ].status = 1;
                                                    tools.storage.put("TikTok_Brazil", tmpTaskList);
                                                    return 1;
                                                }
                                            } else {
                                                console.log("TikTok_Brazil-addComLink-8")
                                            }
                                        } else {
                                            console.log("TikTok_Brazil-addComLink-7")
                                        }

                                    } else {
                                        console.log("TikTok_Brazil-addComLink-6")
                                    }
                                } else {
                                    console.log("TikTok_Brazil-addComLink-5")
                                }
                                // }
                            } else {
                                back();
                            }
                        } else {
                            console.log("TikTok_Brazil-addComLink-4")
                        }
                    } else {
                        console.log("TikTok_Brazil-addComLink-3")
                    }
                } else {
                    console.log("TikTok_Brazil-addComLink-2")
                }
            } else {
                console.log("TikTok_Brazil-addComLink-1")
            }

        } else {
            maxReture--;
            if (maxReture < 1) {
                // sum.setAndNotify(-3);
                return -3;
            }
            back();
            back();
            launchApp();
        }
    }
    return -1;
};

function checkSuccess(indexI, indexJ) {

    let oneData = tmpTaskList[indexI].task_data[indexJ];
    launchApp();
    console.log("加载到首页");
    // while (true) {
    let perfileNode = packageName(pkgName).text("Perfil").findOne(6000);
    console.log("点击个人列表");
    if (perfileNode) {
        while (!click("Perfil"));
        sleep(2000);
        let selfName = textStartsWith("@").className("android.widget.Button").findOne(6000);
        if (selfName) {
            selfId = selfName.text();
            console.info("获取自己", selfId);
        }

        var gridView = className("android.widget.GridView").findOne(5000);
        if (gridView) {
            console.info("刷新");
            let posX = device.width / 2;
            let posY = device.height / 3;
            swipe(posX, posY, posX, posY + device.height / 2, 500);
            sleep(1000);
            swipe(posX, posY, posX, posY + device.height / 2, 500);
            sleep(3000);


            let tmpStr = "#" + oneData.tag + " " + oneData.paperwork;
            tmpStr = tmpStr.length > 12 ? tmpStr.slice(0, 12) : tmpStr;

            let targetNode = gridView.findOne(textStartsWith(tmpStr));
            if (targetNode) {
                console.info("找到对应空间", tmpStr, tmpTaskList[indexI].task_data[indexJ].tag);
            }

            // let textNode = textStartsWith(tmpStr).findOne(6000);
            // let targetNode = gridView.findOne(textStartsWith(tmpStr));
            // if (targetNode) {
            //     targetNode.click();
            //     sleep(3000);
            // }


            // console.info("获取自己00000");
            // let childNode = gridView.find(className("android.widget.FrameLayout"));
            // childNode.forEach(element => {
            //     let ceshiNode = element.findOne(textStartsWith(tmpStr));
            //     if (ceshiNode) {
            //         console.log("找到对应文字：", tmpStr, oneData.tag);
            //     }

            // });
            let childNode = gridView.find(className("android.widget.FrameLayout"));
            if (childNode) {
                for (let index = 0; index < childNode.length; index++) {
                    let tmpChild = childNode[index].findOne(text("Fixado"));
                    if (!tmpChild) {
                        tmpChild = childNode[index].findOne(text("Anclado"));
                    }
                    if (tmpChild) { continue; }
                    tmpChild = childNode[index].findOne(textStartsWith("Rascunhos"));
                    if (!tmpChild) {
                        tmpChild = childNode[index].findOne(textStartsWith("Borradores"));
                    }
                    if (tmpChild) { continue; }
                    childNode[index].click();
                    return tmpGetLink(indexI, indexJ, 0, childNode.length - index);
                }
            }
        }
    }
    // }

    return -1;
}

function tmpGetLink(indexI, indexJ, num, itemCount) {
    sleep(6000);
    let oneData = tmpTaskList[indexI].task_data[indexJ];
    console.error("进入：", num, itemCount, tmpTaskList[indexI].task_data[indexJ].tag, tmpTaskList[indexI].task_data[indexJ].paperwork);
    setTimeout(function () { }, 0);
    if (num > 10) {
        return -1;
    }

    let tmpStr = "#" + oneData.tag + " " + oneData.paperwork;
    tmpStr = tmpStr.length > 12 ? tmpStr.slice(0, 12) : tmpStr;
    let textNode = textStartsWith(tmpStr).findOne(6000);
    if (textNode) {
        console.info("文字位置：", textNode.bounds());
        if (textNode.visibleToUser()) {
            console.info("找到了", tmpStr);
            return getLinks(indexI, indexJ);
        }
    }

    // console.log("不存在，下一个000000", num);
    // swipe(device.width / 2, device.height * 0.8, device.width / 2, device.height * 0.2, 300);
    // sleep(2000);
    // tmpGetLink(indexI, indexJ, num + 1, itemCount);

    // let tmpMsgNode = descStartsWith("Leia ou adicione comentários").visibleToUser().findOne(5000);
    // if (tmpMsgNode) {
    //     console.log("找到评论");
    //     // while (!tmpMsgNode.click());
    //     let tmpMsgNodeRect = tmpMsgNode.bounds();
    //     console.info(tmpMsgNodeRect);
    //     click(tmpMsgNodeRect.centerX(), tmpMsgNodeRect.centerY());
    //     console.log("点击过");
    //     sleep(1000);
    //     let tmpStr = "#" + oneData.tag + " " + oneData.paperwork;
    //     tmpStr = tmpStr.length > 12 ? tmpStr.slice(0, 12) : tmpStr;
    //     let textNode = textStartsWith(tmpStr).findOne(6000);
    //     let isExsitStr = false;
    //     if (textNode) {
    //         console.log("找到对应文字：", num, itemCount, tmpStr, oneData.tag);
    //         // sleep(500000);
    //         // swipe(device.width / 2, device.height * 0.8, device.width / 2, device.height * 0.2, 300);
    //         sleep(2000);
    //         // swipe(posX, posY, posX, device.height / 4, 500);
    //         isExsitStr = true;
    //     }

    //     click(device.width / 2, device.height / 8);
    //     sleep(3000);
    //     if (isExsitStr) {
    //         return getLinks(indexI, indexJ);
    //     }


    swipe(device.width / 2, device.height * 0.8, device.width / 2, device.height * 0.2, 300);
    //        swipe(posX, posY, posX, device.height / 4, 500);
    console.log("不存在，下一个000000", num);
    sleep(2000);
    tmpGetLink(indexI, indexJ, num + 1, itemCount);
}


function getLinks(indexI, indexJ) {
    let linkNode = descStartsWith("Compartilhar vídeo").visibleToUser().findOne(5000);
    if (!linkNode) {
        linkNode = descStartsWith("Compartir el vídeo").visibleToUser().findOne(5000);
    }

    if (linkNode) {
        console.info("分享位置：", linkNode.bounds());
        while (!linkNode.click());

        console.info("对比：:11111", "Copiar Link");
        let copyNode = desc("Copiar Link").visibleToUser().findOne(5000);
        if (!copyNode) {
            copyNode = desc("Copiar enlace").visibleToUser().findOne(5000);
        }
        let isCopy = false;
        if (copyNode) {
            // while (!click("Copiar Link"));
            click("Copiar Link");
            click("Copiar enlace");
            console.info("点击copy000");
            sleep(3000);
            isCopy = true;
        } else {
            let scrollNode = className("androidx.recyclerview.widget.RecyclerView").visibleToUser().find();
            if (scrollNode && scrollNode.length > 2) {
                let tmpScrollNode = scrollNode.get(1);
                tmpScrollNode.scrollForward();
                sleep(2000);
                copyNode = desc("Copiar Link").visibleToUser().findOne(5000);
                if (!copyNode) {
                    copyNode = desc("Copiar enlace").visibleToUser().findOne(5000);
                }
                if (copyNode) {
                    // while (!click("Copiar Link"));
                    click("Copiar Link");
                    click("Copiar enlace");
                    console.info("点击copy1111");
                    sleep(3000);
                    isCopy = true;
                }
                if (!isCopy) {
                    tmpScrollNode.scrollForward();
                    sleep(1000);
                    copyNode = desc("Copiar Link").visibleToUser().findOne(5000);
                    if (!copyNode) {
                        copyNode = desc("Copiar enlace").visibleToUser().findOne(5000);
                    }
                    if (copyNode) {
                        // while (!click("Copiar Link"));
                        click("Copiar Link");
                        click("Copiar enlace");
                        console.info("点击copy1111");
                        sleep(3000);
                        isCopy = true;
                    }
                }

            }
        }
        console.log("链接22：", getClip());
        // if (num < 1) { return getLinks(indexI, indexJ, num + 1); }
        if (isCopy) {
            sleep(1000);
            return pauseLInks(indexI, indexJ);
            // console.info("点击了拷贝按钮");
            // let searchNode = searchNode = searchNode = text("Procurar").findOne(5000);
            // if (searchNode == null) {
            //     searchNode = desc("Procurar").findOne(5000);
            // }
            // if (searchNode == null) {
            //     searchNode = id("com.ss.android.ugc.trill:id/ghb").findOne(5000);
            // }

            // if (searchNode) {
            //     searchNode.click();
            //     sleep(10000);
            //     console.info("search....");

            //     let editNode = className("android.widget.EditText").findOne(5000);
            //     if (editNode) {
            //         editNode.setText("");
            //         editNode.paste();
            //         sleep(3000);
            //         editNode = className("android.widget.EditText").findOne(5000);
            //         let tmpStr = editNode.text();
            //         console.log("链接：：", tmpStr);
            //         console.log("链接21：", getClip());
            //         if (tmpStr != "") {
            //             tmpTaskList[indexI].task_data[indexJ].status = 1;
            //             tmpTaskList[indexI].task_data[indexJ].result_text = tmpStr;
            //             tools.storage.put("TikTok_Brazil", tmpTaskList);
            //             back();
            //             back();
            //             return 1;
            //         }

            //     }
            // }
        }
    }
}


function publishMedia(indexI, indexJ) {
    let oneData = tmpTaskList[indexI].task_data[indexJ];

    let maxExe = config.continuous_fail_stop;
    let maxReture = 3;
    launchApp();
    let downFileName = tools.downloadFiles(oneData.video);
    if (downFileName == "") {
        console.error("TikTok_Brazil-publishMedia-下载视频失败", oneData.video);
        return -10;
    }
    console.info("下载文件路径:", downFileName);
    while (true) {
        setTimeout(function () { }, 0);

        // 封账号
        // let notAccountNode = textStartsWith("Esta conta não").findOne(5000);
        // if (notAccountNode) {
        //     submitBlocked(index);
        //     return -10;
        // }

        let perfileNode = packageName(pkgName).desc("Perfil").findOne(5000);
        // let perfileNode = packageName(pkgName).descMatches(/(Perfil|?)/).findOne(5000);
        if (perfileNode) {
            maxExe--;
            if (maxExe < 1) {
                console.error("TikTok_Brazil-publishMedia-1");
                return -1;
            }

            click("Perfil");
            let selfName = textStartsWith("@").className("android.widget.Button").findOne(6000);
            if (selfName) {
                selfId = selfName.text();
            }
            let tRect = perfileNode.bounds();
            click(tRect.centerX() - tRect.width() * 2, tRect.centerY());
            sleep(2000);
            let imgSelectNode = id("com.ss.android.ugc.trill:id/bnj").findOne(5000);
            let idIsExist = true;
            if (imgSelectNode == null) {
                idIsExist = false;
                imgSelectNode = text("TEXTO").findOne(5000);
                // imgSelectNode = textMatches(/(TEXTO|?)/).findOne(5000);
            }

            if (imgSelectNode) {
                if (idIsExist) {
                    imgSelectNode.click();
                    sleep(500);
                } else {
                    let tRect = imgSelectNode.bounds();
                    click(tRect.centerX() + tRect.width(), tRect.centerY() + tRect.height() * 3);
                    sleep(500);
                }

                sleep(5000);
                let todosNode = text("Vídeos").findOne(5000);
                // let todosNode = textMatches(/(Vídeos|?)/).findOne(5000);
                if (todosNode) {
                    click("Vídeos");
                    console.log("find video ");
                    sleep(3000);
                    // let hulue = text("Entendi").findOne(500);
                    let hulue = textMatches(/(Entendi|Siguiente)/).findOne(500);
                    if (hulue) {
                        hulue.click();
                        sleep(1000);
                    }
                    var gridView = className("android.widget.GridView").findOne(5000);
                    if (gridView) {
                        sleep(2000);
                        var firstItem = gridView.child(0);
                        if (firstItem) {
                            firstItem.click();
                            sleep(1000);
                            firstItem.click();
                            sleep(1000);
                            // let nxetNode = text("Avançar").findOne(5000);
                            let nxetNode = textMatches(/(Avançar|Siguiente)/).findOne(5000);
                            if (nxetNode) {
                                click("Avançar");
                                click("Siguiente");
                                sleep(4000);

                                nxetNode = textStartsWith("Próximo").findOne(3000);
                                if (nxetNode) {
                                    click("Próximo");
                                    sleep(1000);
                                }
                                // nxetNode = text("Avançar").findOne(5000);
                                nxetNode = textMatches(/(Avançar|Siguiente)/).findOne(5000);
                                if (nxetNode) {
                                    click("Avançar");
                                    click("Siguiente");
                                    sleep(1000);
                                }

                                let editNode = className("android.widget.EditText").findOne(5000);
                                if (editNode) {
                                    let tmpStrAddTag = "#" + oneData.tag + " " + oneData.paperwork;
                                    console.log("set text is::", tmpStrAddTag)
                                    editNode.setText(tmpStrAddTag);

                                    sleep(500);
                                    let checkbox = className("android.widget.CheckBox").findOne(5000);
                                    if (checkbox) {
                                        var bounds = checkbox.bounds();
                                        click(bounds.centerX(), bounds.centerY());
                                    }

                                    let sendNode = text("Publicar").findOne(5000);
                                    if (sendNode) {
                                        click("Publicar");
                                        sleep(500);
                                        // Cambiar música
                                        let tmpErr = text("Publicar de todas formas").findOne(5000);
                                        if (tmpErr) {
                                            tmpErr.click();
                                            sleep(500);
                                        }

                                        console.log("sended vidio");
                                        tmpTaskList[indexI].task_data[indexJ].result_text = "sended";
                                        tmpTaskList[indexI].task_data[indexJ].status = 2;
                                        tools.storage.put("TikTok_Brazil", tmpTaskList);
                                        sleep(15000);
                                        let tmpStr = tmpStrAddTag;
                                        tmpStr = tmpStr.length > 15 ? tmpStr.slice(0, 15) : tmpStr;
                                        while (true) {
                                            setTimeout(function () { }, 0);
                                            let findTextNode = textStartsWith(tmpStr).findOne(1000);
                                            if (findTextNode) {
                                                tools.deleteDownloadFiles(downFileName);
                                                console.info("找到对应文字:", tmpStr, "#" + tmpTaskList[indexI].task_data[indexJ].tag + " " + tmpTaskList[indexI].task_data[indexJ].paperwork);
                                                sleep(3000);
                                                return;
                                            }
                                        }
                                        return;

                                    } else {
                                        console.error("TikTok_Brazil-publishMedia-12");
                                    }
                                } else {
                                    console.error("TikTok_Brazil-publishMedia-10");
                                }
                                // } else {
                                //     console.error("TikTok_Brazil-publishMedia-9");
                                // }
                            } else {
                                console.error("TikTok_Brazil-publishMedia-8");
                            }
                        } else {
                            console.error("TikTok_Brazil-publishMedia-7");
                        }
                    } else {
                        console.error("TikTok_Brazil-publishMedia-6");
                    }
                } else {
                    console.error("TikTok_Brazil-publishMedia-5");
                }

            } else {
                console.error("TikTok_Brazil-publishMedia-4");
            }
        } else {
            console.error("TikTok_Brazil-publishMedia-2");
            maxReture--;
            if (maxReture < 1) {
                // sum.setAndNotify(-3);
                return -3;
            }
            back();
            back();
            launchApp();
        }

        return -1;

    }
}
// })

function setUserIntro(indexI, indexJ) {
    let oneData = tmpTaskList[indexI].task_data[indexJ];
    // let maxExe = config.continuous_fail_stop;
    let maxReture = 3;
    launch(pkgName);
    while (true) {
        setTimeout(function () { }, 0);
        let perfileNode = packageName(pkgName).desc("Perfil").className("android.widget.FrameLayout").findOne(5000);
        if (perfileNode) {
            perfileNode.click();
            sleep(500);
            let editPerfileNode = text("Editar perfil").findOne(5000);
            if (editPerfileNode) {
                let selfName = textStartsWith("@").className("android.widget.Button").findOne(6000);
                if (selfName) {
                    selfId = selfName.text();
                }

                let tRect = editPerfileNode.bounds();
                click(tRect.centerX(), tRect.centerY());
                let personalProfileNode = descStartsWith("Descrição").className("android.widget.Button").findOne(5000);
                if (personalProfileNode) {
                    personalProfileNode.click();
                    sleep(500);
                    let editNode = className("android.widget.EditText").findOne(5000);
                    if (editNode) {
                        editNode.setText(oneData.text);
                        sleep(500);
                        let editBtnNode = text("Salvar").className("android.widget.Button").enabled(true).findOne(5000);
                        if (editBtnNode) {
                            editBtnNode.click();
                            tmpTaskList[indexI].task_data[indexJ].result_text = "res" + 1;
                            tmpTaskList[indexI].task_data[indexJ].result_image = "";
                            tmpTaskList[indexI].task_data[indexJ].status = 1;
                            tools.storage.put("TikTok_Brazil", tmpTaskList);
                            return 1;
                        } else {
                            console.log("1===TikTok_Brazil===setUserIntro===step 4")
                        }
                    } else {
                        console.log("1===TikTok_Brazil===setUserIntro===step 3")
                    }
                } else {
                    console.log("1===TikTok_Brazil===setUserIntro===step 2")
                }
            } else {
                console.log("1===TikTok_Brazil===setUserIntro===step 1")
            }
        } else {
            maxReture--;
            if (maxReture < 1) {
                // sum.setAndNotify(-3);
                return -3;
            }
            back();
            back();
            launch(pkgName);
        }
    }

    return -1;
}

function pauseLInks(indexI, indexJ) {
    let oneData = tmpTaskList[indexI].task_data[indexJ];
    // let maxExe = config.continuous_fail_stop;
    let maxReture = 3;
    launch(pkgName);
    while (true) {
        setTimeout(function () { }, 0);
        let perfileNode = packageName(pkgName).desc("Perfil").className("android.widget.FrameLayout").findOne(5000);
        if (perfileNode) {
            perfileNode.click();
            sleep(500);
            let editPerfileNode = text("Editar perfil").findOne(5000);
            if (editPerfileNode) {
                let selfName = textStartsWith("@").className("android.widget.Button").findOne(6000);
                if (selfName) {
                    selfId = selfName.text();
                }

                let tRect = editPerfileNode.bounds();
                click(tRect.centerX(), tRect.centerY());
                let personalProfileNode = descStartsWith("Descrição").className("android.widget.Button").findOne(5000);
                if (!personalProfileNode) {
                    personalProfileNode = descStartsWith("Descripción").className("android.widget.Button").findOne(5000);
                }
                if (personalProfileNode) {
                    personalProfileNode.click();
                    sleep(500);
                    let editNode = className("android.widget.EditText").findOne(5000);
                    if (editNode) {
                        editNode.setText("--");
                        // sleep(500);
                        editNode.paste();
                        sleep(3000);
                        editNode = className("android.widget.EditText").findOne(5000);
                        let tmpStr = editNode.text();
                        console.log("链接：：", tmpStr);
                        console.log("链接21：", getClip());
                        if (tmpStr != "" && tmpStr != "--") {
                            let prefix = "--";
                            if (tmpStr.startsWith(prefix)) {
                                tmpStr = tmpStr.slice(prefix.length);
                            }
                            tmpTaskList[indexI].task_data[indexJ].status = 1;
                            tmpTaskList[indexI].task_data[indexJ].result_text = tmpStr;
                            tools.storage.put("TikTok_Brazil", tmpTaskList);
                            back();
                            back();
                            return 1;
                        } else {
                            return checkSuccess(indexI, indexJ);
                        }
                    } else {
                        console.log("1===TikTok_Brazil===setUserIntro===step 3")
                    }
                } else {
                    console.log("1===TikTok_Brazil===setUserIntro===step 2")
                }
            } else {
                console.log("1===TikTok_Brazil===setUserIntro===step 1")
            }
        } else {
            maxReture--;
            if (maxReture < 1) {
                // sum.setAndNotify(-3);
                return -3;
            }
            back();
            back();
            launch(pkgName);
        }
    }

    return -1;
}
// ************************************************************************
// function submitBlocked(i) {
//     try {
//         let res = {};
//         res.app_id = tmpTaskList[i].app_id;

//         utils.submitBlocked(res);
//         submitRes(i);

//     } catch (error) {
//         console.error("-1===== submit exp -1");
//     }
// }

function launchApp() {
    var intent = new Intent();
    intent.setClassName(pkgName, "com.ss.android.ugc.aweme.splash.SplashActivity");
    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
    context.startActivity(intent);
};

function submitTask(i) {
    try {
        let res = {

        };
        res.task_id = tmpTaskList[i].task_id;
        res.task_sub_id = tmpTaskList[i].task_sub_id;
        res.ex_account = selfId;
        res.has_continuous_fail = isContinueFail;
        res.task_data = JSON.stringify(tmpTaskList[i].task_data);
        console.error("提交结果", res);
        utils.submitTask(res);


        if (i >= 0) {
            tmpTaskList.splice(i, 1);
            tools.storage.put("TikTok_Brazil", tmpTaskList);
            //     tools.storage.remove("TikTok_Brazil");
            //     tmpTaskList = [];
        }

        tmpTaskList[i] = null;

        console.info(" submit TikTok_Brazil end");
    } catch (error) {
        console.error("-1===== submit TikTok_Brazil exp -1");
    }
}